"""Быстрые точные факты без веб-поиска: погода (Open-Meteo, без ключа) и курсы валют (ЦБ РФ).
Если вопрос про это — отдаём готовый блок данных в промпт, поиск не нужен."""
import logging
import re
import time

WEATHER_RE = re.compile(r"(погод|температур|дожд|снег|гроз|холодно|жарко|тепло ли|градус|осадк)", re.I)
RATE_RE = re.compile(r"(курс|доллар|евро|юан|дирхам|тенге|лир[аы]|рубл[ья]\s+к|usd|eur|cny|aed|kzt|try|gbp|фунт|сколько\s+стоит\s+(?:доллар|евро|юань))", re.I)
CITY_RE = re.compile(r"\b(?:в|во|по)\s+([А-ЯЁа-яёA-Za-z][\w\-]{2,})", re.I)
ALIASES = {"питере": "Санкт-Петербург", "питер": "Санкт-Петербург", "спб": "Санкт-Петербург", "мск": "Москва", "москве": "Москва", "дубае": "Дубай",
           "стамбуле": "Стамбул", "сочи": "Сочи", "казани": "Казань", "грозном": "Грозный", "махачкале": "Махачкала", "баку": "Баку", "ташкенте": "Ташкент",
           "алматы": "Алматы", "астане": "Астана", "бишкеке": "Бишкек", "душанбе": "Душанбе", "ереване": "Ереван", "тбилиси": "Тбилиси", "минске": "Минск",
           "киеве": "Киев", "екб": "Екатеринбург", "екатеринбурге": "Екатеринбург", "новосибирске": "Новосибирск", "краснодаре": "Краснодар", "ростове": "Ростов-на-Дону",
           "уфе": "Уфа", "самаре": "Самара", "перми": "Пермь", "тюмени": "Тюмень", "владикавказе": "Владикавказ", "нальчике": "Нальчик", "дербенте": "Дербент"}
STOP = {"чате", "городе", "общем", "итоге", "целом", "принципе", "смысле", "выходные", "понедельник", "вторник", "среду", "четверг", "пятницу", "субботу", "воскресенье", "этом", "том"}
WHEN_RE = re.compile(r"(завтра|послезавтра|на\s+неделю|в\s+выходные|на\s+(?:понедельник|вторник|среду|четверг|пятницу|субботу|воскресенье))", re.I)
DEFAULT_CITY = "Москва"
CODES = {0: "ясно", 1: "в основном ясно", 2: "переменная облачность", 3: "пасмурно", 45: "туман", 48: "изморозь", 51: "морось", 53: "морось", 55: "сильная морось",
         61: "небольшой дождь", 63: "дождь", 65: "сильный дождь", 66: "ледяной дождь", 67: "ледяной дождь", 71: "небольшой снег", 73: "снег", 75: "сильный снег",
         77: "снежные зёрна", 80: "ливень", 81: "ливень", 82: "сильный ливень", 85: "снегопад", 86: "сильный снегопад", 95: "гроза", 96: "гроза с градом", 99: "гроза с градом"}
_cache: dict[str, tuple[float, str]] = {}


def _city_candidates(text: str) -> list[str]:
    m = CITY_RE.search(text)
    if not m or m.group(1).lower() in STOP:
        return [DEFAULT_CITY]
    raw = m.group(1).strip()
    low = raw.lower()
    if low in ALIASES:
        return [ALIASES[low]]
    cands = [raw]
    if low.endswith("е"):
        cands += [raw[:-1] + "а", raw[:-1] + "ь", raw[:-1]]       # москве→москва, казане→казань, омске→омск
    elif low.endswith("и"):
        cands += [raw[:-1] + "ь", raw[:-1] + "ия", raw[:-1] + "а"]  # перми→пермь, самари→самара
    elif low.endswith("у"):
        cands += [raw[:-1] + "а"]
    return cands[:4]


async def weather(text: str) -> str | None:
    import aiohttp
    cands = _city_candidates(text)
    days = 7 if WHEN_RE.search(text) else 2
    key = f"w:{cands[0].lower()}:{days}"
    ts, val = _cache.get(key, (0, ""))
    if time.time() - ts < 900:
        return val
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as s:
            loc = None
            for city in cands:
                async with s.get("https://geocoding-api.open-meteo.com/v1/search", params={"name": city, "count": 1, "language": "ru"}) as r:
                    g = await r.json()
                if g.get("results"):
                    loc = g["results"][0]
                    break
            if not loc:
                return None
            city = cands[0]
            name = loc.get("name") or city
            country = loc.get("country") or ""
            async with s.get("https://api.open-meteo.com/v1/forecast", params={
                "latitude": loc["latitude"], "longitude": loc["longitude"], "timezone": "auto", "forecast_days": days,
                "current": "temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max",
                "hourly": "temperature_2m,weather_code,precipitation_probability"}) as r:
                w = await r.json()
    except Exception as e:
        logging.warning("weather: %s", str(e)[:120])
        return None
    cur = w.get("current") or {}
    out = [f"ПОГОДА ({name}{', ' + country if country else ''}; данные Open-Meteo, обновлено {time.strftime('%H:%M')}):",
           f"сейчас {cur.get('temperature_2m'):+.0f}°C (ощущается {cur.get('apparent_temperature'):+.0f}°), {CODES.get(cur.get('weather_code'), 'без осадков')}, "
           f"ветер {cur.get('wind_speed_10m', 0):.0f} км/ч, влажность {cur.get('relative_humidity_2m')}%"]
    d = w.get("daily") or {}
    for i, day in enumerate(d.get("time", [])[:days]):
        lab = "сегодня" if i == 0 else ("завтра" if i == 1 else day[5:].replace("-", "."))
        out.append(f"{lab}: {d['temperature_2m_min'][i]:+.0f}…{d['temperature_2m_max'][i]:+.0f}°C, {CODES.get(d['weather_code'][i], '')}, осадки {d['precipitation_probability_max'][i]}%")
    h = w.get("hourly") or {}
    if h.get("time"):
        now_h = int(time.strftime("%H"))
        pts = [f"{t[11:16]} {h['temperature_2m'][i]:+.0f}° {CODES.get(h['weather_code'][i], '')}" for i, t in enumerate(h["time"][:24]) if int(t[11:13]) in (max(now_h, 0), 12, 15, 18, 21) and int(t[11:13]) >= now_h]
        if pts:
            out.append("по часам сегодня: " + "; ".join(pts[:5]))
    val = "\n".join(out)
    _cache[key] = (time.time(), val)
    return val


async def rates(text: str) -> str | None:
    import aiohttp
    key = "rates"
    ts, val = _cache.get(key, (0, ""))
    if time.time() - ts < 1800:
        return val
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as s:
            async with s.get("https://www.cbr-xml-daily.ru/daily_json.js") as r:
                j = await r.json(content_type=None)
    except Exception as e:
        logging.warning("rates: %s", str(e)[:120])
        return None
    v = j.get("Valute") or {}
    want = ["USD", "EUR", "CNY", "AED", "KZT", "TRY", "GBP", "BYN", "UZS", "KGS"]
    lines = []
    for code in want:
        x = v.get(code)
        if not x:
            continue
        nominal = x.get("Nominal", 1)
        cur, prev = x["Value"] / nominal, x["Previous"] / nominal
        arrow = "↑" if cur > prev else ("↓" if cur < prev else "→")
        lines.append(f"{code}: {cur:.2f} ₽ ({arrow} {cur - prev:+.2f})")
    date = (j.get("Date") or "")[:10]
    val = f"КУРСЫ ЦБ РФ на {date} (официальные, обменники и биржа отличаются на 1–3%):\n" + "\n".join(lines)
    _cache[key] = (time.time(), val)
    return val


async def quick_facts(text: str) -> str | None:
    """Погода/курсы — если вопрос про них. Иначе None (пойдёт обычный веб-поиск)."""
    try:
        if WEATHER_RE.search(text):
            return await weather(text)
        if RATE_RE.search(text):
            return await rates(text)
    except Exception as e:
        logging.warning("quick_facts: %s", e)
    return None
