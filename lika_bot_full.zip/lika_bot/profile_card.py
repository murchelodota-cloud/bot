"""Розовая Y2K-карточка профиля для !кто я / !кто ты (matplotlib, без эмодзи — DejaVu их не рисует)."""
import io
from datetime import date, timedelta

PINK = "#ff5fa2"; PINK2 = "#ffb3d6"; PINK3 = "#ffe3f0"; INK = "#3a1f33"; MUTED = "#8a6a7e"; LILAC = "#c9a7ff"; WHITE = "white"


def _wrap(text: str, width: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width and cur:
            lines.append(cur); cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines


def draw(d: dict) -> bytes:
    """d: name, username, rank_name, rank, title, gender, city, birthday, mass, level, place, coins, msgs,
    joined, last_active, act (day, week, month), warns, duels (wins, losses, cowards), partners [names], crush (name, mutual),
    love_n, achievements [names], bio, series {iso_day: n}, avatar (bytes|None), chat_title, tg_admin."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.patches import FancyBboxPatch, Ellipse
    AR = 8.4 / 10  # фигура не квадратная — круги рисуем эллипсами

    def Circle(c, r, **kw):
        return Ellipse(c, 2 * r * AR, 2 * r, **kw)
    plt.rcParams["font.family"] = "DejaVu Sans"
    fig = plt.figure(figsize=(10, 8.4), dpi=150)
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    grad = np.linspace(0, 1, 256).reshape(1, -1)
    ax.imshow(grad, extent=[0, 1, 0, 1], aspect="auto", zorder=0,
              cmap=matplotlib.colors.LinearSegmentedColormap.from_list("p", ["#ffe3f0", "#fff6fb", "#f3e8ff"]))
    for (x, y, r) in [(0.05, 0.95, 0.03), (0.95, 0.05, 0.025), (0.92, 0.93, 0.012), (0.08, 0.06, 0.015)]:
        ax.add_patch(Circle((x, y), r, color=PINK2, alpha=0.55, zorder=1))

    def card(x, y, w, h, fc=WHITE, alpha=0.92):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.018",
                                    facecolor=fc, edgecolor=PINK2, linewidth=1.1, alpha=alpha, zorder=2))

    def txt(x, y, s, size=9, color=INK, ha="left", weight="normal", style="normal", va="center", z=5):
        ax.text(x, y, s, fontsize=size, color=color, ha=ha, va=va, fontweight=weight, style=style, zorder=z)

    # ---------- шапка ----------
    if d.get("vip"):
        ax.add_patch(FancyBboxPatch((0.04, 0.80), 0.92, 0.16, boxstyle="round,pad=0.006,rounding_size=0.018",
                                    facecolor="#fff7d6", edgecolor="#e6b800", linewidth=2.4, alpha=0.95, zorder=2))
        txt(0.94, 0.855, "★ VIP", 11, "#c99a00", ha="right", weight="bold")
    else:
        card(0.04, 0.80, 0.92, 0.16)
    ax_x = 0.075
    if d.get("avatar"):
        try:
            from PIL import Image, ImageDraw
            im = Image.open(io.BytesIO(d["avatar"])).convert("RGBA").resize((300, 300))
            mask = Image.new("L", (300, 300), 0); ImageDraw.Draw(mask).ellipse((0, 0, 299, 299), fill=255)
            im.putalpha(mask)
            aax = fig.add_axes([0.055, 0.815, 0.095, 0.13]); aax.axis("off")
            aax.imshow(im, zorder=6)
            ax.add_patch(Circle((0.1025, 0.88), 0.058, facecolor="none", edgecolor=PINK, linewidth=2.2, zorder=7,
                                transform=ax.transAxes))
            ax_x = 0.175
        except Exception:
            pass
    else:
        ax.add_patch(Circle((0.1025, 0.88), 0.055, facecolor=PINK3, edgecolor=PINK, linewidth=2, zorder=6))
        txt(0.1025, 0.88, (d["name"][:1] or "?").upper(), 22, PINK, ha="center", weight="bold", z=7)
        ax_x = 0.175
    txt(ax_x, 0.925, d["name"][:26], 19, PINK, weight="bold")
    sub = []
    if d.get("username"):
        sub.append("@" + d["username"])
    sub.append(f"ранг {d['rank']} · {d['rank_name']}")
    if d.get("tg_admin"):
        sub.append("админ чата")
    txt(ax_x, 0.885, "  ·  ".join(sub), 9.5, MUTED)
    extra = []
    if d.get("title"):
        extra.append(d["title"])
    if d.get("gender"):
        extra.append(d["gender"])
    if d.get("city"):
        extra.append(d["city"])
    if d.get("birthday"):
        extra.append("др " + d["birthday"])
    if extra:
        txt(ax_x, 0.848, "  ·  ".join(extra)[:80], 9.5, INK)
    txt(0.94, 0.925, "Саррочка", 11, LILAC, ha="right", style="italic")
    txt(0.94, 0.89, d.get("chat_title", "")[:30], 8.5, MUTED, ha="right")

    # ---------- плитки ----------
    kpi = [("масса", f"{int(d['mass'])}"), ("уровень", f"{d['level']}  ·  #{d['place']}"), ("сарра-коины", f"{d['coins']:,}".replace(",", " ")),
           ("сообщений", f"{d['msgs']:,}".replace(",", " ")), ("предов", str(d["warns"]))]
    n = len(kpi); gap = 0.012; w = (0.92 - gap * (n - 1)) / n
    for i, (lab, val) in enumerate(kpi):
        x = 0.04 + i * (w + gap)
        card(x, 0.685, w, 0.085, fc=(PINK3 if lab == "предов" and d["warns"] else WHITE))
        txt(x + w / 2, 0.742, val, 14, PINK if lab == "сарра-коины" else INK, ha="center", weight="bold")
        txt(x + w / 2, 0.705, lab, 8, MUTED, ha="center")

    # ---------- график ----------
    card(0.04, 0.40, 0.56, 0.27)
    txt(0.06, 0.645, "активность за год", 10, INK, weight="bold")
    today = date.today()
    days = [today - timedelta(days=i) for i in range(364, -1, -1)]
    vals = [d["series"].get(x.isoformat(), 0) for x in days]
    gax = fig.add_axes([0.07, 0.425, 0.50, 0.19]); gax.set_facecolor(WHITE)
    cols = [PINK if x >= today - timedelta(days=6) else ("#ff8ac0" if x >= today - timedelta(days=29) else PINK2) for x in days]
    gax.bar(range(365), vals, width=1.0, color=cols, linewidth=0, zorder=3)
    ticks = list(range(0, 365, 60))
    gax.set_xticks(ticks); gax.set_xticklabels([days[i].strftime("%d.%m") for i in ticks], fontsize=6.5, color=MUTED)
    gax.tick_params(axis="y", labelsize=6.5, colors=MUTED, length=0); gax.tick_params(axis="x", length=0)
    for sp in gax.spines.values():
        sp.set_visible(False)
    gax.grid(axis="y", color="#f1dbe8", linewidth=0.6, zorder=0); gax.set_axisbelow(True)

    # ---------- инфо справа ----------
    card(0.62, 0.40, 0.34, 0.27)
    txt(0.64, 0.645, "в чате", 10, INK, weight="bold")
    info = [("первое появление", d["joined"]), ("последний актив", d["last_active"]),
            ("актив д | н | м", f"{d['act']['day']} | {d['act']['week']} | {d['act']['month']}"),
            ("дуэли", f"{d['duels']['wins']} побед / {d['duels']['losses']} пораж." + (f" / {d['duels']['cowards']} отказ." if d["duels"]["cowards"] else "")
             if d["duels"]["wins"] or d["duels"]["losses"] or d["duels"]["cowards"] else "ещё не дрался"),
            ("люблю сарру", f"{d.get('love_n', 0)} раз" if d.get("love_n") else "ни разу. обидно.")]
    for i, (k, v) in enumerate(info):
        y = 0.608 - i * 0.042
        txt(0.64, y, k, 8, MUTED)
        txt(0.94, y, str(v)[:34], 9, INK, ha="right")

    # ---------- отношения ----------
    card(0.04, 0.215, 0.44, 0.165)
    txt(0.06, 0.355, "отношения", 10, INK, weight="bold")
    rel = []
    for p in d["partners"]:
        rel.append(f"в браке с {p}")
    if d.get("crush"):
        rel.append(f"влюблён(а) в {d['crush'][0]}" + (" — взаимно" if d["crush"][1] else ""))
    if not rel:
        rel = ["свободен(а). пока. я слежу."]
    for i, r in enumerate(rel[:5]):
        txt(0.06, 0.32 - i * 0.03, r[:46], 9, INK)

    # ---------- ачивки ----------
    card(0.50, 0.215, 0.46, 0.165)
    txt(0.52, 0.355, f"награды · {len(d['achievements'])}", 10, INK, weight="bold")
    x, y = 0.52, 0.318
    for a in d["achievements"][:14]:
        lab = a[:22]
        wch = 0.0068 * len(lab) + 0.018
        if x + wch > 0.95:
            x = 0.52; y -= 0.036
            if y < 0.225:
                break
        ax.add_patch(FancyBboxPatch((x, y - 0.012), wch, 0.024, boxstyle="round,pad=0.002,rounding_size=0.01",
                                    facecolor=PINK3, edgecolor=PINK2, linewidth=0.8, zorder=4))
        txt(x + wch / 2, y, lab, 7.5, INK, ha="center", z=5)
        x += wch + 0.008
    if not d["achievements"]:
        txt(0.52, 0.318, "пока нет. но я верю.", 9, MUTED)

    # ---------- описание ----------
    card(0.04, 0.05, 0.92, 0.13)
    txt(0.06, 0.158, "о себе", 10, INK, weight="bold")
    bio_lines = _wrap(d.get("bio") or "ничего не написал(а). загадочность — тоже позиция. +описание текст", 110)[:3]
    for i, l in enumerate(bio_lines):
        txt(0.06, 0.125 - i * 0.028, l, 8.8, INK if d.get("bio") else MUTED)
    txt(0.94, 0.02, "too pretty to argue. too smart to lose.", 7.5, MUTED, ha="right", style="italic")

    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=fig.get_facecolor())
    plt.close(fig)
    return buf.getvalue()
