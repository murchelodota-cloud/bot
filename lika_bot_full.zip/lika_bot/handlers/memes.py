"""Карточки-цитаты и мемы.
• !цитата (ответом) — розовая карточка с цитатой, аватаром и именем автора. Автоматически — когда сообщение собрало quote_reacts (5) смеющихся реакций.
• !мемни (ответом на фото) — мем: подпись сверху/снизу на картинке в стиле Саррочки (ИИ придумывает текст); !мемни текст — своя подпись.
• Опросы: !опрос вопрос | вариант 1 | вариант 2 … — Telegram-опрос от Саррочки; пульс тоже умеет создавать опрос по спорной теме."""
import asyncio
import html
import io
import logging
import textwrap
import time
from collections import defaultdict
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, BufferedInputFile, MessageReactionUpdated, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, InputSticker
from aiogram.exceptions import TelegramBadRequest
from db import db
from utils import reply, mention, style, split_args
from phrases import say

router = Router()
LAUGH = {"😂", "🤣", "💀", "🔥", "👏", "❤", "❤️", "🤡"}
_react_count: dict[tuple[int, int], set] = defaultdict(set)
_carded: set[tuple[int, int]] = set()


def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    import matplotlib
    import os
    base = os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data", "fonts", "ttf")
    path = os.path.join(base, "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def quote_card(text: str, author: str, sub: str, avatar: bytes | None) -> bytes:
    from PIL import Image, ImageDraw, ImageFilter
    W = 1080
    lines = []
    for para in text.split("\n"):
        lines += textwrap.wrap(para, 38) or [""]
    lines = lines[:14]
    H = 260 + len(lines) * 54 + 120
    img = Image.new("RGB", (W, H), "#ffe3f0")
    # градиент
    g = Image.new("RGB", (1, H))
    for y in range(H):
        t = y / H
        g.putpixel((0, y), (int(255 - 10 * t), int(227 + 20 * t), int(240 + 15 * t)))
    img.paste(g.resize((W, H)))
    d = ImageDraw.Draw(img)
    # карточка
    d.rounded_rectangle((40, 40, W - 40, H - 40), radius=48, fill=(255, 255, 255), outline=(255, 179, 214), width=4)
    d.text((70, 60), "“", font=_font(160, True), fill=(255, 95, 162))
    y = 170
    for ln in lines:
        d.text((90, y), ln, font=_font(40), fill=(58, 31, 51))
        y += 54
    # автор
    ay = H - 150
    if avatar:
        try:
            av = Image.open(io.BytesIO(avatar)).convert("RGB").resize((96, 96))
            mask = Image.new("L", (96, 96), 0); ImageDraw.Draw(mask).ellipse((0, 0, 95, 95), fill=255)
            img.paste(av, (90, ay), mask)
            d.ellipse((88, ay - 2, 188, ay + 98), outline=(255, 95, 162), width=4)
        except Exception:
            pass
    d.text((210, ay + 10), f"— {author}", font=_font(40, True), fill=(255, 95, 162))
    d.text((210, ay + 60), sub, font=_font(26), fill=(138, 106, 126))
    d.text((W - 90, H - 70), "Саррочка", font=_font(26), fill=(201, 167, 255), anchor="ra")
    buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()


def meme_image(photo: bytes, top: str, bottom: str) -> bytes:
    from PIL import Image, ImageDraw
    img = Image.open(io.BytesIO(photo)).convert("RGB")
    if img.width > 1280:
        img = img.resize((1280, int(img.height * 1280 / img.width)))
    d = ImageDraw.Draw(img)
    size = max(28, img.width // 14)
    f = _font(size, True)

    def draw_block(text, at_top):
        lines = textwrap.wrap(text.upper(), max(10, int(img.width / (size * 0.62))))[:3]
        y = 20 if at_top else img.height - 20 - len(lines) * (size + 8)
        for ln in lines:
            w = d.textlength(ln, font=f)
            x = (img.width - w) / 2
            for dx, dy in ((-3, -3), (3, -3), (-3, 3), (3, 3), (0, -3), (0, 3), (-3, 0), (3, 0)):
                d.text((x + dx, y + dy), ln, font=f, fill="black")
            d.text((x, y), ln, font=f, fill="white")
            y += size + 8
    if top:
        draw_block(top, True)
    if bottom:
        draw_block(bottom, False)
    buf = io.BytesIO(); img.save(buf, "JPEG", quality=90); return buf.getvalue()


async def _avatar(bot: Bot, uid: int) -> bytes | None:
    try:
        photos = await bot.get_user_profile_photos(uid, limit=1)
        if photos.total_count:
            f = await bot.get_file(photos.photos[0][-1].file_id)
            buf = io.BytesIO(); await bot.download_file(f.file_path, buf); return buf.getvalue()
    except Exception:
        pass
    return None


async def send_quote_card(bot: Bot, chat_id: int, r: Message, reply_to: Message | None = None):
    text = (r.text or r.caption or "").strip()
    if not text or r.from_user is None:
        return False
    row = await db.user(chat_id, r.from_user.id)
    author = ((row["nick"] or row["first_name"]) if row else None) or r.from_user.first_name
    sub = f"ЧВК «Сарра» · {time.strftime('%d.%m.%Y')}"
    avatar = await _avatar(bot, r.from_user.id)
    png = await asyncio.get_running_loop().run_in_executor(None, quote_card, text[:600], author, sub, avatar)
    cap = say(await style(chat_id), "quote_card", chat_id=chat_id, user=mention(r.from_user.id, author))
    sent = await bot.send_photo(chat_id, BufferedInputFile(png, "quote.png"), caption=cap, reply_to_message_id=r.message_id)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "quote", f"💬 цитата дня от {mention(r.from_user.id, author)}: «{html.escape(text[:80])}»")
    return True


@router.message(Command("цитата", "quote", "вцитаты", prefix="!+/"), F.reply_to_message)
async def cmd_quote(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if r.from_user and r.from_user.is_bot:
        return await reply(msg, "quote_bot")
    if not await send_quote_card(bot, msg.chat.id, r, msg):
        await reply(msg, "quote_fail")


async def on_reaction_count(event: MessageReactionUpdated, author: int | None):
    """Из обработчика реакций: 5 смеющихся/огненных реакций → карточка-цитата автоматически."""
    chat_id, mid = event.chat.id, event.message_id
    key = (chat_id, mid)
    if key in _carded or not author:
        return
    emojis = {getattr(r, "emoji", "") for r in event.new_reaction}
    if not (emojis & LAUGH):
        return
    _react_count[key].add(event.user.id)
    s = await db.settings(chat_id)
    if len(_react_count[key]) < int(s.get("quote_reacts", 5)) or not s.get("quote_auto", 1):
        return
    _carded.add(key)
    # текст сообщения — из журнала
    cur = await db.conn.execute("SELECT text, user_id FROM msg_log WHERE chat_id=? AND msg_id=?", (chat_id, mid))
    row = await cur.fetchone()
    if not row or not row["text"] or row["text"].startswith("[") or len(row["text"]) < 12:
        return
    u = await db.user(chat_id, row["user_id"])
    author_name = ((u["nick"] or u["first_name"]) if u else None) or "кто-то"
    png = await asyncio.get_running_loop().run_in_executor(None, quote_card, row["text"][:600], author_name, f"ЧВК «Сарра» · {time.strftime('%d.%m.%Y')}",
                                                           await _avatar(event.bot, row["user_id"]))
    cap = say(await style(chat_id), "quote_card_auto", chat_id=chat_id, user=mention(row["user_id"], author_name), n=len(_react_count[key]))
    sent = await event.bot.send_photo(chat_id, BufferedInputFile(png, "quote.png"), caption=cap, reply_to_message_id=mid)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "quote", f"💬 цитата дня (по реакциям) от {mention(row['user_id'], author_name)}: «{html.escape(row['text'][:80])}»")


@router.message(Command("мемни", "мем2", "memeit", prefix="!+/"), F.reply_to_message)
async def cmd_memeit(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if not r.photo:
        return await reply(msg, "meme_need_photo")
    custom = " ".join(split_args(msg)).strip()
    try:
        f = await bot.get_file(r.photo[-1].file_id)
        buf = io.BytesIO(); await bot.download_file(f.file_path, buf); data = buf.getvalue()
    except Exception:
        return await reply(msg, "senses_fail")
    top, bottom = "", ""
    if custom:
        parts = custom.split("|")
        top, bottom = (parts[0].strip(), parts[1].strip()) if len(parts) > 1 else ("", parts[0].strip())
    else:
        from handlers.ai import llm_json
        from persona import system_prompt
        desc = None
        try:
            from handlers.senses import describe
            desc = await describe(data, "Опиши картинку одним предложением по-русски: что на ней, кто, какое выражение лиц/настроение.")
        except Exception:
            pass
        from handlers.ai import context_block
        res = await llm_json([{"role": "system", "content": system_prompt(
            'Придумай подпись для мема: верхняя и нижняя строка, коротко (до 6 слов каждая), смешно, в твоём стиле, по ситуации в чате. Верни JSON {"top": "...", "bottom": "..."}', with_mood=False)},
            {"role": "user", "content": f"Картинка: {desc or 'неизвестно'}\nПодпись автора: {r.caption or '-'}\nКонтекст чата:\n{context_block(msg.chat.id, 8)}"}], max_tokens=80, temperature=1.0)
        if res:
            top, bottom = str(res.get("top", ""))[:60], str(res.get("bottom", ""))[:60]
    if not (top or bottom):
        return await reply(msg, "ai_off")
    jpg = await asyncio.get_running_loop().run_in_executor(None, meme_image, data, top, bottom)
    sent = await msg.answer_photo(BufferedInputFile(jpg, "meme.jpg"))
    await db.remember_bot_message(msg.chat.id, sent.message_id)


# ---------------- стикер-цитата «как в Telegram» (/q) ----------------
PALETTE = ["#e17076", "#7bc862", "#e5ca77", "#65aadd", "#a695e7", "#ee7aae", "#6ec9cb", "#faa774"]
_avatar_cache: dict[int, tuple[float, bytes | None]] = {}


async def _avatar_cached(bot: Bot, uid: int) -> bytes | None:
    ts, data = _avatar_cache.get(uid, (0, None))
    if time.time() - ts < 6 * 3600:
        return data
    data = await _avatar(bot, uid)
    _avatar_cache[uid] = (time.time(), data)
    return data


def tg_quote_sticker(items: list[dict], dark: bool = True) -> bytes:
    """items: [{name, text, avatar(bytes|None), uid}] → webp 512px, прозрачный фон, пузыри как в Telegram (крупно, как QuotLy)."""
    from PIL import Image, ImageDraw
    S = 2                      # рисуем в 2x и уменьшаем до 512 — текст чётче
    W = 512 * S
    f_name, f_text = _font(34 * S // 2 + 8, True), _font(34 * S // 2 + 8)
    PAD, AV, GAP, R, LH = 24 * S // 2 + 6, 72 * S // 2 + 12, 16, 34, 46 * S // 2 + 6
    bg = (33, 33, 33, 255) if dark else (255, 255, 255, 255)
    fg = (255, 255, 255, 255) if dark else (20, 20, 20, 255)
    probe_d = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    maxw = int((W - AV - GAP - PAD * 2 - 16) * 0.8)
    blocks = []
    for it in items:
        lines = []
        for para in (it["text"] or "").split("\n"):
            cur = ""
            for w in para.split():
                probe = (cur + " " + w).strip()
                if probe_d.textlength(probe, font=f_text) > maxw - PAD * 2 and cur:
                    lines.append(cur); cur = w
                else:
                    cur = probe
            lines.append(cur)
        lines = lines[:10]
        h = PAD + int(LH * 1.05) + len(lines) * LH + PAD
        blocks.append((it, lines, h))
    H = sum(h for _, _, h in blocks) + GAP * (len(blocks) - 1) + 16
    img = Image.new("RGBA", (W, max(H, AV + 16)), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = 8
    for it, lines, h in blocks:
        ax, ay = 8, y + h - AV
        if it.get("avatar"):
            try:
                av = Image.open(io.BytesIO(it["avatar"])).convert("RGBA").resize((AV, AV))
                mask = Image.new("L", (AV, AV), 0); ImageDraw.Draw(mask).ellipse((0, 0, AV - 1, AV - 1), fill=255)
                img.paste(av, (ax, ay), mask)
            except Exception:
                it["avatar"] = None
        if not it.get("avatar"):
            col = PALETTE[abs(int(it.get("uid") or 0)) % len(PALETTE)]
            d.ellipse((ax, ay, ax + AV, ay + AV), fill=col)
            d.text((ax + AV / 2, ay + AV / 2), (it["name"][:1] or "?").upper(), font=_font(AV // 2, True), fill="white", anchor="mm")
        bx = ax + AV + GAP
        bw = min(W - bx - 8, max(probe_d.textlength(it["name"][:28], font=f_name), *(probe_d.textlength(l, font=f_text) for l in lines)) + PAD * 2)
        bw = max(bw, int(W * 0.45))   # пузырь не уже половины ширины — иначе стикер выглядит крошечным
        d.rounded_rectangle((bx, y, bx + bw, y + h), radius=R, fill=bg)
        d.polygon([(bx + 4, y + h - 26), (bx - 16, y + h - 4), (bx + 26, y + h - 4)], fill=bg)
        col = PALETTE[abs(int(it.get("uid") or 0)) % len(PALETTE)]
        d.text((bx + PAD, y + PAD - 4), it["name"][:28], font=f_name, fill=col)
        ty = y + PAD + int(LH * 1.05)
        for ln in lines:
            d.text((bx + PAD, ty), ln, font=f_text, fill=fg)
            ty += LH
        y += h + GAP
    # обрезаем пустое место справа и дотягиваем высоту: короткая цитата иначе выглядит узкой полоской
    bbox = img.getbbox()
    if bbox:
        img = img.crop((0, 0, min(W, bbox[2] + 8), img.height))
    min_h = int(img.width * 0.55)
    if img.height < min_h:
        pad = Image.new("RGBA", (img.width, min_h), (0, 0, 0, 0))
        pad.paste(img, (0, min_h - img.height))
        img = pad
    # стикер: большая сторона 512
    scale = 512 / max(img.width, img.height)
    img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.LANCZOS)
    buf = io.BytesIO(); img.save(buf, "WEBP", quality=95); return buf.getvalue()


@router.message(Command("q", "к", "цитировать", "qs", prefix="/!+"), F.reply_to_message)
async def cmd_q(msg: Message, bot: Bot):
    """/q [N] ответом — стикер-цитата из N сообщений подряд, начиная с этого (как QuotLy). /q light — светлая тема."""
    args = [a.lower() for a in split_args(msg)]
    n = next((int(a) for a in args if a.isdigit()), 1)
    n = max(1, min(n, 10))
    dark = "light" not in args and "светл" not in " ".join(args)
    r = msg.reply_to_message
    rows = await db.messages_from(msg.chat.id, r.message_id, n)
    items = []
    if not rows:
        if r.from_user and (r.text or r.caption):
            items = [{"uid": r.from_user.id, "name": r.from_user.first_name, "text": (r.text or r.caption), "avatar": await _avatar_cached(bot, r.from_user.id)}]
    else:
        for row in rows:
            text = row["text"] or ""
            if not text or text.startswith("[фото") or text.startswith("[голосовое") or text.startswith("[кружок"):
                text = text or "[медиа]"
            items.append({"uid": row["user_id"], "name": (row["nick"] or row["first_name"] or "кто-то"), "text": text[:400],
                          "avatar": await _avatar_cached(bot, row["user_id"])})
    if not items:
        return await reply(msg, "quote_fail")
    webp = await asyncio.get_running_loop().run_in_executor(None, tg_quote_sticker, items, dark)
    s = await db.settings(msg.chat.id)
    kb = None if s.get("q_autopack", 1) else InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="➕ в стикерпак чата", callback_data="qpack:add")]])
    sent = await msg.answer_sticker(BufferedInputFile(webp, "quote.webp"), reply_markup=kb)
    await db.remember_bot_message(msg.chat.id, sent.message_id)
    if s.get("q_autopack", 1):
        asyncio.create_task(_autopack(bot, msg, sent.sticker.file_id, s))
    try:
        await msg.delete()
    except Exception:
        pass


async def _autopack(bot: Bot, msg: Message, file_id: str, s: dict):
    """Тихо добавить в пак; при первом создании — одно сообщение со ссылкой."""
    try:
        link = await add_to_pack(bot, msg.chat.id, file_id, msg.from_user.id)
    except Exception as e:
        logging.warning("autopack: %s", e)
        return
    if link and not s.get("q_pack_announced"):
        await db.set_setting(msg.chat.id, "q_pack_announced", 1)
        sent = await msg.answer(say(await style(msg.chat.id), "qpack_created", chat_id=msg.chat.id, link=link))
        await db.remember_bot_message(msg.chat.id, sent.message_id)


def pack_name(bot_username: str, chat_id: int) -> str:
    return f"sarra_quotes_{abs(chat_id)}_by_{bot_username}"


async def add_to_pack(bot: Bot, chat_id: int, file_id: str, by_user: int) -> str | None:
    """Добавить стикер в стикерпак чата; если пака нет — создать (владелец — создатель чата, иначе нажавший). Возвращает ссылку."""
    me = await bot.get_me()
    name = pack_name(me.username, chat_id)
    s = await db.settings(chat_id)
    chat = await bot.get_chat(chat_id)
    title = f"{(chat.title or 'чат')[:40]} · цитаты"
    sticker = InputSticker(sticker=file_id, format="static", emoji_list=["💬"])
    exists = bool(s.get("sticker_set"))
    if not exists:
        try:
            await bot.get_sticker_set(name)
            exists = True
        except TelegramBadRequest:
            exists = False
    if exists:
        try:
            await bot.add_sticker_to_set(user_id=int(s.get("sticker_owner") or by_user), name=name, sticker=sticker)
        except TelegramBadRequest as e:
            if "STICKERSET_INVALID" in str(e) or "not found" in str(e).lower():
                exists = False
            else:
                logging.warning("add sticker: %s", e)
                return None
    if not exists:
        from utils import chat_creator
        from config import OWNER_IDS
        candidates = [c for c in [(await chat_creator(bot, chat_id))[0], by_user, *sorted(OWNER_IDS)] if c]
        created = False
        for owner in candidates:
            try:
                await bot.create_new_sticker_set(user_id=owner, name=name, title=title[:64], stickers=[sticker])
                await db.set_setting(chat_id, "sticker_owner", owner)
                created = True
                break
            except TelegramBadRequest as e:
                logging.warning("create sticker set (owner %s): %s", owner, e)
        if not created:
            return None
        await db.set_setting(chat_id, "sticker_set", name)
    return f"https://t.me/addstickers/{name}"


@router.callback_query(F.data == "qpack:add")
async def on_qpack(cb: CallbackQuery, bot: Bot):
    st = cb.message.sticker
    if not st:
        return await cb.answer("стикер не найден.", show_alert=True)
    link = await add_to_pack(bot, cb.message.chat.id, st.file_id, cb.from_user.id)
    if not link:
        return await cb.answer("не вышло добавить: владелец пака должен хотя бы раз написать мне в личку /start.", show_alert=True)
    try:
        await cb.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📦 открыть стикерпак", url=link)]]))
    except TelegramBadRequest:
        pass
    await cb.answer("добавила в стикерпак чата 💬")


@router.message(Command("стикерпак", "stickers", "pack", prefix="!/"))
async def cmd_pack(msg: Message, bot: Bot):
    s = await db.settings(msg.chat.id)
    if not s.get("sticker_set"):
        return await reply(msg, "qpack_none")
    await reply(msg, "qpack_link", link=f"https://t.me/addstickers/{s['sticker_set']}")


# ---------------- опросы ----------------
async def make_poll(bot: Bot, chat_id: int, question: str, options: list[str], anonymous: bool = True, reply_to: int | None = None):
    options = [o.strip()[:100] for o in options if o.strip()][:10]
    if len(options) < 2:
        return None
    sent = await bot.send_poll(chat_id, question[:300], options, is_anonymous=anonymous, reply_to_message_id=reply_to)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "poll", f"📊 опрос: {html.escape(question[:80])}")
    return sent


@router.message(Command("опрос", "poll", prefix="!+/"))
async def cmd_poll(msg: Message, bot: Bot):
    raw = " ".join(split_args(msg))
    if "|" not in raw:
        return await reply(msg, "poll_usage")
    q, *opts = [p.strip() for p in raw.split("|")]
    if len(opts) < 2:
        return await reply(msg, "poll_usage")
    if not await make_poll(bot, msg.chat.id, q, opts, anonymous=False, reply_to=msg.message_id):
        await reply(msg, "poll_usage")
