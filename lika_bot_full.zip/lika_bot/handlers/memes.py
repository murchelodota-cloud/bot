"""Карточки-цитаты и мемы.
• !цитата (ответом) — розовая карточка с цитатой, аватаром и именем автора. Автоматически — когда сообщение собрало quote_reacts (5) смеющихся реакций.
• !мемни (ответом на фото) — мем: подпись сверху/снизу на картинке в стиле Саррочки (ИИ придумывает текст); !мемни текст — своя подпись.
• Опросы: !опрос вопрос | вариант 1 | вариант 2 … — Telegram-опрос от Саррочки; пульс тоже умеет создавать опрос по спорной теме."""
import asyncio
import html
import io
import logging
import textwrap
import time
from collections import defaultdict
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, BufferedInputFile, MessageReactionUpdated
from db import db
from utils import reply, mention, style, split_args
from phrases import say

router = Router()
LAUGH = {"😂", "🤣", "💀", "🔥", "👏", "❤", "❤️", "🤡"}
_react_count: dict[tuple[int, int], set] = defaultdict(set)
_carded: set[tuple[int, int]] = set()


def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    import matplotlib
    import os
    base = os.path.join(os.path.dirname(matplotlib.__file__), "mpl-data", "fonts", "ttf")
    path = os.path.join(base, "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def quote_card(text: str, author: str, sub: str, avatar: bytes | None) -> bytes:
    from PIL import Image, ImageDraw, ImageFilter
    W = 1080
    lines = []
    for para in text.split("\n"):
        lines += textwrap.wrap(para, 38) or [""]
    lines = lines[:14]
    H = 260 + len(lines) * 54 + 120
    img = Image.new("RGB", (W, H), "#ffe3f0")
    # градиент
    g = Image.new("RGB", (1, H))
    for y in range(H):
        t = y / H
        g.putpixel((0, y), (int(255 - 10 * t), int(227 + 20 * t), int(240 + 15 * t)))
    img.paste(g.resize((W, H)))
    d = ImageDraw.Draw(img)
    # карточка
    d.rounded_rectangle((40, 40, W - 40, H - 40), radius=48, fill=(255, 255, 255), outline=(255, 179, 214), width=4)
    d.text((70, 60), "“", font=_font(160, True), fill=(255, 95, 162))
    y = 170
    for ln in lines:
        d.text((90, y), ln, font=_font(40), fill=(58, 31, 51))
        y += 54
    # автор
    ay = H - 150
    if avatar:
        try:
            av = Image.open(io.BytesIO(avatar)).convert("RGB").resize((96, 96))
            mask = Image.new("L", (96, 96), 0); ImageDraw.Draw(mask).ellipse((0, 0, 95, 95), fill=255)
            img.paste(av, (90, ay), mask)
            d.ellipse((88, ay - 2, 188, ay + 98), outline=(255, 95, 162), width=4)
        except Exception:
            pass
    d.text((210, ay + 10), f"— {author}", font=_font(40, True), fill=(255, 95, 162))
    d.text((210, ay + 60), sub, font=_font(26), fill=(138, 106, 126))
    d.text((W - 90, H - 70), "Саррочка", font=_font(26), fill=(201, 167, 255), anchor="ra")
    buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()


def meme_image(photo: bytes, top: str, bottom: str) -> bytes:
    from PIL import Image, ImageDraw
    img = Image.open(io.BytesIO(photo)).convert("RGB")
    if img.width > 1280:
        img = img.resize((1280, int(img.height * 1280 / img.width)))
    d = ImageDraw.Draw(img)
    size = max(28, img.width // 14)
    f = _font(size, True)

    def draw_block(text, at_top):
        lines = textwrap.wrap(text.upper(), max(10, int(img.width / (size * 0.62))))[:3]
        y = 20 if at_top else img.height - 20 - len(lines) * (size + 8)
        for ln in lines:
            w = d.textlength(ln, font=f)
            x = (img.width - w) / 2
            for dx, dy in ((-3, -3), (3, -3), (-3, 3), (3, 3), (0, -3), (0, 3), (-3, 0), (3, 0)):
                d.text((x + dx, y + dy), ln, font=f, fill="black")
            d.text((x, y), ln, font=f, fill="white")
            y += size + 8
    if top:
        draw_block(top, True)
    if bottom:
        draw_block(bottom, False)
    buf = io.BytesIO(); img.save(buf, "JPEG", quality=90); return buf.getvalue()


async def _avatar(bot: Bot, uid: int) -> bytes | None:
    try:
        photos = await bot.get_user_profile_photos(uid, limit=1)
        if photos.total_count:
            f = await bot.get_file(photos.photos[0][-1].file_id)
            buf = io.BytesIO(); await bot.download_file(f.file_path, buf); return buf.getvalue()
    except Exception:
        pass
    return None


async def send_quote_card(bot: Bot, chat_id: int, r: Message, reply_to: Message | None = None):
    text = (r.text or r.caption or "").strip()
    if not text or r.from_user is None:
        return False
    row = await db.user(chat_id, r.from_user.id)
    author = ((row["nick"] or row["first_name"]) if row else None) or r.from_user.first_name
    sub = f"ЧВК «Сарра» · {time.strftime('%d.%m.%Y')}"
    avatar = await _avatar(bot, r.from_user.id)
    png = await asyncio.get_running_loop().run_in_executor(None, quote_card, text[:600], author, sub, avatar)
    cap = say(await style(chat_id), "quote_card", chat_id=chat_id, user=mention(r.from_user.id, author))
    sent = await bot.send_photo(chat_id, BufferedInputFile(png, "quote.png"), caption=cap, reply_to_message_id=r.message_id)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "quote", f"💬 цитата дня от {mention(r.from_user.id, author)}: «{html.escape(text[:80])}»")
    return True


@router.message(Command("цитата", "quote", "вцитаты", prefix="!+/"), F.reply_to_message)
async def cmd_quote(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if r.from_user and r.from_user.is_bot:
        return await reply(msg, "quote_bot")
    if not await send_quote_card(bot, msg.chat.id, r, msg):
        await reply(msg, "quote_fail")


async def on_reaction_count(event: MessageReactionUpdated, author: int | None):
    """Из обработчика реакций: 5 смеющихся/огненных реакций → карточка-цитата автоматически."""
    chat_id, mid = event.chat.id, event.message_id
    key = (chat_id, mid)
    if key in _carded or not author:
        return
    emojis = {getattr(r, "emoji", "") for r in event.new_reaction}
    if not (emojis & LAUGH):
        return
    _react_count[key].add(event.user.id)
    s = await db.settings(chat_id)
    if len(_react_count[key]) < int(s.get("quote_reacts", 5)) or not s.get("quote_auto", 1):
        return
    _carded.add(key)
    # текст сообщения — из журнала
    cur = await db.conn.execute("SELECT text, user_id FROM msg_log WHERE chat_id=? AND msg_id=?", (chat_id, mid))
    row = await cur.fetchone()
    if not row or not row["text"] or row["text"].startswith("[") or len(row["text"]) < 12:
        return
    u = await db.user(chat_id, row["user_id"])
    author_name = ((u["nick"] or u["first_name"]) if u else None) or "кто-то"
    png = await asyncio.get_running_loop().run_in_executor(None, quote_card, row["text"][:600], author_name, f"ЧВК «Сарра» · {time.strftime('%d.%m.%Y')}",
                                                           await _avatar(event.bot, row["user_id"]))
    cap = say(await style(chat_id), "quote_card_auto", chat_id=chat_id, user=mention(row["user_id"], author_name), n=len(_react_count[key]))
    sent = await event.bot.send_photo(chat_id, BufferedInputFile(png, "quote.png"), caption=cap, reply_to_message_id=mid)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "quote", f"💬 цитата дня (по реакциям) от {mention(row['user_id'], author_name)}: «{html.escape(row['text'][:80])}»")


@router.message(Command("мемни", "мем2", "memeit", prefix="!+/"), F.reply_to_message)
async def cmd_memeit(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if not r.photo:
        return await reply(msg, "meme_need_photo")
    custom = " ".join(split_args(msg)).strip()
    try:
        f = await bot.get_file(r.photo[-1].file_id)
        buf = io.BytesIO(); await bot.download_file(f.file_path, buf); data = buf.getvalue()
    except Exception:
        return await reply(msg, "senses_fail")
    top, bottom = "", ""
    if custom:
        parts = custom.split("|")
        top, bottom = (parts[0].strip(), parts[1].strip()) if len(parts) > 1 else ("", parts[0].strip())
    else:
        from handlers.ai import llm_json
        from persona import system_prompt
        desc = None
        try:
            from handlers.senses import describe
            desc = await describe(data, "Опиши картинку одним предложением по-русски: что на ней, кто, какое выражение лиц/настроение.")
        except Exception:
            pass
        from handlers.ai import context_block
        res = await llm_json([{"role": "system", "content": system_prompt(
            'Придумай подпись для мема: верхняя и нижняя строка, коротко (до 6 слов каждая), смешно, в твоём стиле, по ситуации в чате. Верни JSON {"top": "...", "bottom": "..."}', with_mood=False)},
            {"role": "user", "content": f"Картинка: {desc or 'неизвестно'}\nПодпись автора: {r.caption or '-'}\nКонтекст чата:\n{context_block(msg.chat.id, 8)}"}], max_tokens=80, temperature=1.0)
        if res:
            top, bottom = str(res.get("top", ""))[:60], str(res.get("bottom", ""))[:60]
    if not (top or bottom):
        return await reply(msg, "ai_off")
    jpg = await asyncio.get_running_loop().run_in_executor(None, meme_image, data, top, bottom)
    sent = await msg.answer_photo(BufferedInputFile(jpg, "meme.jpg"))
    await db.remember_bot_message(msg.chat.id, sent.message_id)


# ---------------- опросы ----------------
async def make_poll(bot: Bot, chat_id: int, question: str, options: list[str], anonymous: bool = True, reply_to: int | None = None):
    options = [o.strip()[:100] for o in options if o.strip()][:10]
    if len(options) < 2:
        return None
    sent = await bot.send_poll(chat_id, question[:300], options, is_anonymous=anonymous, reply_to_message_id=reply_to)
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "poll", f"📊 опрос: {html.escape(question[:80])}")
    return sent


@router.message(Command("опрос", "poll", prefix="!+/"))
async def cmd_poll(msg: Message, bot: Bot):
    raw = " ".join(split_args(msg))
    if "|" not in raw:
        return await reply(msg, "poll_usage")
    q, *opts = [p.strip() for p in raw.split("|")]
    if len(opts) < 2:
        return await reply(msg, "poll_usage")
    if not await make_poll(bot, msg.chat.id, q, opts, anonymous=False, reply_to=msg.message_id):
        await reply(msg, "poll_usage")
