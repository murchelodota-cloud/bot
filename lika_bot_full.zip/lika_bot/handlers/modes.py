"""Режимы поведения: !режим ночь | праздник | траур | строгий | хаос | обычный (ст. админ). Меняет тон всех ИИ-реплик,
в режиме «траур» выключаются игры, болтовня, пульс-инициативы, номинации и прожарки; в «ночь» — игры и болтовня. !режим — текущий."""
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, deny, split_args
from persona import MODES, set_mode, get_mode

router = Router()
OFF_IN = {"траур": ["games", "chatter", "quotes_every", "nominations", "story", "roast"], "ночь": ["games", "chatter"]}


async def load_modes():
    for chat_id in await db.all_chats():
        s = await db.settings(chat_id)
        if s.get("mode"):
            set_mode(chat_id, s["mode"])


def allowed(chat_id: int, feature: str) -> bool:
    return feature not in OFF_IN.get(get_mode(chat_id), [])


@router.message(Command("режим", "mode", prefix="!/"))
async def cmd_mode(msg: Message, bot: Bot):
    args = [a.lower() for a in split_args(msg)]
    if not args:
        return await reply(msg, "mode_current", mode=get_mode(msg.chat.id), list=" · ".join(MODES))
    if await deny(msg, bot, "settings"):
        return
    m = args[0]
    if m not in MODES:
        return await reply(msg, "mode_unknown", list=" · ".join(MODES))
    set_mode(msg.chat.id, m)
    await db.set_setting(msg.chat.id, "mode", m)
    await reply(msg, f"mode_{m}" if f"mode_{m}" else "mode_set", mode=m)
