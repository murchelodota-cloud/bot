"""Память о людях: Саррочка извлекает из переписки устойчивые факты («из Москвы», «возит машины из Китая», «есть кот»)
и использует их в диалоге, разборе, прожарке и играх. !факты [@юзер] — что она помнит; +факт @юзер текст — добавить (ст. админ);
-факт номер — удалить; !забудь меня — стереть всё о себе. Настройка: memory (1/0), memory_every (40 сообщений)."""
import html
import time
from collections import defaultdict
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, resolve_target, split_args, deny

router = Router()
_counter: dict[int, int] = defaultdict(int)
_buffer: dict[int, list] = defaultdict(list)   # chat_id -> [(uid, name, text)]


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


async def facts_line(chat_id: int, uid: int, limit: int = 12) -> str:
    """Строка фактов для промптов: «известно о нём: …» или пусто."""
    rows = await db.user_facts(chat_id, uid, limit)
    if not rows:
        return ""
    return "Что ты уже знаешь об этом человеке из прошлых разговоров: " + "; ".join(r["fact"] for r in rows) + "."


async def observe(msg: Message, bot: Bot):
    """Из middleware: копим сообщения, раз в memory_every просим модель вытащить факты."""
    text = (msg.text or msg.caption or "").strip()
    if not text or text.startswith(("/", "!", "+", "-")) or len(text) < 12:
        return
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    if not s.get("memory", 1):
        return
    from config import LLM_API_KEY
    if not LLM_API_KEY:
        return
    row = await db.user(chat_id, msg.from_user.id)
    name = (row["nick"] or row["first_name"]) if row else msg.from_user.first_name
    _buffer[chat_id].append((msg.from_user.id, name, text[:300]))
    _counter[chat_id] += 1
    if _counter[chat_id] < int(s.get("memory_every", 40)):
        return
    _counter[chat_id] = 0
    batch, _buffer[chat_id] = _buffer[chat_id][-80:], []
    await extract(chat_id, batch)


async def extract(chat_id: int, batch: list):
    from handlers.ai import llm_json
    users = {}
    for uid, name, _ in batch:
        users[uid] = name
    known = {}
    for uid in users:
        known[uid] = [r["fact"] for r in await db.user_facts(chat_id, uid, 20)]
    sample = "\n".join(f"[{uid}] {name}: {t}" for uid, name, t in batch)
    known_txt = "\n".join(f"[{uid}] {users[uid]}: {'; '.join(f) or '-'}" for uid, f in known.items())
    res = await llm_json([
        {"role": "system", "content":
            "Ты ведёшь память о людях для бота чата. Из сообщений вытащи УСТОЙЧИВЫЕ факты о самих авторах, которые пригодятся в будущих разговорах: "
            "город, работа/учёба, чем занимается, хобби, питомцы, машина, семья (в общих словах), что любит/не любит, привычки, достижения, планы, "
            "характерные выражения. Только то, что человек сказал О СЕБЕ прямо (не шутки, не о других, не сиюминутное «иду спать»). "
            "НЕ сохраняй: здоровье и диагнозы, религию, национальность, политику, ориентацию, деньги и долги, адреса, телефоны, конфликты и обиды. "
            "Уже известное не повторяй. Формулируй коротко, в третьем лице, без имени: «живёт в Москве», «возит машины из Китая», «есть кот Барсик». "
            "ОТДЕЛЬНО — открытые нити: обещания и планы, к которым можно вернуться через день-два («обещал скинуть фото гелика», «с понедельника бросает курить», "
            "«едет в Дубай в пятницу», «поспорил, что …»). Только явные, от первого лица, с действием в будущем. "
            'Верни JSON: {"facts": {"<id>": ["факт", ...]}, "threads": [{"id": <id>, "text": "что обещал/планирует", "due": "ГГГГ-ММ-ДД или null"}]}. Если ничего нет — {"facts": {}, "threads": []}.'},
        {"role": "user", "content": f"Сегодня {time.strftime('%Y-%m-%d, %A')}. Уже известно:\n{known_txt}\n\nСообщения:\n{sample}"}], max_tokens=500, temperature=0.2)
    if not isinstance(res, dict):
        return
    facts_map = res.get("facts") if isinstance(res.get("facts"), dict) else {k: v for k, v in res.items() if k != "threads"}
    for k, facts in (facts_map or {}).items():
        try:
            uid = int(k)
        except (TypeError, ValueError):
            continue
        if uid not in users or not isinstance(facts, list):
            continue
        for f in facts[:4]:
            if isinstance(f, str) and 3 < len(f) < 160:
                await db.add_fact(chat_id, uid, f)
    for th in (res.get("threads") or [])[:5]:
        try:
            uid = int(th.get("id"))
        except (TypeError, ValueError, AttributeError):
            continue
        text = str(th.get("text") or "").strip()
        if uid in users and 5 < len(text) < 160:
            due = th.get("due") if isinstance(th.get("due"), str) and len(th.get("due")) == 10 else None
            await db.thread_add(chat_id, uid, text, due)


@router.message(Command("факты", "память", "facts", prefix="!+/"))
async def cmd_facts(msg: Message, bot: Bot):
    uid, name, _ = await resolve_target(msg)
    if not uid:
        uid, name = msg.from_user.id, msg.from_user.first_name
    rows = await db.user_facts(msg.chat.id, uid, 25)
    who = await nm(msg.chat.id, uid, name)
    if not rows:
        return await reply(msg, "facts_empty", user=who)
    lines = [f"#{r['id']} · {html.escape(r['fact'])}" + (" ✍️" if r["src"] != "ai" else "") for r in rows]
    await reply(msg, "facts_list", user=who, list="\n".join(lines))


@router.message(Command("факт", "fact", prefix="+"))
async def cmd_fact_add(msg: Message, bot: Bot):
    """+факт @юзер текст (или ответом) — ст. админ."""
    if await deny(msg, bot, "settings"):
        return
    uid, name, rest = await resolve_target(msg)
    text = " ".join(rest).strip()
    if not uid or len(text) < 3:
        return await reply(msg, "fact_usage")
    ok = await db.add_fact(msg.chat.id, uid, text, src=f"admin:{msg.from_user.id}")
    await reply(msg, "fact_added" if ok else "fact_dup", user=await nm(msg.chat.id, uid, name), fact=html.escape(text[:200]))


@router.message(Command("факт", "fact", prefix="-"))
async def cmd_fact_del(msg: Message, bot: Bot):
    """-факт 12 — удалить по номеру (ст. админ или сам человек, о ком факт)."""
    args = split_args(msg)
    if not args or not args[0].lstrip("#").isdigit():
        return await reply(msg, "fact_usage")
    fid = int(args[0].lstrip("#"))
    from utils import has_rank
    cur = await db.conn.execute("SELECT user_id FROM user_facts WHERE chat_id=? AND id=?", (msg.chat.id, fid))
    row = await cur.fetchone()
    if not row:
        return await reply(msg, "fact_none")
    if row["user_id"] != msg.from_user.id and not await has_rank(bot, msg.chat.id, msg.from_user.id, "settings"):
        return await reply(msg, "fact_denied")
    await db.del_fact(msg.chat.id, fid)
    await reply(msg, "fact_removed", id=fid)


@router.message(Command("забудьменя", "забудь", "forgetme", prefix="!+/"))
async def cmd_forget(msg: Message):
    await db.clear_facts(msg.chat.id, msg.from_user.id)
    await reply(msg, "facts_cleared", user=await nm(msg.chat.id, msg.from_user.id, msg.from_user.first_name))
