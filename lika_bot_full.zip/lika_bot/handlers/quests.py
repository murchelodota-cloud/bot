"""Квесты дня: в quest_hour (12) Саррочка выдаёт 3 задания на день; выполнение считается автоматически,
награда (quest_prize, 15 🪙) начисляется сразу и тихо, вечером в итогах дня — кто что выполнил. !квесты — задания и свой прогресс."""
import json
import random
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, style
from phrases import say

router = Router()
# key: (описание, цель, как считается)
POOL = {
    "msgs30": ("написать 30 осмысленных сообщений", 30),
    "reply5": ("ответить пятерым разным людям", 5),
    "compliment": ("сделать два комплимента", 2),
    "react5": ("поставить 5 реакций другим", 5),
    "got_react": ("собрать 5 реакций на свои сообщения", 5),
    "thanks": ("сказать Саррочке спасибо", 1),
    "duel_win": ("выиграть дуэль", 1),
    "game": ("поучаствовать в игре", 1),
    "love": ("признаться Саррочке в любви", 1),
    "newbie": ("поздороваться с новичком (ответить ему)", 1),
    "photo": ("скинуть фото", 1),
    "night_silence": ("не писать с 2:00 до 7:00", 1),
}
_prog: dict[tuple[int, str, int], dict] = {}        # (chat, day, uid) -> {key: n}
_reply_targets: dict[tuple[int, str, int], set] = {}
_done: dict[tuple[int, str, int], set] = {}


def today() -> str:
    return time.strftime("%Y-%m-%d")


async def active(chat_id: int) -> list[str]:
    s = await db.settings(chat_id)
    try:
        q = json.loads(s.get("quests_today") or "{}")
    except Exception:
        q = {}
    return q.get("keys", []) if q.get("day") == today() else []


async def bump(chat_id: int, uid: int, key: str, n: int = 1, bot: Bot | None = None):
    keys = await active(chat_id)
    if key not in keys:
        return
    k = (chat_id, today(), uid)
    p = _prog.setdefault(k, {})
    p[key] = p.get(key, 0) + n
    if p[key] >= POOL[key][1] and key not in _done.setdefault(k, set()):
        _done[k].add(key)
        s = await db.settings(chat_id)
        prize = int(s.get("quest_prize", 15))
        await db.give_coin(chat_id, 0, uid, f"квест: {POOL[key][0]}", prize)
        await db.log_event(chat_id, "quest", f"✅ {mention(uid, (await db.user(chat_id, uid) or {'first_name': 'кто-то'})['first_name'])} выполнил(а) квест «{POOL[key][0]}» (+{prize} 🪙)")


async def track(msg: Message, counted: bool):
    """Из middleware: сообщения, ответы, комплименты, фото, приветствие новичка."""
    chat_id, uid = msg.chat.id, msg.from_user.id
    if not await active(chat_id):
        return
    if counted:
        await bump(chat_id, uid, "msgs30")
    text = msg.text or msg.caption or ""
    if msg.photo:
        await bump(chat_id, uid, "photo")
    if msg.reply_to_message and msg.reply_to_message.from_user and not msg.reply_to_message.from_user.is_bot \
            and msg.reply_to_message.from_user.id != uid:
        tgt = msg.reply_to_message.from_user.id
        k = (chat_id, today(), uid)
        st = _reply_targets.setdefault(k, set())
        if tgt not in st:
            st.add(tgt)
            await bump(chat_id, uid, "reply5")
        row = await db.user(chat_id, tgt)
        if row and row["joined_at"] and time.time() - row["joined_at"] < 86400:
            await bump(chat_id, uid, "newbie")
    from handlers.nominations import SIMP_RE
    if msg.reply_to_message and SIMP_RE.search(text):
        await bump(chat_id, uid, "compliment")


async def post_quests(bot: Bot, chat_id: int, force: bool = False):
    s = await db.settings(chat_id)
    if not s.get("quests", 1):
        return
    try:
        q = json.loads(s.get("quests_today") or "{}")
    except Exception:
        q = {}
    if not force and q.get("day") == today():
        return
    hour = time.localtime().tm_hour
    keys = random.sample([k for k in POOL if k != "night_silence" or hour < 2], 3)
    await db.set_setting(chat_id, "quests_today", json.dumps({"day": today(), "keys": keys}))
    prize = int(s.get("quest_prize", 15))
    lines = [f"{i + 1}. {POOL[k][0]}" for i, k in enumerate(keys)]
    sent = await bot.send_message(chat_id, say(await style(chat_id), "quests_post", chat_id=chat_id, list="\n".join(lines), prize=prize))
    await db.remember_bot_message(chat_id, sent.message_id)


async def quests_tick(bot: Bot):
    lt = time.localtime()
    for chat_id in await db.all_chats():
        if chat_id > 0:
            continue
        s = await db.settings(chat_id)
        if not s.get("quests", 1) or lt.tm_hour < int(s.get("quest_hour", 12)):
            continue
        try:
            await post_quests(bot, chat_id)
        except Exception:
            pass


async def day_summary(chat_id: int) -> str:
    """Для итогов дня: кто что выполнил."""
    d = today()
    done = [(k[2], v) for k, v in _done.items() if k[0] == chat_id and k[1] == d and v]
    if not done:
        return ""
    parts = []
    for uid, keys in sorted(done, key=lambda x: -len(x[1]))[:8]:
        u = await db.user(chat_id, uid)
        parts.append(f"{mention(uid, (u['nick'] or u['first_name']) if u else None)} — {len(keys)}/3")
    return "🎯 квесты: " + ", ".join(parts)


@router.message(Command("квесты", "квест", "quests", prefix="!+/"))
async def cmd_quests(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    keys = await active(chat_id)
    if not keys:
        s = await db.settings(chat_id)
        if time.localtime().tm_hour >= int(s.get("quest_hour", 12)):
            await post_quests(bot, chat_id)
            keys = await active(chat_id)
        if not keys:
            return await reply(msg, "quests_none", hour=int(s.get("quest_hour", 12)))
    p = _prog.get((chat_id, today(), uid), {})
    lines = [f"{'✅' if p.get(k, 0) >= POOL[k][1] else '▫️'} {POOL[k][0]} — {min(p.get(k, 0), POOL[k][1])}/{POOL[k][1]}" for k in keys]
    await reply(msg, "quests_mine", list="\n".join(lines))
