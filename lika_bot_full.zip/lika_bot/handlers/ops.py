"""Эксплуатация: бэкап базы, очередь отправки (анти-флуд), потолок расходов на ИИ.
• Бэкап: каждый день в BACKUP_HOUR (4) бот шлёт data/lika.db владельцам (OWNER_IDS) в личку — они должны один раз написать боту /start.
  !бэкап — прислать сейчас (владелец). Хранится 1 файл в день, последние 7 — ещё и локально в data/backups/.
• Очередь: ≥1.1 с между сообщениями в один чат, ≤25 отправок/с всего, автоповтор при Flood control (RetryAfter).
• Потолок: LLM_DAILY_TOKENS (по умолчанию 1 500 000) — при превышении остаются только ответы по обращению и !спроси."""
import asyncio
import logging
import os
import shutil
import time
from collections import defaultdict
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message, FSInputFile
from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.exceptions import TelegramRetryAfter
from db import db
from config import OWNER_IDS, DB_PATH

router = Router()
BACKUP_HOUR = int(os.getenv("BACKUP_HOUR", "4"))
_backup_day = ""


# ---------------- очередь отправки ----------------
class ThrottleMiddleware(BaseRequestMiddleware):
    SEND_METHODS = ("SendMessage", "SendPhoto", "SendVoice", "SendAudio", "SendVideo", "SendVideoNote", "SendDocument", "SendAnimation", "SendSticker", "SendPoll", "EditMessageText")
    PER_CHAT_GAP = 1.1
    GLOBAL_GAP = 0.04

    def __init__(self):
        self._chat_last: dict[int, float] = defaultdict(float)
        self._locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
        self._global_last = 0.0
        self._global_lock = asyncio.Lock()

    async def __call__(self, make_request, bot, method):
        name = type(method).__name__
        if name not in self.SEND_METHODS:
            return await make_request(bot, method)
        chat_id = getattr(method, "chat_id", None)
        try:
            chat_id = int(chat_id)
        except (TypeError, ValueError):
            chat_id = 0
        async with self._locks[chat_id]:
            wait = self._chat_last[chat_id] + self.PER_CHAT_GAP - time.monotonic()
            if wait > 0:
                await asyncio.sleep(wait)
            async with self._global_lock:
                gw = self._global_last + self.GLOBAL_GAP - time.monotonic()
                if gw > 0:
                    await asyncio.sleep(gw)
                self._global_last = time.monotonic()
            for attempt in range(3):
                try:
                    res = await make_request(bot, method)
                    self._chat_last[chat_id] = time.monotonic()
                    return res
                except TelegramRetryAfter as e:
                    logging.warning("flood control %s: ждём %s с", chat_id, e.retry_after)
                    await asyncio.sleep(min(float(e.retry_after) + 0.5, 60))
            return await make_request(bot, method)


# ---------------- бэкап ----------------
async def send_backup(bot: Bot, to: int | None = None) -> bool:
    if not os.path.exists(DB_PATH):
        return False
    bdir = os.path.join(os.path.dirname(DB_PATH) or ".", "backups")
    os.makedirs(bdir, exist_ok=True)
    stamp = time.strftime("%Y-%m-%d")
    path = os.path.join(bdir, f"lika_{stamp}.db")
    try:
        # консистентная копия через sqlite backup API
        import sqlite3
        src = sqlite3.connect(DB_PATH, timeout=30)
        dst = sqlite3.connect(path)
        with dst:
            src.backup(dst)
        src.close(); dst.close()
    except Exception as e:
        logging.warning("backup copy: %s", e)
        shutil.copy2(DB_PATH, path)
    # оставляем 7 последних
    files = sorted(f for f in os.listdir(bdir) if f.startswith("lika_") and f.endswith(".db"))
    for f in files[:-7]:
        try:
            os.remove(os.path.join(bdir, f))
        except OSError:
            pass
    size = os.path.getsize(path)
    targets = [to] if to else sorted(OWNER_IDS)
    ok = False
    for uid in targets:
        try:
            await bot.send_document(uid, FSInputFile(path, filename=f"sarrochka_{stamp}.db"),
                                    caption=f"🗄 бэкап базы за {stamp} · {size / 1024 / 1024:.1f} МБ. положи куда-нибудь, где не потеряется. не как мои нервы.")
            ok = True
        except Exception as e:
            logging.warning("backup send to %s: %s (владелец должен написать боту /start)", uid, str(e)[:120])
    return ok


async def backup_tick(bot: Bot):
    global _backup_day
    lt = time.localtime()
    day = time.strftime("%Y-%m-%d")
    if lt.tm_hour < BACKUP_HOUR or _backup_day == day:
        return
    _backup_day = day
    if OWNER_IDS:
        await send_backup(bot)


@router.message(Command("бэкап", "backup", prefix="!/"))
async def cmd_backup(msg: Message, bot: Bot):
    from utils import rank_of
    if msg.from_user.id not in OWNER_IDS and (msg.chat.type == "private" or await rank_of(bot, msg.chat.id, msg.from_user.id) < 4):
        return await msg.answer("бэкап — только владельцу. это же вся наша жизнь в одном файле.")
    ok = await send_backup(bot, msg.from_user.id)
    await msg.answer("отправила тебе в личку." if ok else "не смогла отправить в личку — напиши мне сначала /start в личных сообщениях, Telegram так устроен.")
