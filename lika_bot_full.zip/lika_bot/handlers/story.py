"""Сторителлинг.
• !история — Саррочка даёт первую фразу; каждый добавляет по одному предложению (ответом на последнее сообщение истории или сообщением,
  начинающимся с «…»); после story_lines (10) реплик или 20 минут тишины она пишет абсурдный финал. Участникам +5 🪙.
• Сериал про чат: раз в день в serial_hour (15) новая серия — участники как персонажи, по заметкам, связям и событиям дня (serial 0 — выкл; по умолчанию выкл).
  !сериал — серия сейчас (ст. админ)."""
import asyncio
import html
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, style, deny
from phrases import say

router = Router()
_story: dict[int, dict] = {}   # chat_id -> {lines: [(uid, text)], last_msg_id, started, last_ts}


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


@router.message(Command("история", "story", prefix="!+/"))
async def cmd_story(msg: Message, bot: Bot):
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    if not s.get("story", 1):
        return
    if chat_id in _story and time.time() - _story[chat_id]["last_ts"] < 1200:
        return await reply(msg, "story_busy")
    from handlers.ai import llm
    from persona import system_prompt
    top = await db.top_period(chat_id, 1, 6)
    names = ", ".join([await plain(chat_id, r["user_id"]) for r in top])
    opening = await llm([{"role": "system", "content": system_prompt(
        "Придумай ПЕРВУЮ фразу коллективной истории для чата: 1–2 предложения, интригующе и абсурдно, с одним из участников в главной роли. "
        f"Участники: {names}. Строчными, без markdown, без объяснений.", with_mood=False)}, {"role": "user", "content": "начни"}], max_tokens=80, temperature=1.0)
    if not opening:
        return await reply(msg, "ai_off")
    sent = await reply(msg, "story_start", text=html.escape(opening), n=int(s.get("story_lines", 10)))
    _story[chat_id] = {"lines": [(0, opening)], "last_msg_id": sent.message_id, "started": time.time(), "last_ts": time.time(), "authors": set()}
    asyncio.create_task(_watch(bot, chat_id, sent.message_id))


async def _watch(bot: Bot, chat_id: int, start_id: int):
    while True:
        await asyncio.sleep(60)
        st = _story.get(chat_id)
        if not st or st.get("done"):
            return
        if time.time() - st["last_ts"] > 1200 and len(st["lines"]) > 1:
            await _finish(bot, chat_id)
            return
        if time.time() - st["started"] > 3 * 3600:
            st["done"] = True
            _story.pop(chat_id, None)
            return


@router.message(F.text)
async def story_line(msg: Message, bot: Bot):
    from aiogram.dispatcher.event.bases import SkipHandler
    chat_id = msg.chat.id
    st = _story.get(chat_id)
    text = (msg.text or "").strip()
    if not st or st.get("done") or text.startswith(("/", "!", "+", "-")):
        raise SkipHandler
    is_reply = msg.reply_to_message and msg.reply_to_message.message_id == st["last_msg_id"]
    if not (is_reply or text.startswith(("…", "..."))):
        raise SkipHandler
    line = text.lstrip("…. ").strip()
    if len(line) < 3 or len(line) > 300:
        raise SkipHandler
    uid = msg.from_user.id
    if st["lines"] and st["lines"][-1][0] == uid:
        return await reply(msg, "story_turn")
    st["lines"].append((uid, line))
    st["authors"].add(uid)
    st["last_ts"] = time.time()
    st["last_msg_id"] = msg.message_id
    s = await db.settings(chat_id)
    try:
        from handlers.nominations import set_reaction
        await set_reaction(bot, chat_id, msg.message_id, "✍", min_gap=0)
    except Exception:
        pass
    if len(st["lines"]) - 1 >= int(s.get("story_lines", 10)):
        await _finish(bot, chat_id)


async def _finish(bot: Bot, chat_id: int):
    st = _story.get(chat_id)
    if not st or st.get("done"):
        return
    st["done"] = True
    from handlers.ai import llm
    from persona import system_prompt
    body = "\n".join([f"{'Саррочка' if uid == 0 else await plain(chat_id, uid)}: {t}" for uid, t in st["lines"]])
    ending = await llm([{"role": "system", "content": system_prompt(
        "Чат писал историю по кругу. Напиши ФИНАЛ: 3–6 предложений, с неожиданным поворотом, абсурдно, но связно, обыграй детали и имена авторов. "
        "Потом одной строкой — «мораль» от себя. Строчными, без markdown.", with_mood=False)}, {"role": "user", "content": body}], max_tokens=350, temperature=1.0)
    for uid in st["authors"]:
        await db.give_coin(chat_id, 0, uid, "история", 5)
    _story.pop(chat_id, None)
    text = say(await style(chat_id), "story_end", chat_id=chat_id, story=html.escape(body)[:2500], ending=html.escape(ending or "…и все жили долго. в чате."), n=len(st["authors"]))
    sent = await bot.send_message(chat_id, text[:4000])
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "story", f"📖 история: {len(st['lines']) - 1} реплик, {len(st['authors'])} авторов")


# ---------------- сериал ----------------
async def episode(bot: Bot, chat_id: int):
    from handlers.ai import llm
    from persona import system_prompt
    from handlers.relations import chat_summary
    s = await db.settings(chat_id)
    msgs = [m for m in await db.messages_since(chat_id, int(time.time()) - 24 * 3600, 600) if m["text"]]
    if len(msgs) < 30:
        return
    try:
        n = int(s.get("serial_episode", 0)) + 1
    except Exception:
        n = 1
    sample = "\n".join(f"{m['nick'] or m['first_name']}: {m['text'][:120]}" for m in msgs[-200:])[-9000:]
    notes = "\n".join(f"{x['day']}: {x['note']}" for x in await db.day_notes(chat_id, 5))
    out = await llm([{"role": "system", "content": system_prompt(
        f"Ты пишешь сериал «ЧВК Сарра», серия {n}. Жанр — мыльная опера с элементами криминальной комедии. Персонажи — реальные участники чата под их именами, "
        "сюжет — из реальных событий и разговоров за сутки, преувеличенных до абсурда. 8–14 строк: название серии, завязка, конфликт, клиффхэнгер. "
        "Без оскорблений по внешности, вере, национальности, здоровью. Строчными, без markdown. В конце — «в следующей серии: …» одной строкой.", with_mood=False)},
        {"role": "user", "content": f"Предыстория:\n{notes}\n\nСвязи: {await chat_summary(chat_id, int(time.time()) - 7 * 86400)}\n\nЗа сутки:\n{sample}"}],
        max_tokens=700, temperature=0.95, timeout=120)
    if not out:
        return
    await db.set_setting(chat_id, "serial_episode", n)
    sent = await bot.send_message(chat_id, say(await style(chat_id), "serial_head", chat_id=chat_id, n=n) + "\n\n" + html.escape(out)[:3800])
    await db.remember_bot_message(chat_id, sent.message_id)


async def serial_tick(bot: Bot):
    lt = time.localtime()
    day = time.strftime("%Y-%m-%d")
    for chat_id in await db.all_chats():
        if chat_id > 0:
            continue
        s = await db.settings(chat_id)
        if not s.get("serial", 0) or lt.tm_hour < int(s.get("serial_hour", 15)) or s.get("serial_done") == day:
            continue
        await db.set_setting(chat_id, "serial_done", day)
        try:
            await episode(bot, chat_id)
        except Exception:
            pass


@router.message(Command("сериал", "serial", prefix="!/"))
async def cmd_serial(msg: Message, bot: Bot):
    if await deny(msg, bot, "settings"):
        return
    await reply(msg, "serial_wait")
    await episode(bot, msg.chat.id)
