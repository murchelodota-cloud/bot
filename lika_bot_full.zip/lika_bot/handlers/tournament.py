"""Турнир недели по дуэлям. !турнир — записаться (взнос tour_fee, 50 🪙, идёт в призовой фонд). Очки: победа над участником турнира +3,
над любым +1, поражение −1 (не ниже 0). Каждый день в 21:00 — таблица; в воскресенье в 19:00 — финал: призовой фонд делится 50/30/20
между топ-3 (+ бонус tour_bonus 200 от Саррочки), ачивка «чемпион недели». !турнир таблица — текущие очки. Выкл: tournament 0."""
import json
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, style, split_args
from phrases import say

router = Router()


def week() -> str:
    return time.strftime("%Y-%W")


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def state(chat_id: int) -> dict:
    s = await db.settings(chat_id)
    try:
        t = json.loads(s.get("tournament_state") or "{}")
    except Exception:
        t = {}
    if t.get("week") != week():
        t = {"week": week(), "players": {}, "pool": 0, "closed": False}
    return t


async def save(chat_id: int, t: dict):
    await db.set_setting(chat_id, "tournament_state", json.dumps(t))


@router.message(Command("турнир", "tournament", prefix="!+/"))
async def cmd_tournament(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    s = await db.settings(chat_id)
    if not s.get("tournament", 1):
        return
    args = [a.lower() for a in split_args(msg)]
    t = await state(chat_id)
    if args and args[0] in ("таблица", "очки", "топ", "table"):
        return await show_table(msg, t)
    if t.get("closed"):
        return await reply(msg, "tour_closed")
    if str(uid) in t["players"]:
        return await show_table(msg, t)
    fee = int(s.get("tour_fee", 50))
    bal = await db.coins_total(chat_id, uid)
    if bal < fee:
        return await reply(msg, "shop_poor", name="взнос в турнир", cost=fee, balance=bal)
    await db.give_coin(chat_id, uid, 0, "взнос в турнир", -fee)
    t["players"][str(uid)] = {"pts": 0, "w": 0, "l": 0}
    t["pool"] += fee
    await save(chat_id, t)
    await reply(msg, "tour_joined", user=await nm(chat_id, uid), n=len(t["players"]), pool=t["pool"] + int(s.get("tour_bonus", 200)))


async def show_table(msg: Message, t: dict):
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    if not t["players"]:
        return await reply(msg, "tour_empty", fee=int(s.get("tour_fee", 50)))
    rows = sorted(t["players"].items(), key=lambda kv: (-kv[1]["pts"], -kv[1]["w"]))
    lines = [f"{i + 1}. {await nm(chat_id, int(u))} — {p['pts']} очк. ({p['w']}:{p['l']})" for i, (u, p) in enumerate(rows[:15])]
    await reply(msg, "tour_table", list="\n".join(lines), pool=t["pool"] + int(s.get("tour_bonus", 200)), n=len(t["players"]))


async def on_duel(bot: Bot, chat_id: int, winner: int, loser: int):
    t = await state(chat_id)
    if t.get("closed") or not t["players"]:
        return
    pw, pl = t["players"].get(str(winner)), t["players"].get(str(loser))
    if pw:
        pw["pts"] += 3 if pl else 1
        pw["w"] += 1
    if pl:
        pl["pts"] = max(0, pl["pts"] - 1)
        pl["l"] += 1
    if pw or pl:
        await save(chat_id, t)


async def tournament_tick(bot: Bot):
    lt = time.localtime()
    for chat_id in await db.all_chats():
        if chat_id > 0:
            continue
        s = await db.settings(chat_id)
        if not s.get("tournament", 1):
            continue
        t = await state(chat_id)
        if not t["players"] or t.get("closed"):
            continue
        day = time.strftime("%Y-%m-%d")
        # финал — воскресенье 19:00
        if lt.tm_wday == 6 and lt.tm_hour >= 19:
            await finish(bot, chat_id, t, s)
            continue
        # ежедневная таблица в 21:00
        if lt.tm_hour >= 21 and t.get("table_day") != day:
            t["table_day"] = day
            await save(chat_id, t)
            rows = sorted(t["players"].items(), key=lambda kv: (-kv[1]["pts"], -kv[1]["w"]))
            lines = [f"{i + 1}. {await nm(chat_id, int(u))} — {p['pts']} очк." for i, (u, p) in enumerate(rows[:10])]
            sent = await bot.send_message(chat_id, say(await style(chat_id), "tour_daily", chat_id=chat_id, list="\n".join(lines),
                                                       pool=t["pool"] + int(s.get("tour_bonus", 200))))
            await db.remember_bot_message(chat_id, sent.message_id)


async def finish(bot: Bot, chat_id: int, t: dict, s: dict):
    t["closed"] = True
    await save(chat_id, t)
    pool = t["pool"] + int(s.get("tour_bonus", 200))
    rows = sorted(t["players"].items(), key=lambda kv: (-kv[1]["pts"], -kv[1]["w"]))
    shares = [0.5, 0.3, 0.2]
    lines = []
    for i, (u, p) in enumerate(rows[:3]):
        prize = int(pool * shares[i]) if len(rows) >= 2 else pool
        await db.give_coin(chat_id, 0, int(u), f"турнир недели: {i + 1} место", prize)
        if i == 0:
            await db.give_achievement(chat_id, int(u), "tour_champion")
        lines.append(f"{['🥇', '🥈', '🥉'][i]} {await nm(chat_id, int(u))} — {p['pts']} очк., +{prize} 🪙")
        if len(rows) < 2:
            break
    await db.log_event(chat_id, "tournament", f"🏆 турнир недели: {lines[0] if lines else '—'}")
    sent = await bot.send_message(chat_id, say(await style(chat_id), "tour_final", chat_id=chat_id, list="\n".join(lines), n=len(rows)))
    await db.remember_bot_message(chat_id, sent.message_id)
