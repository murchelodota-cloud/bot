"""Игры на коины.
!ктописал — Саррочка показывает цитату из чата (за 7 дней) и 4 кнопки с именами; первый угадавший +10 🪙, 60 секунд.
!правдаложь — ИИ придумывает утверждение про участника (правда по его сообщениям/фактам или ложь); кнопки Правда/Ложь; все угадавшие +5 🪙.
!игра — случайная из двух. Настройки: games, game_prize (10), game_seconds (60)."""
import asyncio
import html
import json
import random
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from db import db
from utils import reply, mention, style
from phrases import say

router = Router()
_games: dict[int, dict] = {}   # chat_id -> активная игра


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


def _busy(chat_id: int) -> bool:
    g = _games.get(chat_id)
    return bool(g and time.time() < g["until"])


# ---------------- угадай, кто написал ----------------
async def pick_quote(chat_id: int):
    msgs = await db.messages_since(chat_id, int(time.time()) - 7 * 86400, 1500)
    good = [m for m in msgs if m["text"] and 40 <= len(m["text"]) <= 220 and not m["text"].startswith(("/", "!", "+", "-"))
            and "http" not in m["text"] and "@" not in m["text"]]
    authors = {}
    for m in good:
        authors.setdefault(m["user_id"], []).append(m)
    active = [u for u, lst in authors.items() if len(lst) >= 3]
    if len(active) < 4:
        return None
    uid = random.choice(active)
    m = random.choice(authors[uid])
    others = random.sample([u for u in active if u != uid], 3)
    return uid, m["text"], others


async def start_guess(msg: Message, bot: Bot):
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    picked = await pick_quote(chat_id)
    if not picked:
        return await reply(msg, "game_no_data")
    uid, text, others = picked
    options = [uid] + others
    random.shuffle(options)
    names = {u: await plain(chat_id, u) for u in options}
    secs = int(s.get("game_seconds", 60))
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=names[u][:28], callback_data=f"game:guess:{u}")] for u in options])
    sent = await reply(msg, "game_guess_start", quote=html.escape(text), secs=secs, reply_markup=kb)
    _games[chat_id] = {"kind": "guess", "answer": uid, "msg_id": sent.message_id, "until": time.time() + secs,
                       "tried": set(), "prize": int(s.get("game_prize", 10)), "text": text}
    asyncio.create_task(_finish_guess(bot, chat_id, sent.message_id, secs))


async def _finish_guess(bot: Bot, chat_id: int, msg_id: int, secs: int):
    await asyncio.sleep(secs)
    g = _games.get(chat_id)
    if not g or g["msg_id"] != msg_id or g.get("done"):
        return
    g["done"] = True
    try:
        await bot.edit_message_reply_markup(chat_id, msg_id, reply_markup=None)
    except TelegramBadRequest:
        pass
    st = await style(chat_id)
    sent = await bot.send_message(chat_id, say(st, "game_guess_timeout", chat_id=chat_id, user=await nm(chat_id, g["answer"])))
    await db.remember_bot_message(chat_id, sent.message_id)


# ---------------- правда или ложь ----------------
async def start_truth(msg: Message, bot: Bot):
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    try:
        from handlers.ai import llm_json
        from persona import system_prompt
        from config import LLM_API_KEY
    except Exception:
        LLM_API_KEY = None
    if not LLM_API_KEY:
        return await reply(msg, "game_ai_off")
    rows = await db.top_period(chat_id, 7, 12)
    if len(rows) < 3:
        return await reply(msg, "game_no_data")
    uid = random.choice(rows)["user_id"]
    texts = [m["text"] for m in await db.user_messages(chat_id, uid, 120)]
    facts = await db.user_facts(chat_id, uid, 15) if hasattr(db, "user_facts") else []
    u = await db.user(chat_id, uid)
    want_true = random.random() < 0.5
    info = (f"имя: {u['nick'] or u['first_name']}; сообщений: {u['msgs']}; город: {u['city'] or '-'}; описание: {u['bio'] or '-'}; "
            f"известные факты: {'; '.join(f['fact'] for f in facts) or '-'}\nсообщения:\n" + "\n".join(f"- {t[:120]}" for t in texts[-50:]))
    res = await llm_json([
        {"role": "system", "content": system_prompt(
            ("Придумай одно ПРАВДИВОЕ утверждение про участника — конкретное, проверяемое по его сообщениям/фактам, но не очевидное всем (не «он пишет в чат»)."
             if want_true else
             "Придумай одно ЛОЖНОЕ, но правдоподобное утверждение про участника — похожее на правду по стилю его сообщений, но противоречащее им или выдуманное.")
            + ' Без оскорблений, без тем о здоровье, вере, национальности, внешности. Верни JSON {"statement": "одна фраза в третьем лице, с именем"}', with_mood=False)},
        {"role": "user", "content": info}], max_tokens=120)
    if not isinstance(res, dict) or not res.get("statement"):
        return await reply(msg, "game_ai_off")
    secs = int(s.get("game_seconds", 60))
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ правда", callback_data="game:truth:1"),
                                                InlineKeyboardButton(text="❌ ложь", callback_data="game:truth:0")]])
    sent = await reply(msg, "game_truth_start", statement=html.escape(str(res["statement"])[:300]), secs=secs, reply_markup=kb)
    _games[chat_id] = {"kind": "truth", "answer": 1 if want_true else 0, "msg_id": sent.message_id, "until": time.time() + secs,
                       "votes": {}, "prize": max(1, int(s.get("game_prize", 10)) // 2), "about": uid}
    asyncio.create_task(_finish_truth(bot, chat_id, sent.message_id, secs))


async def _finish_truth(bot: Bot, chat_id: int, msg_id: int, secs: int):
    await asyncio.sleep(secs)
    g = _games.get(chat_id)
    if not g or g["msg_id"] != msg_id or g.get("done"):
        return
    g["done"] = True
    try:
        await bot.edit_message_reply_markup(chat_id, msg_id, reply_markup=None)
    except TelegramBadRequest:
        pass
    winners = [u for u, v in g["votes"].items() if v == g["answer"]]
    for u in winners:
        await db.give_coin(chat_id, 0, u, "правда или ложь", g["prize"])
    st = await style(chat_id)
    names = ", ".join([await nm(chat_id, u) for u in winners[:10]]) or "никто"
    sent = await bot.send_message(chat_id, say(st, "game_truth_result", chat_id=chat_id, verdict="правда" if g["answer"] else "ложь",
                                               winners=names, n=len(winners), prize=g["prize"], about=await nm(chat_id, g["about"])))
    await db.remember_bot_message(chat_id, sent.message_id)


# ---------------- кнопки ----------------
@router.callback_query(F.data.startswith("game:"))
async def on_game_button(cb: CallbackQuery, bot: Bot):
    _, kind, val = cb.data.split(":")
    chat_id = cb.message.chat.id
    g = _games.get(chat_id)
    if not g or g["msg_id"] != cb.message.message_id or g.get("done") or time.time() > g["until"]:
        return await cb.answer("игра уже закончилась.", show_alert=True)
    uid = cb.from_user.id
    await db.touch_user(chat_id, cb.from_user)
    if kind == "guess":
        if uid == g["answer"]:
            return await cb.answer("это же ты написал. не подсказывай.", show_alert=True)
        if uid in g["tried"]:
            return await cb.answer("одна попытка, котенок.", show_alert=True)
        g["tried"].add(uid)
        if int(val) != g["answer"]:
            return await cb.answer("мимо 💅", show_alert=False)
        g["done"] = True
        await db.give_coin(chat_id, 0, uid, "угадай, кто написал", g["prize"])
        await db.log_event(chat_id, "game", f"🎮 {await nm(chat_id, uid)} угадал автора цитаты, +{g['prize']} 🪙")
        try:
            await cb.message.edit_reply_markup(reply_markup=None)
        except TelegramBadRequest:
            pass
        st = await style(chat_id)
        sent = await cb.message.answer(say(st, "game_guess_win", chat_id=chat_id, user=await nm(chat_id, uid), author=await nm(chat_id, g["answer"]), prize=g["prize"]))
        await db.remember_bot_message(chat_id, sent.message_id)
        return await cb.answer("🏆")
    if kind == "truth":
        if uid == g["about"]:
            return await cb.answer("про тебя же. сиди молча и красиво.", show_alert=True)
        g["votes"][uid] = int(val)
        return await cb.answer("принято. ждём остальных.")


@router.message(Command("ктописал", "ктонаписал", "цитата", "whosaid", prefix="!+/"))
async def cmd_guess(msg: Message, bot: Bot):
    s = await db.settings(msg.chat.id)
    if not s.get("games", 1):
        return
    if _busy(msg.chat.id):
        return await reply(msg, "game_busy")
    await start_guess(msg, bot)


@router.message(Command("правдаложь", "правдаилиложь", "truth", prefix="!+/"))
async def cmd_truth(msg: Message, bot: Bot):
    s = await db.settings(msg.chat.id)
    if not s.get("games", 1):
        return
    if _busy(msg.chat.id):
        return await reply(msg, "game_busy")
    await start_truth(msg, bot)


@router.message(Command("игра", "game", "играем", prefix="!+/"))
async def cmd_game(msg: Message, bot: Bot):
    s = await db.settings(msg.chat.id)
    if not s.get("games", 1):
        return
    if _busy(msg.chat.id):
        return await reply(msg, "game_busy")
    await (start_truth if random.random() < 0.4 else start_guess)(msg, bot)
