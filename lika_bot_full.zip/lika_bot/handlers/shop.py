"""Магазин за сарра-коины — чтобы коины что-то значили.
!магазин — витрина; !купить <номер или название> [@юзер / текст] — купить. Покупки: shop_* настройки цен.
Товары: звание на 7 дней · своя ачивка · помилование друга из мута · VIP-рамка в карточке на 30 дней ·
иммунитет от первого преда на 7 дней · сменить ник другу на сутки · имя в приветствии новичков на 3 дня."""
import html
import json
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, resolve_target, split_args, FULL_PERMS
from aiogram.exceptions import TelegramBadRequest

router = Router()
ITEMS = [
    # key, название, цена по умолчанию, срок (сек), описание, нужен аргумент
    ("title", "звание на 7 дней", 300, 7 * 86400, "своё звание в карточке и в !кто я — !купить звание текст", "text"),
    ("ach", "своя ачивка", 500, 0, "именная ачивка навсегда — !купить ачивка название", "text"),
    ("pardon", "помилование", 200, 0, "снять мут с друга — !купить помилование @юзер (не чаще раза в сутки на человека)", "user"),
    ("vip", "VIP-рамка на 30 дней", 1000, 30 * 86400, "золотая рамка и метка VIP в карточке профиля", None),
    ("immunity", "иммунитет на 7 дней", 800, 7 * 86400, "первый пред за неделю сгорает (не работает на скам и бан)", None),
    ("rename", "переименовать друга на сутки", 400, 86400, "ник другу на 24 часа — !купить переименовать @юзер новый ник (без оскорблений)", "user_text"),
    ("greeter", "лицо приветствия на 3 дня", 600, 3 * 86400, "Саррочка упоминает тебя в приветствии каждого новичка: «…а это наш {name}, он тут главный по …»", "text"),
]
ALIASES = {"звание": "title", "титул": "title", "ачивка": "ach", "ачивку": "ach", "помилование": "pardon", "помиловать": "pardon", "vip": "vip", "вип": "vip",
           "рамка": "vip", "иммунитет": "immunity", "переименовать": "rename", "ник": "rename", "приветствие": "greeter", "лицо": "greeter"}


def price(s: dict, key: str, default: int) -> int:
    return int(s.get(f"shop_{key}", default) or default)


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


@router.message(Command("магазин", "shop", "лавка", prefix="!+/"))
async def cmd_shop(msg: Message):
    s = await db.settings(msg.chat.id)
    if not s.get("shop", 1):
        return
    bal = await db.coins_total(msg.chat.id, msg.from_user.id)
    lines = [f"{i + 1}. <b>{name}</b> — {price(s, key, p)} 🪙\n    <i>{desc}</i>" for i, (key, name, p, _, desc, _) in enumerate(ITEMS)]
    await reply(msg, "shop_list", list="\n".join(lines), balance=bal)


@router.message(Command("купить", "buy", prefix="!+/"))
async def cmd_buy(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    s = await db.settings(chat_id)
    if not s.get("shop", 1):
        return
    args = split_args(msg)
    if not args:
        return await reply(msg, "shop_usage")
    sel = args[0].lower().strip(".")
    key = ALIASES.get(sel) or (ITEMS[int(sel) - 1][0] if sel.isdigit() and 1 <= int(sel) <= len(ITEMS) else None)
    item = next((it for it in ITEMS if it[0] == key), None)
    if not item:
        return await reply(msg, "shop_usage")
    key, name, p, ttl, desc, need = item
    cost = price(s, key, p)
    bal = await db.coins_total(chat_id, uid)
    if bal < cost:
        return await reply(msg, "shop_poor", name=name, cost=cost, balance=bal)
    target, tname, rest = (None, None, args[1:])
    if need in ("user", "user_text"):
        target, tname, rest = await resolve_target(msg)
        if not target or target == uid and key != "pardon":
            return await reply(msg, "shop_need_user", name=name)
    text = " ".join(rest).strip()
    if need in ("text", "user_text") and len(text) < 2:
        return await reply(msg, "shop_need_text", name=name)
    text = html.escape(text[:40])
    me = await nm(chat_id, uid, msg.from_user.first_name)
    # ---- эффекты ----
    if key == "title":
        await db.set_user_field(chat_id, uid, "title", text)
    elif key == "ach":
        if not await db.give_achievement(chat_id, uid, "custom:" + text.lower()):
            return await reply(msg, "shop_ach_dup", ach=text)
    elif key == "pardon":
        last = await db.purchase_last(chat_id, target, "pardon")
        if time.time() - last < 86400:
            return await reply(msg, "shop_pardon_cooldown", user=await nm(chat_id, target, tname))
        try:
            await bot.restrict_chat_member(chat_id, target, FULL_PERMS)
        except TelegramBadRequest:
            return await reply(msg, "shop_pardon_fail", user=await nm(chat_id, target, tname))
    elif key == "rename":
        row = await db.user(chat_id, target)
        old = row["nick"] if row else None
        await db.set_nick(chat_id, target, text)
        await db.purchase_add(chat_id, uid, "rename_restore", ttl, json.dumps({"target": target, "old": old}))
    elif key == "greeter":
        await db.set_setting(chat_id, "greeter", json.dumps({"uid": uid, "text": text, "until": int(time.time()) + ttl}))
    # vip / immunity — просто запись покупки, проверяется в карточке и при преде
    await db.give_coin(chat_id, uid, 0, f"магазин: {name}", -cost)
    await db.purchase_add(chat_id, uid if key != "pardon" else target, key, ttl, text or "")
    await db.log_event(chat_id, "shop", f"🛍 {me} купил(а) «{name}» за {cost} 🪙" + (f" для {await nm(chat_id, target, tname)}" if target else ""))
    await reply(msg, f"shop_ok_{key}", user=me, target=await nm(chat_id, target, tname) if target else "", text=text, cost=cost,
                left=bal - cost, days=max(1, ttl // 86400))


async def expire_tick(bot: Bot):
    """Снимаем истёкшие звания/ники (раз в 5 минут из цикла)."""
    for row in await db.purchases_expired():
        try:
            if row["item"] == "title":
                u = await db.user(row["chat_id"], row["user_id"])
                if u and u["title"] == row["data"]:
                    await db.set_user_field(row["chat_id"], row["user_id"], "title", None)
            elif row["item"] == "rename_restore":
                d = json.loads(row["data"] or "{}")
                await db.set_nick(row["chat_id"], d["target"], d.get("old"))
        except Exception:
            pass
        await db.purchase_close(row["id"])


async def has(chat_id: int, uid: int, key: str) -> bool:
    return bool(await db.purchase_active(chat_id, uid, key))


async def consume_immunity(chat_id: int, uid: int) -> bool:
    """Если есть иммунитет — сжигаем его и возвращаем True (пред не ставится)."""
    row = await db.purchase_active(chat_id, uid, "immunity")
    if not row:
        return False
    await db.purchase_close(row["id"])
    return True
