"""ИИ-возможности (через LLM из .env): диалог по имени, !спроси, умное вмешательство, токсичность и скам,
разбор спора, что пропустил, подпись к мему, вопрос дня, совместимость, авто-номинации, гороскоп, итоги месяца (wrapped)."""
import asyncio
import html
import json
import logging
import random
import re
import time
from collections import defaultdict, deque
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.exceptions import TelegramBadRequest
from db import db
from phrases import say
from utils import reply, mention, split_args, style, rank_of, deny, warn_weight, human_duration, MUTE_PERMS
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL, MASS_PER_WARN

router = Router()

from persona import PERSONA, system_prompt

_history: dict[int, deque] = defaultdict(lambda: deque(maxlen=40))   # chat -> последние реплики (для контекста диалога)
_last_interject: dict[int, float] = {}
_since_interject: dict[int, int] = defaultdict(int)


# ======================= базовый вызов модели =======================
_usage: dict[str, int] = {"main_calls": 0, "cheap_calls": 0, "main_tokens": 0, "cheap_tokens": 0, "day": ""}


def usage_snapshot() -> dict:
    return dict(_usage)


def over_budget() -> bool:
    from config import LLM_DAILY_TOKENS
    return _usage["day"] == time.strftime("%Y-%m-%d") and (_usage["main_tokens"] + _usage["cheap_tokens"]) > LLM_DAILY_TOKENS


async def llm(messages: list[dict], max_tokens: int = 400, temperature: float = 0.8, timeout: int = 60, tier: str = "main", essential: bool = False) -> str | None:
    """tier='main' — мозг (LLM_*), tier='cheap' — служебные вызовы (LLM_CHEAP_*, по умолчанию = мозг).
    essential=True — вызов по прямому обращению: работает даже при превышении дневного потолка токенов."""
    from config import LLM_CHEAP_API_KEY, LLM_CHEAP_BASE_URL, LLM_CHEAP_MODEL
    if not essential and over_budget():
        return None
    key, base, model = (LLM_CHEAP_API_KEY, LLM_CHEAP_BASE_URL, LLM_CHEAP_MODEL) if tier == "cheap" else (LLM_API_KEY, LLM_BASE_URL, LLM_MODEL)
    if not key:
        return None
    import aiohttp
    payload = {"model": model, "temperature": temperature, "max_tokens": max_tokens, "messages": messages}
    today = time.strftime("%Y-%m-%d")
    if _usage["day"] != today:
        _usage.update(main_calls=0, cheap_calls=0, main_tokens=0, cheap_tokens=0, day=today)
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
            async with s.post(f"{base}/chat/completions", json=payload,
                              headers={"Authorization": f"Bearer {key}"}) as resp:
                data = await resp.json()
                if resp.status != 200:
                    logging.warning("llm[%s] %s: %s", tier, resp.status, str(data)[:300])
                    return None
                _usage[f"{tier}_calls"] += 1
                _usage[f"{tier}_tokens"] += int((data.get("usage") or {}).get("total_tokens") or 0)
                return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logging.warning("llm[%s]: %s: %s", tier, type(e).__name__, str(e)[:200])
        return None


async def llm_json(messages: list[dict], max_tokens: int = 300, temperature: float = 0.2, tier: str = "main") -> dict | None:
    out = await llm(messages, max_tokens=max_tokens, temperature=temperature, tier=tier)
    if not out:
        return None
    m = re.search(r"\{.*\}", out, re.S)
    try:
        return json.loads(m.group(0) if m else out)
    except (ValueError, AttributeError):
        return None


def who(msg: Message) -> str:
    return msg.from_user.first_name or "кто-то"


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


async def send_long(msg: Message, text: str, reply_to: bool = True):
    text = html.escape(text)
    while text:
        cut = text.rfind("\n", 0, 4000) if len(text) > 4000 else len(text)
        sent = await (msg.reply(text[:cut]) if reply_to else msg.answer(text[:cut]))
        await db.remember_bot_message(msg.chat.id, sent.message_id)
        text = text[cut:].lstrip("\n")
        reply_to = False


def remember(msg: Message, is_bot: bool = False):
    t = (msg.text or msg.caption or "").strip()
    if t:
        _history[msg.chat.id].append(("саррочка" if is_bot else who(msg), t[:300]))


def context_block(chat_id: int, n: int = 25) -> str:
    return "\n".join(f"{a}: {t}" for a, t in list(_history[chat_id])[-n:])


# ======================= 1. диалог по имени / ответом на сообщение бота =======================
NAME_RE = re.compile(r"^(?:саррочка|@fromsarrabot)[,!\s]+(.+)$|^(.+?)[,\s]+(?:саррочка)[?!.]*$|^(.+?)[,\s]+(?:саррочка)[,\s]+(.+)$", re.I | re.S)


async def talk(msg: Message, text: str):
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    if not s.get("ai_talk", 1):
        return
    mood = await db.mood(chat_id)
    rank = await rank_of(msg.bot, chat_id, msg.from_user.id)
    from handlers.memory import facts_line
    notes = await db.day_notes(chat_id, 3)
    notes_txt = (" Что было в чате в прошлые дни: " + " | ".join(f"{n['day']}: {n['note']}" for n in notes) + ".") if notes else ""
    web_block = ""
    from websearch import NEED_WEB_HINT, research
    if s.get("ai_web", 1) and ("?" in text or NEED_WEB_HINT.search(text)) and len(text) > 12:
        web_block, _ = await research(text, context_block(chat_id, 6))
    from persona import relation_note
    from config import OWNER_IDS
    sys = system_prompt(f"Собеседник: {who(msg)}, ранг «{['участник','модератор','младший админ','старший админ','владелец'][rank]}». "
                        + relation_note(rank, msg.from_user.id in OWNER_IDS, who(msg)) + " "
                        + (await facts_line(chat_id, msg.from_user.id)) + " " + (await __import__("handlers.relations", fromlist=["summary"]).summary(chat_id, msg.from_user.id)) + notes_txt + " Используй то, что знаешь, только если это к месту, не перечисляй. "
                        + ("Есть результаты веб-поиска по его вопросу — ответь по фактам из них (с датой, если важна) и добавь «источник: <url>»; стиль сохраняй, но суть первой. " if web_block else "")
                        + "Ответь на его реплику 1–3 предложениями, как в живом чате. Если человеку плохо — без сарказма. "
                        "Если просят что-то по модерации — скажи, что для этого есть команды, сама не делай. Не повторяй фразы, которые уже говорила в этом разговоре.", mood)
    ctx = context_block(chat_id)
    out = await llm([{"role": "system", "content": sys},
                     {"role": "user", "content": f"Последние реплики чата:\n{ctx}\n\n{who(msg)} пишет тебе: {text}" + (f"\n\n{web_block}" if web_block else "")}],
                    max_tokens=450 if web_block else 200, essential=True)
    if not out:
        # без модели — скриптовые реакции по образу
        return await reply(msg, scripted_key(text))
    await db.bump_mood(chat_id, 1)
    sent = await msg.reply(html.escape(out))
    await db.remember_bot_message(chat_id, sent.message_id)
    _history[chat_id].append(("саррочка", out[:300]))


REACT_RULES = [
    ("react_stupid", re.compile(r"\b(туп|глуп|дур|идиот|бесполезн|отстой)", re.I)),
    ("react_praise", re.compile(r"(красив|умниц|молодец|лучш|люблю|обожа|крут|класс|супер|королев)", re.I)),
    ("react_flirt", re.compile(r"(замуж|встреча|свидан|поцелу|обним|мо[яй] (девочк|малыш|кис))", re.I)),
    ("react_sad", re.compile(r"(грустн|плохо мне|тяжело|устал|одинок|плач|депресс|хочу умереть|разби)", re.I)),
    ("react_argue", re.compile(r"(не согласен|не согласна|неправда|ошибаешься|бред|чушь|ты не права|докажи)", re.I)),
]


def scripted_key(text: str) -> str:
    for key, rx in REACT_RULES:
        if rx.search(text):
            return key
    return "react_default"


@router.message(F.text, F.reply_to_message)
async def on_reply_to_bot(msg: Message, bot: Bot):
    u = msg.reply_to_message.from_user
    if not u or not u.is_bot or u.id != (await bot.get_me()).id:
        from aiogram.dispatcher.event.bases import SkipHandler
        raise SkipHandler
    if (msg.text or "").startswith(("/", "!", "+", "-")):
        from aiogram.dispatcher.event.bases import SkipHandler
        raise SkipHandler
    await talk(msg, msg.text)


@router.message(F.text.regexp(NAME_RE).as_("m"))
async def on_name(msg: Message, m: re.Match):
    text = (m.group(1) or m.group(2) or " ".join(x for x in (m.group(3), m.group(4)) if x) or "").strip()
    if not text or text.startswith(("/", "!", "+", "-")):
        return
    low = text.lower()
    # музыку, картинки и прожарку обрабатывают свои модули
    if re.match(r"^(включи|поставь|трек|песн|музык|найди (?:картинк|фото|пикч)|картинк|покажи (?:картинк|фото)|скинь (?:картинк|фото))", low) or "прожар" in low:
        return
    # разбор человека — только если это ответ на сообщение или есть @юзер; «какая погода?» — обычный вопрос
    if (msg.reply_to_message or "@" in text) and re.search(r"(опиши|какой он|какая она|можно ли (?:ему|ей) верить|расскажи (?:о|про)|что думаешь (?:о|про))", low):
        return
    try:
        await msg.bot.send_chat_action(msg.chat.id, "typing")
    except Exception:
        pass
    await talk(msg, text)


@router.message(Command("спроси", "ask", "ai", "саррочка", prefix="!+/"))
async def cmd_ask(msg: Message):
    q = " ".join(split_args(msg)).strip()
    if not q and msg.reply_to_message:
        q = f"что скажешь про это: «{msg.reply_to_message.text or msg.reply_to_message.caption or ''}»"
    if not q:
        return await reply(msg, "ai_ask_usage")
    s = await db.settings(msg.chat.id)
    web_block, results = ("", [])
    status = None
    try:
        await msg.bot.send_chat_action(msg.chat.id, "typing")
    except Exception:
        pass
    if s.get("ai_web", 1):
        from websearch import research
        web_block, results = await research(q, context_block(msg.chat.id, 6))
    sys = system_prompt("Тебя спросили что-то по делу (перевод, факт, расчёт, совет). Ответь полезно и точно, 1–6 предложений, в своём стиле, но суть — на первом месте."
                        + (" Ниже результаты веб-поиска — опирайся на них для фактов и цифр, укажи дату, если важна; в конце одной строкой «источник: <url>» для главного источника. "
                           "Если результаты не по теме — скажи, что не нашла." if web_block else ""), with_mood=False)
    out = await llm([{"role": "system", "content": sys}, {"role": "user", "content": q + ("\n\n" + web_block if web_block else "")}], max_tokens=600, temperature=0.4, essential=True)
    if not out:
        return await reply(msg, "ai_off")
    await send_long(msg, out)


@router.message(Command("ai", "ии", prefix="!/"))
async def cmd_ai_stats(msg: Message, bot: Bot):
    """!ai — какие модели подключены и расход за день (ст. админ)."""
    from utils import deny
    if await deny(msg, bot, "settings"):
        return
    from config import LLM_CHEAP_MODEL, LLM_CHEAP_BASE_URL, OPENAI_API_KEY, VISION_MODEL
    u = usage_snapshot()
    from config import LLM_DAILY_TOKENS
    host = lambda b: b.split("//")[-1].split("/")[0]
    await msg.answer(f"🧠 мозг: <code>{LLM_MODEL}</code> @ {host(LLM_BASE_URL)} — {u['main_calls']} вызовов, {u['main_tokens']:,} токенов сегодня\n"
                     f"🔧 дешёвый контур: <code>{LLM_CHEAP_MODEL}</code> @ {host(LLM_CHEAP_BASE_URL)} — {u['cheap_calls']} вызовов, {u['cheap_tokens']:,} токенов\n"
                     f"👁 зрение/слух: {'<code>' + VISION_MODEL + '</code> + whisper' if OPENAI_API_KEY else 'нет ключа (OPENAI_API_KEY)'}\n"
                     f"🌐 веб-поиск: {'вкл' if (await db.settings(msg.chat.id)).get('ai_web', 1) else 'выкл'}\n"
                     f"📉 потолок: {LLM_DAILY_TOKENS:,} токенов/сутки" + (" — ПРЕВЫШЕН, работают только ответы по обращению" if over_budget() else "")).replace(",", " ")


# ======================= 1b. отвечает на вопросы в чат без обращения =======================
QUESTION_RE = re.compile(r"\?\s*$|^(?:кто|что|как|какой|какая|какие|где|когда|почему|зачем|сколько|можно ли|есть ли|стоит ли|правда ли|а если|посоветуйте|подскажите|кто знает|кто-нибудь знает|объясните)\b", re.I)
_last_answer: dict[int, float] = defaultdict(float)


async def maybe_answer_question(msg: Message, bot: Bot):
    """Вопрос в чат (не ответом и не конкретному человеку) → ждём ai_answer_wait секунд; если никто не ответил — отвечаем как ИИ, по делу."""
    chat_id = msg.chat.id
    text = (msg.text or "").strip()
    s = await db.settings(chat_id)
    if not s.get("ai_answer", 1) or not LLM_API_KEY:
        return
    if msg.reply_to_message or len(text) < 15 or len(text) > 700 or "@" in text or not QUESTION_RE.search(text):
        return
    if time.time() - _last_answer[chat_id] < int(s.get("ai_answer_gap", 180)):
        return
    wait = int(s.get("ai_answer_wait", 90))
    await asyncio.sleep(wait)
    # кто-то уже ответил?
    after = await db.messages_since(chat_id, msg.date.timestamp() if msg.date else int(time.time()) - wait, 50)
    after = [m for m in after if m["msg_id"] != msg.message_id and m["user_id"] != msg.from_user.id]
    if any(m["reply_to"] == msg.message_id for m in after) or len(after) >= 4:
        return
    web_block = ""
    if s.get("ai_web", 1):
        from websearch import research
        web_block, _ = await research(text, context_block(chat_id, 6))
    res = await llm_json([
        {"role": "system", "content": system_prompt(
            ("Тебе доступны результаты веб-поиска по этому вопросу — используй их для фактов, цифр и дат, в конце ответа добавь строку «источник: <url>». " if web_block else "") +
            "В чате задали вопрос, и никто не ответил. Реши, стоит ли тебе ответить КАК ИИ-ПОМОЩНИК: отвечай, если это вопрос на знание, факт, совет, "
            "объяснение, расчёт, перевод, рекомендацию, «как сделать», «что выбрать», «правда ли» — то, на что у тебя есть полезный ответ. "
            "НЕ отвечай, если вопрос риторический, обращён к конкретному человеку или к чату про их личные дела («кто идёт гулять?», «где Мурик?»), "
            "если это часть спора между людьми или если полезно ответить ты не можешь. "
            'Верни JSON: {"answer": true/false, "text": "ответ"}. Ответ: полезный и точный, суть сначала, 2–8 предложений, без markdown, в твоём стиле, '
            "но без ужимок — человек хочет ответ, а не шоу. Если не уверена в факте — скажи, что не уверена. Не выдумывай ссылок и цифр.", with_mood=False)},
        {"role": "user", "content": f"Контекст:\n{context_block(chat_id, 8)}\n\nВопрос от {who(msg)}: {text}" + (f"\n\n{web_block}" if web_block else "")}], max_tokens=700, temperature=0.4)
    if not isinstance(res, dict) or not res.get("answer") or not res.get("text"):
        return
    _last_answer[chat_id] = time.time()
    out = str(res["text"]).strip()
    try:
        sent = await msg.reply(html.escape(out)[:3900])
    except TelegramBadRequest:
        sent = await msg.answer(html.escape(out)[:3900])
    await db.remember_bot_message(chat_id, sent.message_id)
    _history[chat_id].append(("саррочка", out[:300]))
    await db.log_event(chat_id, "answer", f"🤖 ответила на вопрос {mention(msg.from_user.id, who(msg))}: {html.escape(text[:60])}")


# ======================= 2. умное вмешательство + 3. токсичность/скам =======================
async def analyze_message(msg: Message, bot: Bot):
    """Из middleware: копим контекст; раз в N сообщений спрашиваем модель, стоит ли встрять; проверяем токсичность/скам."""
    chat_id = msg.chat.id
    text = (msg.text or msg.caption or "").strip()
    if not text or text.startswith(("/", "!", "+", "-")) or not LLM_API_KEY:
        return
    remember(msg)
    s = await db.settings(chat_id)
    rank = await rank_of(bot, chat_id, msg.from_user.id)
    if msg.text and not NAME_RE.match(msg.text):
        asyncio.create_task(maybe_answer_question(msg, bot))

    # --- токсичность и скам: одна дешёвая классификация на сообщение длиннее 12 символов ---
    if (s.get("ai_mod", 0) or s.get("ai_scam", 1)) and len(text) >= 12 and rank < 1:
        res = await llm_json([
            {"role": "system", "content": "Ты классификатор сообщений телеграм-чата. Верни только JSON: "
             '{"toxic": 0-3, "scam": 0-3, "reason": "кратко"}. toxic: 0 нормально, 1 грубовато, 2 оскорбление/травля конкретного человека, '
             "3 угрозы/ненависть по признаку. scam: 0 нет, 1 реклама, 2 «заработок/пишите в лс/крипта/ставки», 3 явное мошенничество (сбор денег, фишинг). "
             "Мат сам по себе — не токсичность. Шутки между своими — 0–1."},
            {"role": "user", "content": f"Контекст:\n{context_block(chat_id, 6)}\n\nСообщение {who(msg)}: {text}"}], max_tokens=80, tier="cheap")
        if res:
            tox, scam = int(res.get("toxic", 0) or 0), int(res.get("scam", 0) or 0)
            reason = str(res.get("reason", ""))[:100]
            if s.get("ai_scam", 1) and scam >= 3:
                try:
                    await msg.delete()
                    await bot.restrict_chat_member(chat_id, msg.from_user.id, MUTE_PERMS, until_date=int(time.time()) + 24 * 3600)
                except TelegramBadRequest:
                    pass
                await db.log_event(chat_id, "scam", f"🚫 скам от {mention(msg.from_user.id, who(msg))}: {html.escape(reason)}")
                return await reply(msg, "ai_scam", user=mention(msg.from_user.id, who(msg)), reason=html.escape(reason))
            if s.get("ai_mod", 0) and tox >= 2:
                lvl = int(s.get("ai_mod_level", 2))
                if tox >= lvl:
                    row = await db.user(chat_id, msg.from_user.id)
                    total = await db.add_warn(chat_id, msg.from_user.id, 0, f"ИИ: {reason}", warn_weight(row["mass"] if row else 0))
                    await db.add_mass(chat_id, msg.from_user.id, MASS_PER_WARN)
                    await db.log_event(chat_id, "warn", f"⚠️ авто-пред {mention(msg.from_user.id, who(msg))}: {html.escape(reason)}")
                    await reply(msg, "ai_toxic_warn", user=mention(msg.from_user.id, who(msg)), reason=html.escape(reason), n=total, limit=s["warn_ban"])
                    if total >= s["warn_mute"]:
                        secs = int(s["automute_hours"] * 3600)
                        try:
                            await bot.restrict_chat_member(chat_id, msg.from_user.id, MUTE_PERMS, until_date=int(time.time()) + secs)
                            await reply(msg, "warn_automute", user=mention(msg.from_user.id, who(msg)), time=human_duration(secs))
                        except TelegramBadRequest:
                            pass
                    return
                else:
                    await reply(msg, "ai_toxic_soft", user=mention(msg.from_user.id, who(msg)))

    # --- умное вмешательство (счётчик) — только если «пульс» выключен ---
    if not s.get("ai_interject", 1) or s.get("pulse", 1):
        return
    _since_interject[chat_id] += 1
    every = int(s.get("ai_interject_every", 15))
    if _since_interject[chat_id] < every or time.time() - _last_interject.get(chat_id, 0) < 600:
        return
    _since_interject[chat_id] = 0
    res = await llm_json([
        {"role": "system", "content": system_prompt("Ты читаешь чат и решаешь, стоит ли сейчас вставить реплику. Повод: спор (замечаешь противоречие), нелепое уверенное утверждение, "
         "кто-то грустит (тогда ласково), флирт, кто-то написал простыню, тишина, никто давно не делал тебе комплимент, кто-то упомянул ботов. "
         'Верни JSON: {"say": true/false, "text": "реплика 1–2 предложения или пустая строка", "react": "эмодзи или пустая строка"}. '
         "В 70% случаев повода нет — say:false. Если повод мелкий (пикми-сообщение, клоунада, нытьё, флирт) — лучше не писать, а поставить реакцию на последнее сообщение: "
         "react из набора 💅 🤡 💔 💘 🔥 🤔 🙈 😱 👀 🗿 💋 🥱, text пустой. Не повторяй то, что уже говорила.", await db.mood(chat_id))},
        {"role": "user", "content": context_block(chat_id, 20)}], max_tokens=150)
    if not res:
        return
    react = str(res.get("react") or "").strip()
    if react and not (res.get("say") and res.get("text")) and s.get("reactions", 1):
        from handlers.nominations import set_reaction
        await set_reaction(bot, chat_id, msg.message_id, react)
        _last_interject[chat_id] = time.time() - 300   # реакция — полповода, следующий текст можно раньше
        return
    if res.get("say") and res.get("text"):
        _last_interject[chat_id] = time.time()
        sent = await msg.answer(html.escape(str(res["text"])[:400]))
        await db.remember_bot_message(chat_id, sent.message_id)
        _history[chat_id].append(("саррочка", str(res["text"])[:300]))


# ======================= 4. разбор спора: кто прав =======================
@router.message(Command("ктоправ", "кто_прав", "рассуди", prefix="!+/"))
async def cmd_judge_dispute(msg: Message):
    if not msg.reply_to_message:
        return await reply(msg, "ai_dispute_usage")
    chat_id = msg.chat.id
    since = int(time.time()) - 3 * 3600
    msgs = await db.messages_since(chat_id, since, 300)
    start_id = msg.reply_to_message.message_id
    thread = [m for m in msgs if m["msg_id"] and m["msg_id"] >= start_id and m["text"]]
    if len(thread) < 3:
        return await reply(msg, "ai_dispute_short")
    transcript = "\n".join(f"{m['nick'] or m['first_name']}: {m['text'][:250]}" for m in thread[-80:])
    sys = system_prompt("Тебя просят рассудить спор. Прочитай ветку, определи стороны и аргументы, найди логические ошибки и вынеси вердикт: кто прав, кто нет и почему, "
                        "5–8 строк. Справедливо, с цитатами в кавычках. Если обе стороны частично правы — так и скажи. Споришь как адвокат, заканчиваешь как Саррочка.", with_mood=False)
    out = await llm([{"role": "system", "content": sys}, {"role": "user", "content": f"Спор:\n{transcript}"}], max_tokens=500, temperature=0.5)
    if not out:
        return await reply(msg, "ai_off")
    await send_long(msg, "⚖️ " + out)


# ======================= 5. что пропустил =======================
MISSED_RE = re.compile(r"^(?:саррочка|сарочка|сара)?[,!\s]*(?:что\s+(?:я\s+)?пропустил|что\s+было|что\s+тут\s+было|что\s+нового|что\s+обсуждали|я\s+всё\s+пропустил)[?!.\s]*$", re.I)


@router.message(F.text.regexp(MISSED_RE))
@router.message(Command("пропустил", "чтобыло", "missed", prefix="!+/"))
async def cmd_missed(msg: Message):
    chat_id, uid = msg.chat.id, msg.from_user.id
    row = await db.user(chat_id, uid)
    last_seen = (row["last_seen"] if row else 0) or 0
    # последний актив ДО этого сообщения: берём его предыдущее сообщение из лога
    mine = await db.user_messages(chat_id, uid, 2)
    since = mine[-2]["ts"] if len(mine) >= 2 else max(last_seen, int(time.time()) - 24 * 3600)
    since = max(since, int(time.time()) - 3 * 86400)
    msgs = await db.messages_since(chat_id, since, 400)
    texts = [m for m in msgs if m["text"] and not m["text"].startswith(("/", "!", "+"))]
    if len(texts) < 5:
        return await reply(msg, "ai_missed_nothing", user=await nm(chat_id, uid, who(msg)))
    events = await db.events(chat_id, since, 15)
    transcript = "\n".join(f"[{time.strftime('%d.%m %H:%M', time.localtime(m['ts']))}] {m['nick'] or m['first_name']}: {m['text'][:200]}" for m in texts[-250:])
    ev = "\n".join(e["text"] for e in events) or "—"
    sys = system_prompt(f"{who(msg)} вернулся в чат и спрашивает, что пропустил. Перескажи ему лично (на «ты»), 4–7 строк: главные темы, кто что учудил, события. "
                        "Только факты из переписки, имена как написаны.", await db.mood(chat_id))
    out = await llm([{"role": "system", "content": sys}, {"role": "user", "content": f"События:\n{ev}\n\nПереписка:\n{transcript}"}], max_tokens=450)
    if not out:
        return await reply(msg, "ai_off")
    await send_long(msg, out)


# ======================= 6. подпись к мему =======================
@router.message(Command("мем", "подпись", "caption", prefix="!+/"))
async def cmd_meme(msg: Message):
    src = msg.reply_to_message
    hint = " ".join(split_args(msg))
    if not src or not (src.photo or src.video or src.animation or src.sticker or src.text):
        return await reply(msg, "ai_meme_usage")
    desc = src.caption or src.text or ("стикер" if src.sticker else "картинка/видео без подписи")
    sys = system_prompt("Придумай подпись к мему для этого чата: 1–2 строки, сухой сарказм или неожиданный вывод, можно упомянуть автора.", await db.mood(msg.chat.id))
    out = await llm([{"role": "system", "content": sys},
                     {"role": "user", "content": f"Автор: {src.from_user.first_name if src.from_user else 'кто-то'}. Что на картинке/в сообщении: {desc[:300]}. "
                                                 f"Подсказка: {hint or 'нет'}. Контекст чата:\n{context_block(msg.chat.id, 8)}"}], max_tokens=120, temperature=1.0)
    if not out:
        return await reply(msg, "ai_off")
    sent = await src.reply(html.escape(out))
    await db.remember_bot_message(msg.chat.id, sent.message_id)


# ======================= 7. вопрос дня от модели =======================
async def ai_question_of_day(chat_id: int) -> str | None:
    since = int(time.time()) - 86400
    msgs = await db.messages_since(chat_id, since, 200)
    texts = [m["text"][:150] for m in msgs if m["text"] and not m["text"].startswith(("/", "!", "+"))]
    if len(texts) < 10:
        return None
    out = await llm([{"role": "system", "content": system_prompt("Придумай один «вопрос дня» для чата по мотивам вчерашних разговоров: "
                      "неудобный, философский или провокационный — такой, чтобы захотелось ответить. Только сам вопрос, одна строка, без кавычек.", with_mood=False)},
                     {"role": "user", "content": "\n".join(texts[-120:])}], max_tokens=80, temperature=1.0)
    return out


# ======================= 8. совместимость =======================
@router.message(Command("совместимость", "пара?", "шип", "match", prefix="!+/"))
async def cmd_match(msg: Message):
    chat_id = msg.chat.id
    from utils import resolve_target
    b_id, b_name, args = await resolve_target(msg)
    a_id, a_name = msg.from_user.id, who(msg)
    # две цели: !совместимость @a @b
    ids = [a for a in args if a.startswith("@")]
    if len(ids) >= 1 and b_id:
        row = await db.find_user_by_username(chat_id, ids[-1])
        if row and row["user_id"] != b_id:
            a_id, a_name, b_id, b_name = b_id, b_name, row["user_id"], row["first_name"]
    if not b_id or b_id == a_id:
        return await reply(msg, "ai_match_usage")
    ta = [m["text"][:150] for m in await db.user_messages(chat_id, a_id, 60)]
    tb = [m["text"][:150] for m in await db.user_messages(chat_id, b_id, 60)]
    if len(ta) < 3 or len(tb) < 3:
        return await reply(msg, "ai_match_short")
    sys = system_prompt('Оцени совместимость двух участников по их манере общения. Верни JSON: {"percent": 0-100, "verdict": "3–5 строк в твоём стиле: что общего, что бесит, вердикт"}. '
                        "Опирайся только на сообщения.", with_mood=False)
    res = await llm_json([{"role": "system", "content": sys},
                          {"role": "user", "content": f"{a_name}:\n" + "\n".join(ta) + f"\n\n{b_name}:\n" + "\n".join(tb)}], max_tokens=350)
    if not res:
        return await reply(msg, "ai_off")
    await reply(msg, "ai_match", a=await nm(chat_id, a_id, a_name), b=await nm(chat_id, b_id, b_name),
                percent=int(res.get("percent", 50)), text=html.escape(str(res.get("verdict", ""))))


# ======================= 9. гороскоп =======================
@router.message(Command("гороскоп", "horoscope", prefix="!+/"))
async def cmd_horoscope(msg: Message):
    chat_id, uid = msg.chat.id, msg.from_user.id
    texts = [m["text"][:120] for m in await db.user_messages(chat_id, uid, 30)]
    act = await db.activity(chat_id, uid)
    row = await db.user(chat_id, uid)
    facts = f"сообщений сегодня {act['day']}, за неделю {act['week']}, масса {int(row['mass']) if row else 0}, в браке: {len(await db.partners(chat_id, uid))}, влюблён: {bool(await db.crush(chat_id, uid))}"
    sys = system_prompt("Напиши шуточный гороскоп на сегодня для участника чата: 3–4 строки, по его активности и манере, с «предсказанием» про чат, любовь и дуэли.", await db.mood(chat_id))
    seed = f"{time.strftime('%Y-%m-%d')}:{uid}"
    out = await llm([{"role": "system", "content": sys}, {"role": "user", "content": f"Имя: {who(msg)}. Факты: {facts}. Сид дня: {seed}.\nЕго сообщения:\n" + "\n".join(texts)}], max_tokens=220, temperature=1.0)
    if not out:
        return await reply(msg, "ai_off")
    await send_long(msg, "🔮 " + out)


# ======================= 10. авто-номинации вечером =======================
AI_NOMS = ["философ дня", "душнила дня", "романтик дня", "комик дня", "драматург дня", "самый загадочный", "оптимист дня", "ворчун дня"]


async def ai_nominations(bot: Bot, chat_id: int) -> str | None:
    since = int(time.time()) - 86400
    msgs = await db.messages_since(chat_id, since, 500)
    texts = [m for m in msgs if m["text"] and not m["text"].startswith(("/", "!", "+"))]
    if len(texts) < 40:
        return None
    by_user: dict[int, list] = defaultdict(list)
    names = {}
    for m in texts:
        by_user[m["user_id"]].append(m["text"][:120])
        names[m["user_id"]] = m["nick"] or m["first_name"]
    top = sorted(by_user.items(), key=lambda kv: -len(kv[1]))[:12]
    sample = "\n\n".join(f"[{uid}] {names[uid]}:\n" + "\n".join(t[-15:]) for uid, t in top)
    picks = random.sample(AI_NOMS, 3)
    res = await llm_json([{"role": "system", "content": system_prompt(f"Выбери победителей в номинациях {picks} по сообщениям участников. "
                           'Верни JSON: {"<номинация>": {"id": число_в_квадратных_скобках, "why": "одна строка почему, в твоём стиле"}, ...}. '
                           "Только по реальным сообщениям. Если по номинации никто не подходит — пропусти её.", with_mood=False)},
                          {"role": "user", "content": sample}], max_tokens=400)
    if not res:
        return None
    lines = []
    for nom, v in res.items():
        try:
            uid = int(v.get("id"))
        except (TypeError, ValueError, AttributeError):
            continue
        if uid not in names:
            continue
        await db.give_coin(chat_id, 0, uid, nom, 5)
        await db.log_event(chat_id, "nom", f"🎭 {nom} — {await nm(chat_id, uid)}")
        lines.append(f"🎭 <b>{html.escape(nom)}</b> — {await nm(chat_id, uid)}: {html.escape(str(v.get('why', '')))}")
    return "\n".join(lines) or None


# ======================= 11. итоги месяца (wrapped) =======================
@router.message(Command("итоги", "wrapped", "мойгод", "моймесяц", prefix="!+/"))
async def cmd_wrapped(msg: Message):
    chat_id, uid = msg.chat.id, msg.from_user.id
    row = await db.user(chat_id, uid)
    if not row:
        return
    from handlers.coins import month_key
    act = await db.activity(chat_id, uid)
    series = await db.activity_series(chat_id, uid, 30)
    best_day = max(series.items(), key=lambda kv: kv[1]) if series else ("—", 0)
    hours = defaultdict(int)
    texts = []
    for m in await db.user_messages(chat_id, uid, 300):
        hours[time.localtime(m["ts"]).tm_hour] += 1
        texts.append(m["text"][:120])
    peak_hour = max(hours.items(), key=lambda kv: kv[1])[0] if hours else 0
    ds = await db.duel_stats(chat_id, uid)
    facts = (f"имя {row['nick'] or row['first_name']}; сообщений за месяц {act['month']}; самый активный день {best_day[0]} ({best_day[1]} сообщений); "
             f"любимый час {peak_hour}:00; масса {int(row['mass'])}; коинов за месяц {await db.coins_month(chat_id, uid, month_key())}; "
             f"место по коинам #{await db.coins_rank(chat_id, uid, month_key())}; преды {await db.active_warns(chat_id, uid)}; "
             f"дуэли {ds['wins'] if ds else 0}/{ds['losses'] if ds else 0}; браков {len(await db.partners(chat_id, uid))}; "
             f"ачивки {', '.join(await db.achievements(chat_id, uid)) or 'нет'}")
    sys = system_prompt("Сделай персональные «итоги месяца» в духе Spotify Wrapped для участника: 6–9 коротких строк с цифрами из фактов и 2–3 наблюдениями "
                        "по его сообщениям (любимая тема, фирменное слово, настроение). Обращайся на «ты».", await db.mood(chat_id))
    out = await llm([{"role": "system", "content": sys}, {"role": "user", "content": f"Факты: {facts}\nСообщения:\n" + "\n".join(texts[-100:])}], max_tokens=450)
    if not out:
        return await reply(msg, "ai_off")
    await send_long(msg, "🎁 " + out)
