"""!кто я / !кто ты (ответом) / /me — розовая карточка профиля картинкой (аватар, ранг, масса, коины, график за год, браки, ачивки, описание)."""
import asyncio
import html
import io
import os
import time
from datetime import date, timedelta
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from db import db
from phrases import ACHIEVEMENTS
from utils import reply, mention, level, resolve_target, rank_of, rank_name, split_args

router = Router()


def _ago(ts: int | None) -> str:
    if not ts:
        return "—"
    d = int(time.time()) - ts
    if d < 60:
        return "только что"
    if d < 3600:
        return f"{d // 60} мин"
    if d < 86400:
        return f"{d // 3600} ч"
    return f"{d // 86400} дн"


def _since(ts: int | None) -> str:
    if not ts:
        return "—"
    d0 = date.fromtimestamp(ts)
    days = (date.today() - d0).days
    y, rem = divmod(days, 365)
    mo, dd = divmod(rem, 30)
    parts = [f"{y} г" if y else "", f"{mo} мес" if mo else "", f"{dd} дн" if (dd and not y) else ""]
    return f"{d0:%d.%m.%Y} ({' '.join(p for p in parts if p) or 'сегодня'})"


def _fmt(n: int) -> str:
    return f"{n / 1000:.1f}k".replace(".0k", "k") if n >= 1000 else str(n)


async def card_data(bot: Bot, chat_id: int, uid: int, fallback_name: str | None) -> dict:
    row = await db.user(chat_id, uid)
    name = ((row["nick"] or row["first_name"]) if row else None) or fallback_name or "кто-то"
    mass = row["mass"] if row else 0
    rank = await rank_of(bot, chat_id, uid)
    try:
        cm = await bot.get_chat_member(chat_id, uid)
        tg_admin = cm.status in ("administrator", "creator")
        username = cm.user.username
    except TelegramBadRequest:
        tg_admin, username = False, (row["username"] if row else None)
    avatar = None
    try:
        photos = await bot.get_user_profile_photos(uid, limit=1)
        if photos.total_count:
            f = await bot.get_file(photos.photos[0][-1].file_id)
            buf = io.BytesIO()
            await bot.download_file(f.file_path, buf)
            avatar = buf.getvalue()
    except Exception:
        pass
    partners, crush = await db.partners(chat_id, uid), await db.crush(chat_id, uid)
    pnames = []
    for p in partners:
        pr = await db.user(chat_id, p)
        pnames.append(((pr["nick"] or pr["first_name"]) if pr else None) or "кто-то")
    crush_t = None
    if crush:
        c = await db.user(chat_id, crush)
        crush_t = (((c["nick"] or c["first_name"]) if c else None) or "кто-то", await db.crush(chat_id, crush) == uid)
    ds = await db.duel_stats(chat_id, uid) or {"wins": 0, "losses": 0, "cowards": 0}
    gender = None
    if row and row["gender"]:
        gender = ("муж." if row["gender"].startswith("м") else "жен.") + (" (авто)" if row["gender"].endswith("?") else "")
    return {
        "name": name, "username": username, "rank": rank, "rank_name": rank_name(rank), "tg_admin": tg_admin,
        "title": row["title"] if row else None, "gender": gender, "city": row["city"] if row else None, "birthday": row["birthday"] if row else None,
        "mass": mass, "level": level(mass), "place": await db.rank(chat_id, uid), "coins": await db.coins_total(chat_id, uid),
        "msgs": row["msgs"] if row else 0, "joined": _since(row["joined_at"] if row else None), "last_active": _ago(row["last_seen"] if row else None),
        "act": await db.activity(chat_id, uid), "warns": await db.active_warns(chat_id, uid),
        "duels": {"wins": ds["wins"], "losses": ds["losses"], "cowards": ds["cowards"]},
        "partners": pnames, "crush": crush_t, "love_n": await db.sarra_love_count(chat_id, uid),
        "achievements": [ACHIEVEMENTS.get(a, a[7:] if a.startswith("custom:") else a) for a in await db.achievements(chat_id, uid)],
        "bio": row["bio"] if row else None, "series": await db.activity_series(chat_id, uid, 365), "avatar": avatar,
        "chat_title": "",
    }


def card_kb(uid: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🏆 Награды", callback_data=f"who:ach:{uid}"),
         InlineKeyboardButton(text="💞 Отношения", callback_data=f"who:rel:{uid}")],
        [InlineKeyboardButton(text="⚠️ Преды", callback_data=f"who:warns:{uid}"),
         InlineKeyboardButton(text="🪙 Коины", callback_data=f"who:coins:{uid}")],
    ])


async def send_card(msg: Message, bot: Bot, uid: int, name: str | None):
    chat_id = msg.chat.id
    d = await card_data(bot, chat_id, uid, name)
    d["chat_title"] = msg.chat.title or ""
    from phrases import say
    from utils import style
    caption = say(await style(chat_id), "who_caption", chat_id=chat_id, user=mention(uid, d["name"]), mass=int(d["mass"]), coins=d["coins"], rank=d["rank_name"])
    try:
        import profile_card
        png = await asyncio.get_running_loop().run_in_executor(None, profile_card.draw, d)
        sent = await msg.answer_photo(BufferedInputFile(png, "profile.png"), caption=caption[:1024], reply_markup=card_kb(uid))
    except Exception as e:
        import logging
        logging.warning("profile card: %s", e)
        sent = await msg.answer(caption, reply_markup=card_kb(uid))
    await db.remember_bot_message(chat_id, sent.message_id)


@router.message(Command("кто", "who", "whoami", prefix="!/+"))
async def cmd_who(msg: Message, bot: Bot):
    """!кто я · !кто ты (ответом) · !кто @юзер"""
    args = split_args(msg)
    uid, name, _ = await resolve_target(msg)
    if args and args[0].lower() in ("я", "me", "i") and not msg.reply_to_message:
        uid, name = msg.from_user.id, msg.from_user.first_name
    if not uid:
        uid, name = msg.from_user.id, msg.from_user.first_name
    await db.touch_user(msg.chat.id, msg.from_user)
    await send_card(msg, bot, uid, name)


@router.message(Command("описание", "bio", prefix="+!/"))
async def cmd_bio(msg: Message):
    """+описание текст — своё описание в карточке; +описание снять."""
    await db.touch_user(msg.chat.id, msg.from_user)
    text = " ".join(split_args(msg)).strip()
    if not text:
        return await msg.answer("+описание текст — и оно появится в твоей карточке. +описание снять — убрать.")
    if text.lower() in ("снять", "удалить", "-"):
        await db.set_bio(msg.chat.id, msg.from_user.id, None)
        return await msg.answer("описание убрала. ты снова загадка.")
    await db.set_bio(msg.chat.id, msg.from_user.id, text[:200])
    await msg.answer("записала. теперь все будут знать. ну, кто спросит !кто ты.")


@router.callback_query(F.data.startswith("who:"))
async def on_who_button(cb: CallbackQuery, bot: Bot):
    _, what, uid = cb.data.split(":")
    uid, chat_id = int(uid), cb.message.chat.id
    row = await db.user(chat_id, uid)
    name = mention(uid, (row["nick"] or row["first_name"]) if row else None)
    if what == "ach":
        ach = await db.achievements(chat_id, uid)
        text = f"🏆 награды {name}:\n" + ("\n".join(f"🎗 {ACHIEVEMENTS.get(a, a[7:] if a.startswith('custom:') else a)}" for a in ach) or "пока нет. но я верю.")
    elif what == "rel":
        partners, crush = await db.partners(chat_id, uid), await db.crush(chat_id, uid)
        parts = []
        for partner in partners:
            p = await db.user(chat_id, partner); parts.append(f"💍 в браке с {mention(partner, (p['nick'] or p['first_name']) if p else None)}")
        if crush:
            c = await db.user(chat_id, crush); parts.append(f"💘 влюблён(а) в {mention(crush, (c['nick'] or c['first_name']) if c else None)}")
        text = f"💞 {name}:\n" + ("\n".join(parts) or "свободен(а). как птица. как я.")
    elif what == "warns":
        rows = await db.list_warns(chat_id, uid)
        text = f"⚠️ преды {name}:\n" + ("\n".join(
            f"• {html.escape(r['reason'])} ({time.strftime('%d.%m', time.localtime(r['created_at']))})" for r in rows) or "чист. как слеза. моя.")
    else:
        from handlers.coins import month_key
        text = (f"🪙 {name}: всего {await db.coins_total(chat_id, uid)}, за месяц {await db.coins_month(chat_id, uid, month_key())}, "
                f"место #{await db.coins_rank(chat_id, uid, month_key())}")
    await cb.answer()
    sent = await bot.send_message(chat_id, text, reply_to_message_id=cb.message.message_id)
    await db.remember_bot_message(chat_id, sent.message_id)


# ---------- ачивки вручную ----------
@router.message(Command("ачивка", "достижение", "ach", prefix="!+"))
async def cmd_ach_give(msg: Message, bot: Bot):
    """!ачивка @юзер название (или ответом) — ст. админ выдаёт ачивку с объявлением в чате."""
    from utils import deny, resolve_target, split_args
    if await deny(msg, bot, "settings"):
        return
    uid, name, rest = await resolve_target(msg)
    title = " ".join(rest).strip()
    if not uid or not title:
        return await reply(msg, "ach_usage")
    key = "custom:" + title[:40].lower()
    row = await db.user(msg.chat.id, uid)
    who = mention(uid, ((row["nick"] or row["first_name"]) if row else None) or name)
    if not await db.give_achievement(msg.chat.id, uid, key):
        return await reply(msg, "ach_dup", user=who, ach=title[:40])
    await db.log_event(msg.chat.id, "ach", f"🏅 {who} — ачивка «{title[:40]}» (от {mention(msg.from_user.id, msg.from_user.first_name)})")
    await reply(msg, "achievement", user=who, ach=title[:40])


@router.message(Command("ачивка", "достижение", "ach", prefix="-"))
async def cmd_ach_del(msg: Message, bot: Bot):
    """-ачивка @юзер название — убрать ачивку (свою или автоматическую по названию)."""
    from utils import deny, resolve_target, split_args
    if await deny(msg, bot, "settings"):
        return
    uid, name, rest = await resolve_target(msg)
    title = " ".join(rest).strip().lower()
    if not uid or not title:
        return await reply(msg, "ach_usage")
    keys = [k for k in await db.achievements(msg.chat.id, uid) if k == "custom:" + title or ACHIEVEMENTS.get(k, "").lower() == title]
    if not keys:
        return await reply(msg, "ach_none", ach=title)
    for k in keys:
        await db.del_achievement(msg.chat.id, uid, k)
    row = await db.user(msg.chat.id, uid)
    await reply(msg, "ach_removed", user=mention(uid, ((row["nick"] or row["first_name"]) if row else None) or name), ach=title)


@router.message(Command("ачивки", "достижения", "achs", prefix="!+/"))
async def cmd_achs(msg: Message, bot: Bot):
    from utils import resolve_target
    uid, name, _ = await resolve_target(msg)
    if not uid:
        uid, name = msg.from_user.id, msg.from_user.first_name
    row = await db.user(msg.chat.id, uid)
    who = mention(uid, ((row["nick"] or row["first_name"]) if row else None) or name)
    ach = await db.achievements(msg.chat.id, uid)
    text = "\n".join(f"🎗 {ACHIEVEMENTS.get(a, a[7:] if a.startswith('custom:') else a)}" for a in ach)
    await reply(msg, "ach_list", user=who, list=text or "пока нет. но я верю.")
