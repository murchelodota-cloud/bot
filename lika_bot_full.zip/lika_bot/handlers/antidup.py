"""Антидубль: «это уже кидали вчера, Абдулла». Ссылки (нормализованные, без utm) и фото (перцептивный хэш) помнятся 7 дней.
Повтор → короткая реплика с автором и временем оригинала. Настройка: antidup (1/0), antidup_days (7)."""
import io
import re
import time
from aiogram import Bot
from aiogram.types import Message
from db import db
from utils import reply, mention

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)
SKIP_HOSTS = ("t.me/", "telegram.me/", "youtube.com/watch", "youtu.be/", "google.", "yandex.")


def norm_url(u: str) -> str:
    u = u.strip().rstrip(".,!?)")
    u = re.sub(r"[?&](utm_[a-z]+|fbclid|igsh|si|feature)=[^&]*", "", u)
    u = u.replace("https://www.", "https://").replace("http://www.", "http://").rstrip("?&/")
    u = re.sub(r"^https?://m\.", "https://", u)
    return u.lower()[:300]


def ahash(data: bytes) -> str | None:
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert("L").resize((9, 8))
        px = list(im.getdata())
        bits = []
        for row in range(8):
            for col in range(8):
                bits.append("1" if px[row * 9 + col] > px[row * 9 + col + 1] else "0")
        return "%016x" % int("".join(bits), 2)
    except Exception:
        return None


def hamming(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def observe(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    s = await db.settings(chat_id)
    if not s.get("antidup", 1):
        return
    days = int(s.get("antidup_days", 7))
    since = int(time.time()) - days * 86400
    text = msg.text or msg.caption or ""
    for raw in URL_RE.findall(text)[:3]:
        if any(h in raw for h in SKIP_HOSTS) and "youtu" not in raw:
            continue
        key = "u:" + norm_url(raw)
        prev = await db.dup_find(chat_id, key, since)
        if prev and prev["user_id"] != uid:
            await _say(msg, prev)
        elif not prev:
            await db.dup_add(chat_id, key, uid, msg.message_id)
    if msg.photo:
        try:
            f = await bot.get_file(msg.photo[-1].file_id)
            buf = io.BytesIO(); await bot.download_file(f.file_path, buf)
            h = ahash(buf.getvalue())
        except Exception:
            h = None
        if h:
            for row in await db.dup_recent(chat_id, "p:", since, 400):
                if hamming(row["key"][2:], h) <= 4:
                    if row["user_id"] != uid:
                        await _say(msg, row)
                    return
            await db.dup_add(chat_id, "p:" + h, uid, msg.message_id)


async def _say(msg: Message, prev):
    ago = int(time.time()) - prev["ts"]
    when = "только что" if ago < 3600 else (f"{ago // 3600} ч назад" if ago < 86400 else ("вчера" if ago < 2 * 86400 else f"{ago // 86400} дн назад"))
    await reply(msg, "dup_notice", user=mention(msg.from_user.id, msg.from_user.first_name), author=await nm(msg.chat.id, prev["user_id"]), when=when)
