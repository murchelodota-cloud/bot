"""Отношения между людьми: кто с кем общается, спорит, смеётся, флиртует. Считается по ответам (reply) в чате.
Используется в диалоге, разборе, прожарке и пульсе: «вы опять вдвоём, как в прошлый вторник». !связи [@юзер] — показать."""
import html
import re
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, resolve_target

router = Router()
ARGUE_RE = re.compile(r"(не согласен|не согласна|неправда|ошибаешься|бред|чушь|ты не прав|докажи|с чего ты взял|ну да конечно|ахах нет|нет,|ты что|что за|глупост|фигн|лож[ьи])", re.I)
KINDS = {"talk": "общается", "argue": "спорит", "laugh": "смеётся над", "flirt": "флиртует"}


async def observe(msg: Message):
    """Из middleware: ответ на чужое сообщение → связь."""
    if not msg.reply_to_message or not msg.reply_to_message.from_user or msg.reply_to_message.from_user.is_bot:
        return
    a, b = msg.from_user.id, msg.reply_to_message.from_user.id
    if a == b:
        return
    chat_id = msg.chat.id
    text = msg.text or msg.caption or ""
    await db.rel_add(chat_id, a, b, "talk")
    from handlers.nominations import LAUGH_RE, SIMP_RE
    if LAUGH_RE.search(text):
        await db.rel_add(chat_id, a, b, "laugh")
    if SIMP_RE.search(text):
        await db.rel_add(chat_id, a, b, "flirt")
    if ARGUE_RE.search(text) or (len(text) > 8 and text.upper() == text and any(c.isalpha() for c in text)):
        await db.rel_add(chat_id, a, b, "argue")


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


async def summary(chat_id: int, uid: int) -> str:
    """Строка для промптов: «чаще всего общается с X и Y; спорит с Z; смеётся над W; флиртует с V»."""
    parts = []
    for kind, verb in KINDS.items():
        rows = await db.rel_top(chat_id, uid, kind, 2)
        rows = [r for r in rows if r["n"] >= (3 if kind == "talk" else 2)]
        if rows:
            parts.append(f"{verb} с " + " и ".join(f"{await plain(chat_id, r['other'])} ({r['n']})" for r in rows) if kind != "laugh"
                         else f"{verb} " + " и ".join(f"{await plain(chat_id, r['other'])} ({r['n']})" for r in rows))
    return ("Его связи в чате: " + "; ".join(parts) + ".") if parts else ""


async def chat_summary(chat_id: int, since: int = 0) -> str:
    """Для пульса/недели: главные пары по спорам, смеху, флирту."""
    out = []
    for kind, lab in (("argue", "вечно спорят"), ("flirt", "флиртуют"), ("laugh", "смеются друг над другом"), ("talk", "больше всех общаются")):
        rows = [r for r in await db.rel_pairs(chat_id, kind, 2, since) if r["n"] >= 3]
        if rows:
            out.append(lab + ": " + ", ".join(f"{await plain(chat_id, r['x'])} и {await plain(chat_id, r['y'])} ({r['n']})" for r in rows))
    return "; ".join(out)


@router.message(Command("связи", "отношенияс", "relations", prefix="!/"))
async def cmd_relations(msg: Message, bot: Bot):
    uid, name, _ = await resolve_target(msg)
    if not uid:
        uid, name = msg.from_user.id, msg.from_user.first_name
    chat_id = msg.chat.id
    lines = []
    for kind, verb in KINDS.items():
        rows = await db.rel_top(chat_id, uid, kind, 3)
        if rows:
            lines.append(f"• {verb}: " + ", ".join(f"{mention(r['other'], await plain(chat_id, r['other']))} ({r['n']})" for r in rows))
    who = mention(uid, await plain(chat_id, uid))
    if not lines:
        return await reply(msg, "rel_empty", user=who)
    await reply(msg, "rel_list", user=who, list="\n".join(lines))
