"""Голос Саррочки. По умолчанию — нейроголос Microsoft (edge-tts, бесплатно, без ключей, ru-RU-SvetlanaNeural).
Если в .env есть ELEVEN_API_KEY и ELEVEN_VOICE_ID — говорит клонированным голосом через ElevenLabs.
!скажи текст — озвучить; !голосом (ответом на её сообщение) — озвучить его; «саррочка, скажи голосом …»;
прожарка и разбор приходят ещё и войсом (tts_roast 1). Настройки: tts (1/0), tts_roast (1/0), tts_max (600 символов)."""
import asyncio
import html
import logging
import os
import re
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, FSInputFile
from db import db
from utils import reply, split_args
from config import MUSIC_DIR, TTS_VOICE, ELEVEN_API_KEY, ELEVEN_VOICE_ID

router = Router()
_cool: dict[int, float] = {}
SAY_RE = re.compile(r"^(?:саррочка|@fromsarrabot)[,!\s]+(?:скажи|озвучь|произнеси)\s+(?:голосом|вслух)?[:,\s]*(.+)$", re.I | re.S)


def _clean(text: str, limit: int) -> str:
    text = re.sub(r"<[^>]+>", "", text)
    text = html.unescape(text)
    text = re.sub(r"[*_`#>]+", "", text)
    text = re.sub(r"https?://\S+", "ссылка", text)
    text = re.sub(r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF]", "", text)   # эмодзи не читаем
    text = re.sub(r"\s+", " ", text).strip()
    return text[:limit]


async def _edge(text: str, out_mp3: str):
    import edge_tts
    comm = edge_tts.Communicate(text, TTS_VOICE or "ru-RU-SvetlanaNeural", rate="+3%", pitch="+12Hz")
    await comm.save(out_mp3)


async def _eleven(text: str, out_mp3: str):
    import aiohttp
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{ELEVEN_VOICE_ID}"
    payload = {"text": text, "model_id": "eleven_multilingual_v2",
               "voice_settings": {"stability": 0.45, "similarity_boost": 0.8, "style": 0.35}}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as sess:
        async with sess.post(url, json=payload, headers={"xi-api-key": ELEVEN_API_KEY, "accept": "audio/mpeg"}) as resp:
            if resp.status != 200:
                raise RuntimeError(f"elevenlabs {resp.status}: {(await resp.text())[:200]}")
            with open(out_mp3, "wb") as f:
                f.write(await resp.read())


async def synth(text: str, chat_id: int) -> str | None:
    """Текст → .ogg (opus) для голосового сообщения. None, если не вышло."""
    os.makedirs(MUSIC_DIR, exist_ok=True)
    base = os.path.join(MUSIC_DIR, f"tts_{chat_id}_{int(time.time() * 1000)}")
    mp3, ogg = base + ".mp3", base + ".ogg"
    try:
        if ELEVEN_API_KEY and ELEVEN_VOICE_ID:
            try:
                await _eleven(text, mp3)
            except Exception as e:
                logging.warning("tts eleven: %s — fallback edge", str(e)[:200])
                await _edge(text, mp3)
        else:
            await _edge(text, mp3)
        if not os.path.exists(mp3) or os.path.getsize(mp3) < 1000:
            return None
        proc = await asyncio.create_subprocess_exec("ffmpeg", "-y", "-loglevel", "error", "-i", mp3, "-c:a", "libopus", "-b:a", "48k", "-vbr", "on", "-ac", "1", ogg)
        await asyncio.wait_for(proc.wait(), 60)
        return ogg if os.path.exists(ogg) and os.path.getsize(ogg) > 500 else None
    except Exception as e:
        logging.warning("tts: %s", str(e)[:300])
        return None
    finally:
        try:
            os.remove(mp3)
        except OSError:
            pass


async def send_voice(msg_or_bot, chat_id: int, text: str, reply_to: int | None = None, caption: str | None = None) -> bool:
    """Озвучить и отправить голосовое. msg_or_bot — Message или Bot."""
    s = await db.settings(chat_id)
    if not s.get("tts", 1):
        return False
    clean = _clean(text, int(s.get("tts_max", 600)))
    if len(clean) < 2:
        return False
    ogg = await synth(clean, chat_id)
    if not ogg:
        return False
    bot = msg_or_bot if isinstance(msg_or_bot, Bot) else msg_or_bot.bot
    try:
        sent = await bot.send_voice(chat_id, FSInputFile(ogg), caption=caption, reply_to_message_id=reply_to)
        await db.remember_bot_message(chat_id, sent.message_id)
        return True
    except Exception as e:
        logging.warning("send voice: %s", str(e)[:200])
        return False
    finally:
        try:
            os.remove(ogg)
        except OSError:
            pass


async def _say(msg: Message, text: str):
    chat_id = msg.chat.id
    if time.time() - _cool.get(chat_id, 0) < 20:
        return await reply(msg, "tts_cooldown")
    _cool[chat_id] = time.time()
    if not text.strip():
        return await reply(msg, "tts_usage")
    ok = await send_voice(msg, chat_id, text, reply_to=msg.message_id)
    if not ok:
        await reply(msg, "tts_fail")


@router.message(Command("скажи", "озвучь", "голос", "say", "tts", prefix="!+/"))
async def cmd_say(msg: Message, bot: Bot):
    text = " ".join(split_args(msg)).strip()
    if not text and msg.reply_to_message:
        text = msg.reply_to_message.text or msg.reply_to_message.caption or ""
    await _say(msg, text)


@router.message(Command("голосом", "voice", prefix="!+/"), F.reply_to_message)
async def cmd_voice_reply(msg: Message, bot: Bot):
    r = msg.reply_to_message
    await _say(msg, r.text or r.caption or "")


@router.message(F.text.regexp(SAY_RE).as_("m"))
async def natural_say(msg: Message, bot: Bot, m: re.Match):
    await _say(msg, m.group(1))
