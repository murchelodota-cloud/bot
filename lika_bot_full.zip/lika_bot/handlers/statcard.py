"""!стата — статистика чата картинкой в розовом Y2K-стиле (график по дням, топ активных, топ по коинам, цифры).
!стата неделя|месяц — период; !стата 20 — старый текстовый топ (обрабатывает iris)."""
import asyncio
import os
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message, FSInputFile
from aiogram.dispatcher.event.bases import SkipHandler
from db import db
from utils import reply, split_args
from config import MUSIC_DIR

router = Router()
PERIODS = {"сутки": 1, "день": 1, "неделя": 7, "неделю": 7, "месяц": 30}

PINK = "#ff5fa2"; PINK2 = "#ffb3d6"; BG = "#fff0f7"; INK = "#3a1f33"; MUTED = "#8a6a7e"; LILAC = "#c9a7ff"


def _draw(path: str, title: str, period: str, days: list[tuple[str, int]], top: list[tuple[str, int]],
          coins: list[tuple[str, int]], kpi: list[tuple[str, str]], footer: str):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    plt.rcParams["font.family"] = "DejaVu Sans"
    fig = plt.figure(figsize=(10, 7.2), dpi=160)
    fig.patch.set_facecolor(BG)
    # фон-градиент
    ax_bg = fig.add_axes([0, 0, 1, 1]); ax_bg.axis("off")
    import numpy as np
    grad = np.linspace(0, 1, 256).reshape(1, -1)
    ax_bg.imshow(grad, extent=[0, 1, 0, 1], aspect="auto", cmap=matplotlib.colors.LinearSegmentedColormap.from_list("p", ["#ffe3f0", "#fff6fb", "#f3e8ff"]), zorder=0)
    for (x, y, r) in [(0.06, 0.93, 0.025), (0.93, 0.08, 0.02), (0.9, 0.9, 0.012), (0.12, 0.1, 0.014)]:
        ax_bg.add_patch(plt.Circle((x, y), r, color=PINK2, alpha=0.6, transform=ax_bg.transAxes, zorder=1))
    fig.text(0.05, 0.93, title, fontsize=20, fontweight="bold", color=PINK, va="center")
    fig.text(0.05, 0.885, period, fontsize=11, color=MUTED, va="center")
    fig.text(0.95, 0.93, "Саррочка", fontsize=12, color=LILAC, ha="right", va="center", style="italic")

    def card(x, y, w, h):
        ax_bg.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.008,rounding_size=0.02", transform=ax_bg.transAxes,
                                       facecolor="white", edgecolor=PINK2, linewidth=1.2, alpha=0.92, zorder=2))

    # KPI плитки
    n = len(kpi); gap = 0.012; w = (0.9 - gap * (n - 1)) / n
    for i, (lab, val) in enumerate(kpi):
        x = 0.05 + i * (w + gap)
        card(x, 0.755, w, 0.09)
        fig.text(x + w / 2, 0.815, val, fontsize=16, fontweight="bold", color=INK, ha="center", va="center")
        fig.text(x + w / 2, 0.775, lab, fontsize=8.5, color=MUTED, ha="center", va="center")

    # график по дням
    card(0.05, 0.36, 0.53, 0.37)
    ax = fig.add_axes([0.09, 0.40, 0.46, 0.27]); ax.set_facecolor("white")
    xs = range(len(days)); ys = [v for _, v in days]
    bars = ax.bar(xs, ys, color=PINK2, width=0.7, zorder=3)
    if ys:
        bars[max(range(len(ys)), key=lambda i: ys[i])].set_color(PINK)
    ax.set_xticks(list(xs)); ax.set_xticklabels([d for d, _ in days], fontsize=7, color=MUTED, rotation=0)
    ax.tick_params(axis="y", labelsize=7, colors=MUTED, length=0); ax.tick_params(axis="x", length=0)
    for sp in ax.spines.values(): sp.set_visible(False)
    ax.grid(axis="y", color="#f1dbe8", zorder=0); ax.set_axisbelow(True)
    fig.text(0.075, 0.70, "сообщений по дням", fontsize=10, fontweight="bold", color=INK)

    # топ активных
    card(0.60, 0.36, 0.35, 0.37)
    fig.text(0.625, 0.70, "самые активные", fontsize=10, fontweight="bold", color=INK)
    mx = max([v for _, v in top] or [1])
    for i, (name, v) in enumerate(top[:7]):
        y = 0.665 - i * 0.041
        fig.text(0.625, y, f"{i + 1}. {name[:16]}", fontsize=8.5, color=INK, va="center")
        ax_bg.add_patch(FancyBboxPatch((0.78, y - 0.008), 0.115 * v / mx, 0.016, boxstyle="round,pad=0.001,rounding_size=0.006",
                                       transform=ax_bg.transAxes, facecolor=PINK if i == 0 else PINK2, edgecolor="none", zorder=3))
        fig.text(0.93, y, str(v), fontsize=8, color=MUTED, ha="right", va="center")

    # топ по коинам
    card(0.05, 0.08, 0.9, 0.25)
    fig.text(0.075, 0.30, "сарра-коины за месяц", fontsize=10, fontweight="bold", color=INK)
    cols = 2
    for i, (name, v) in enumerate(coins[:8]):
        cx = 0.075 + (i % cols) * 0.44; cy = 0.265 - (i // cols) * 0.042
        medal = ["①", "②", "③"][i] if i < 3 else f"{i + 1}."
        fig.text(cx, cy, f"{medal} {name[:22]}", fontsize=9, color=INK, va="center")
        fig.text(cx + 0.40, cy, f"{v:,}".replace(",", " "), fontsize=9, color=PINK, ha="right", va="center", fontweight="bold")
    fig.text(0.95, 0.035, footer, fontsize=8, color=MUTED, ha="right", va="center", style="italic")
    fig.savefig(path, facecolor=fig.get_facecolor())
    plt.close(fig)


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


@router.message(Command("стата", "stats", "статистика", prefix="+!/"))
async def cmd_statcard(msg: Message, bot: Bot):
    args = [a.lower() for a in split_args(msg)]
    if any(a.isdigit() for a in args) or "текст" in args or "вся" in args or "все" in args:
        raise SkipHandler   # текстовый вариант — в iris
    days = next((PERIODS[a] for a in args if a in PERIODS), 7)
    chat_id = msg.chat.id
    status = await reply(msg, "stat_wait")
    since = int(time.time()) - days * 86400
    st = await db.summary_stats(chat_id, since)
    series = await db.chat_daily(chat_id, min(days, 30))
    top = [(await plain(chat_id, r["user_id"]), r["n"]) for r in await db.top_period(chat_id, days, 7)]
    from handlers.coins import month_key
    coins = [(await plain(chat_id, r["user_id"]), r["n"]) for r in await db.coins_top(chat_id, month_key(), 8)]
    newbies = await db.count_joined_since(chat_id, since)
    events = await db.events(chat_id, since, 500)
    marriages = sum(1 for e in events if e["kind"] == "marry")
    duels = sum(1 for e in events if e["kind"] == "duel")
    warns = sum(1 for e in events if e["kind"] in ("warn", "mute", "ban"))
    kpi = [("сообщений", f"{st['msgs']:,}".replace(",", " ")), ("писали", str(st["users"])), ("новых", str(newbies)),
           ("браков", str(marriages)), ("дуэлей", str(duels)), ("предов/мутов", str(warns))]
    period = {1: "за сутки", 7: "за неделю", 30: "за месяц"}.get(days, f"за {days} дн.")
    os.makedirs(MUSIC_DIR, exist_ok=True)
    path = os.path.join(MUSIC_DIR, f"stat_{chat_id}.png")
    title = (msg.chat.title or "чат")[:28]
    try:
        await asyncio.get_running_loop().run_in_executor(
            None, _draw, path, title, f"статистика {period} · {time.strftime('%d.%m.%Y')}", series, top, coins, kpi,
            "too pretty to argue. too smart to lose.")
    except Exception as e:
        import logging
        logging.warning("statcard: %s", e)
        try:
            await status.delete()
        except Exception:
            pass
        raise SkipHandler
    try:
        await status.delete()
    except Exception:
        pass
    from phrases import say
    from utils import style
    sent = await msg.answer_photo(FSInputFile(path), caption=say(await style(chat_id), "stat_caption", chat_id=chat_id, period=period))
    await db.remember_bot_message(chat_id, sent.message_id)
