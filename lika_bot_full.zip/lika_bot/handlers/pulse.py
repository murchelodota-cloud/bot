"""«Пульс чата» — самостоятельность Саррочки.
Раз в pulse_every (2 мин) модель смотрит на последние сообщения, своё состояние (настроение, когда и что говорила, как на это реагировали),
открытые нити (обещания, споры, игры) и заметки о прошлых днях — и сама решает: молчать / реакция / реплика / начать тему / спросить про обещание / запустить игру.
Самооценка: если на её реплики не отвечают — пауза между ними растёт. Ночью (pulse_night_from–pulse_night_to) молчит, пока не позовут.
Заметки о днях: в 23:5x модель пишет 2 строки «что было сегодня» — они попадают в контекст диалога на следующие дни.
Команды: !пульс — состояние; !обещания — открытые нити; -обещание id. Настройки: pulse, pulse_every, pulse_gap (мин), pulse_quiet (мин тишины для инициативы),
pulse_night_from (2), pulse_night_to (10), day_notes."""
import html
import json
import logging
import random
import time
from collections import defaultdict, deque
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, split_args, deny
from config import LLM_API_KEY

router = Router()
_last_tick: dict[int, float] = defaultdict(float)
_actions: dict[int, deque] = defaultdict(lambda: deque(maxlen=20))   # (ts, kind, msg_id, text)
_last_text_action: dict[int, float] = defaultdict(float)
_last_topic: dict[int, float] = defaultdict(float)
_last_poll: dict[int, float] = defaultdict(float)
_day_note_done: dict[int, str] = {}
_owner: dict[int, tuple[float, str]] = {}
_bots: dict[int, Bot] = {}


def bot_for(chat_id: int) -> Bot | None:
    return _bots.get(chat_id)


async def _owner_cache(bot: Bot | None, chat_id: int) -> str:
    if not bot:
        return ""
    ts, val = _owner.get(chat_id, (0, ""))
    if time.time() - ts < 6 * 3600:
        return val
    val = ""
    try:
        for a in await bot.get_chat_administrators(chat_id):
            if a.status == "creator":
                val = a.user.first_name + (f" (@{a.user.username})" if a.user.username else "")
    except Exception:
        pass
    _owner[chat_id] = (time.time(), val)
    return val

ALLOWED = ["silence", "react", "say", "start_topic", "ask_promise", "game", "poll"]


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


def hit_rate(chat_id: int, msgs: list) -> tuple[int, int]:
    """Сколько из последних текстовых действий получили отклик (ответ на её сообщение или ≥2 сообщений в 10 минут после)."""
    acts = [a for a in _actions[chat_id] if a[1] in ("say", "start_topic", "ask_promise")]
    if not acts:
        return 0, 0
    hits = 0
    for ts, kind, mid, _ in acts:
        after = [m for m in msgs if ts < m["ts"] <= ts + 600]
        if any(m["reply_to"] == mid for m in after) or len(after) >= 2:
            hits += 1
    return hits, len(acts)


def chat_mood(msgs: list) -> str:
    """Тон чата по последним 30 сообщениям: эвристика без ИИ."""
    from handlers.nominations import LAUGH_RE, DRAMA_RE, SIMP_RE
    recent = [m for m in msgs if m["text"]][-30:]
    if not recent:
        return "тишина"
    now = time.time()
    span = max(60, now - recent[0]["ts"])
    rate = len(recent) / (span / 60)
    texts = " ".join(m["text"] for m in recent)
    laugh = len(LAUGH_RE.findall(texts)); drama = len(DRAMA_RE.findall(texts)); flirt = len(SIMP_RE.findall(texts))
    caps = sum(1 for m in recent if len(m["text"]) > 8 and m["text"].upper() == m["text"])
    authors = len({m["user_id"] for m in recent})
    hour = time.localtime().tm_hour
    if now - recent[-1]["ts"] > 1800:
        return "тишина"
    if drama + caps >= 6 and authors <= 4:
        return "срач"
    if drama + caps >= 4:
        return "напряжённо"
    if flirt >= 4:
        return "флирт"
    if laugh >= 6:
        return "угар"
    if rate >= 3 and authors >= 5:
        return "движ"
    if 0 <= hour < 6:
        return "ночные посиделки"
    if rate < 0.5:
        return "скука"
    return "спокойно"


MOOD_HINT = {"срач": "в срач не лезь судьёй по умолчанию: либо одной фразой разведи стороны, либо подлей масла, если это весело, либо промолчи",
             "напряжённо": "аккуратнее с сарказмом, лучше реакция или ничего",
             "флирт": "можно одну ироничную реплику про «романтическую линию», не чаще",
             "угар": "поддержи, если есть что добавить, иначе реакция",
             "движ": "не мешай, твоя реплика должна быть лучше среднего сообщения",
             "ночные посиделки": "время философии и тихих вопросов, без громких шуток",
             "скука": "повод для инициативы: вопрос, игра, провокация",
             "тишина": "если тишина долгая — начни разговор, иначе молчи",
             "спокойно": "по ситуации"}


async def state_block(chat_id: int, msgs: list, s: dict) -> str:
    now = time.time()
    mood_lbl = chat_mood(msgs)
    from handlers.relations import chat_summary
    rel = await chat_summary(chat_id, int(now) - 7 * 86400)
    last_human = max((m["ts"] for m in msgs), default=0)
    quiet_min = int((now - last_human) / 60) if last_human else 999
    since_text = int((now - _last_text_action[chat_id]) / 60) if _last_text_action[chat_id] else 999
    hits, total = hit_rate(chat_id, msgs)
    own = [a[3] for a in _actions[chat_id] if a[3]][-8:]
    threads = await db.threads_open(chat_id, 8)
    th_lines = []
    for t in threads:
        th_lines.append(f"  #{t['id']} {await plain(chat_id, t['user_id'])}: {t['text']} (с {time.strftime('%d.%m', time.localtime(t['ts']))}"
                        + (f", срок {t['due']}" if t["due"] else "") + (", уже спрашивала" if t["status"] == "asked" else "") + ")")
    th = "\n".join(th_lines) or "  нет"
    bets = await db.bets_active(chat_id)
    notes = await db.day_notes(chat_id, 4)
    nt = "\n".join(f"  {n['day']}: {n['note']}" for n in notes) or "  нет"
    from handlers.games import _busy
    owner_line = ""
    try:
        from utils import chat_creator
        b = bot_for(chat_id)
        if b:
            cid, cname, cuser = await chat_creator(b, chat_id)
            if cid:
                owner_line = f"Владелица чата и твоя создательница: {cname}" + (f" (@{cuser})" if cuser else "") + ". К ней — теплее, её не подкалывай всерьёз.\n"
    except Exception:
        pass
    return (owner_line + f"Время: {time.strftime('%H:%M, %A')}. Твоё настроение: {int(await db.mood(chat_id))}/100.\n"
            f"Тон чата сейчас: {mood_lbl} — {MOOD_HINT.get(mood_lbl, '')}.\n"
            + (f"Связи за неделю: {rel}.\n" if rel else "")
            + f"Тишина в чате: {quiet_min} мин. С твоей последней реплики: {since_text} мин.\n"
            f"Отклик на твои последние реплики: {hits} из {total} получили ответ" + (" — тебя игнорируют, пиши реже и точнее" if total >= 4 and hits <= total // 4 else "") + ".\n"
            f"Твои последние реплики (не повторяйся):\n  " + ("\n  ".join(own) if own else "нет") + "\n"
            f"Открытые нити (обещания, планы участников):\n{th}\n"
            f"Активные споры: {len(bets)}. Игра сейчас идёт: {'да' if _busy(chat_id) else 'нет'}.\n"
            f"Заметки о прошлых днях:\n{nt}")


async def pulse_tick(bot: Bot):
    if not LLM_API_KEY:
        return
    now = time.time()
    for chat_id in await db.all_chats():
        try:
            s = await db.settings(chat_id)
            if not s.get("pulse", 1) or chat_id > 0:
                continue
            if now - _last_tick[chat_id] < int(s.get("pulse_every", 2)) * 60:
                continue
            _last_tick[chat_id] = now
            await _tick_chat(bot, chat_id, s)
        except Exception as e:
            logging.warning("pulse %s: %s", chat_id, str(e)[:200])


async def _tick_chat(bot: Bot, chat_id: int, s: dict):
    now = time.time()
    _bots[chat_id] = bot
    hour = time.localtime().tm_hour
    nf, nt = int(s.get("pulse_night_from", 2)), int(s.get("pulse_night_to", 10))
    if (nf <= hour < nt) if nf < nt else (hour >= nf or hour < nt):
        return
    await maybe_day_note(bot, chat_id, s)
    msgs = await db.messages_since(chat_id, int(now) - 6 * 3600, 400)
    human = [m for m in msgs if m["text"]]
    if not human:
        return
    last_human = human[-1]["ts"]
    quiet_min = (now - last_human) / 60
    gap = int(s.get("pulse_gap", 10))
    hits, total = hit_rate(chat_id, msgs)
    if total >= 4 and hits <= total // 4:
        gap *= 2   # игнорируют — реже
    since_text = (now - _last_text_action[chat_id]) / 60
    recent_new = [m for m in human if m["ts"] > _last_tick.get(chat_id, 0) - 180]
    # нечего решать: ни новых сообщений, ни тишины для инициативы
    quiet_need = int(s.get("pulse_quiet", 40))
    if not recent_new and quiet_min < quiet_need:
        return
    if quiet_min >= quiet_need and now - _last_topic[chat_id] < 2 * 3600:
        return
    ctx = "\n".join(f"[{m['msg_id']}] {m['nick'] or m['first_name']}" + (f" (отвечает на {m['reply_to']})" if m["reply_to"] else "") + f": {m['text'][:220]}"
                    for m in human[-25:])
    from handlers.ai import llm_json
    from persona import system_prompt
    can_text = since_text >= gap
    task = ("Ты сама решаешь, что сделать в чате прямо сейчас. Варианты action: "
            "silence — ничего (по умолчанию, в большинстве случаев); "
            "react — поставить реакцию на одно из последних сообщений (эмодзи из 💅 🤡 💔 💘 🔥 🤔 🙈 😱 👀 🗿 💋 🥱 👏 ❤ 😁), укажи msg_id; "
            "say — короткая реплика по делу (спор с противоречием, нелепое уверенное заявление, кому-то плохо — тогда без сарказма, флирт, простыня, тебя упомянули); "
            "start_topic — если в чате тишина: сама начни разговор (неудобный вопрос, зацепка из заметок о прошлых днях или из нитей, провокация, мини-наблюдение) — не «как дела»; "
            "ask_promise — спросить участника про его обещание/план из открытых нитей (укажи thread_id), если прошло ≥1 дня и уместно; "
            "game — предложить сыграть (только если тишина или скука, не чаще раза в день); "
            "poll — создать опрос по спорной теме, которую сейчас обсуждают (text = вопрос, options = 2–4 коротких варианта), не чаще раза в 3 часа. "
            + ("" if can_text else "СЕЙЧАС текстовые действия (say/start_topic/ask_promise/game) запрещены — слишком недавно говорила; можно только silence или react. ")
            + 'Верни JSON: {"action": "...", "text": "реплика 1–2 предложения или пусто", "emoji": "", "msg_id": 0, "thread_id": 0, "options": [], "why": "кратко"}. '
            "Не повторяй свои прошлые реплики и шаблонные фразы. Пиши строчными. Главное правило: лучше промолчать, чем сказать среднее.")
    res = await llm_json([{"role": "system", "content": system_prompt(task, await db.mood(chat_id), chat_id=chat_id)},
                          {"role": "user", "content": f"СОСТОЯНИЕ:\n{await state_block(chat_id, msgs, s)}\n\nПОСЛЕДНИЕ СООБЩЕНИЯ:\n{ctx}"}],
                         max_tokens=220, temperature=0.7)
    if not isinstance(res, dict):
        return
    action = str(res.get("action", "silence"))
    text = html.escape(str(res.get("text") or "").strip())[:400]
    if action not in ALLOWED or action == "silence":
        return
    from persona import get_mode
    if get_mode(chat_id) == "траур" and action in ("start_topic", "game", "ask_promise"):
        return
    if action == "react":
        emoji = str(res.get("emoji") or "").strip()
        try:
            mid = int(res.get("msg_id") or human[-1]["msg_id"])
        except (TypeError, ValueError):
            mid = human[-1]["msg_id"]
        if emoji and s.get("reactions", 1):
            from handlers.nominations import set_reaction
            if await set_reaction(bot, chat_id, mid, emoji, min_gap=120):
                _actions[chat_id].append((now, "react", mid, ""))
        return
    if not can_text or not text:
        return
    if action == "poll":
        if now - _last_poll[chat_id] < 3 * 3600:
            return
        opts = [str(o) for o in (res.get("options") or []) if str(o).strip()]
        if len(opts) < 2:
            return
        from handlers.memes import make_poll
        sent = await make_poll(bot, chat_id, html.unescape(text), opts, anonymous=True)
        if not sent:
            return
        _last_poll[chat_id] = now
    elif action == "game":
        from handlers.games import _busy
        if _busy(chat_id) or now - _last_topic[chat_id] < 6 * 3600:
            return
        sent = await bot.send_message(chat_id, text + "\n\n<i>!ктописал · !правдаложь · !игра</i>")
        _last_topic[chat_id] = now
    elif action == "ask_promise":
        try:
            tid = int(res.get("thread_id") or 0)
        except (TypeError, ValueError):
            tid = 0
        th = await db.thread(tid) if tid else None
        if not th or th["chat_id"] != chat_id or th["status"] == "closed" or now - th["ts"] < 20 * 3600:
            return
        sent = await bot.send_message(chat_id, f"{await nm(chat_id, th['user_id'])}, {text}")
        await db.thread_status(tid, "closed" if th["status"] == "asked" else "asked")
    elif action == "start_topic":
        if quiet_min < quiet_need * 0.75:
            return
        sent = await bot.send_message(chat_id, text)
        _last_topic[chat_id] = now
    else:
        sent = await bot.send_message(chat_id, text)
    await db.remember_bot_message(chat_id, sent.message_id)
    _last_text_action[chat_id] = now
    _actions[chat_id].append((now, action, sent.message_id, text[:120]))
    try:
        from handlers.ai import _history
        _history[chat_id].append(("саррочка", text[:300]))
    except Exception:
        pass
    logging.info("pulse %s: %s — %s", chat_id, action, str(res.get("why", ""))[:80])


async def maybe_day_note(bot: Bot, chat_id: int, s: dict):
    """В 23:50+ — две строки о дне в память."""
    if not s.get("day_notes", 1):
        return
    lt = time.localtime()
    if lt.tm_hour != 23 or lt.tm_min < 50:
        return
    day = time.strftime("%Y-%m-%d")
    if _day_note_done.get(chat_id) == day or await db.day_note_exists(chat_id, day):
        _day_note_done[chat_id] = day
        return
    _day_note_done[chat_id] = day
    msgs = [m for m in await db.messages_since(chat_id, int(time.time()) - 24 * 3600, 500) if m["text"]]
    if len(msgs) < 20:
        return
    from handlers.ai import llm
    sample = "\n".join(f"{m['nick'] or m['first_name']}: {m['text'][:160]}" for m in msgs[-250:])
    events = await db.events(chat_id, int(time.time()) - 24 * 3600, 40)
    ev = "\n".join(e["text"] for e in events)
    out = await llm([{"role": "system", "content": "Сожми день телеграм-чата в 2 строки для своей памяти: главные темы, кто с кем спорил/мирился/женился, "
                      "что обещали, смешное. Только факты с именами, без оценок, без markdown, до 300 символов."},
                     {"role": "user", "content": f"События:\n{ev}\n\nПереписка:\n{sample}"}], max_tokens=200, temperature=0.3)
    if out:
        await db.day_note_add(chat_id, day, out.strip()[:400])


# ---------------- команды ----------------
@router.message(Command("пульс", "pulse", prefix="!/"))
async def cmd_pulse(msg: Message, bot: Bot):
    if await deny(msg, bot, "settings"):
        return
    chat_id = msg.chat.id
    _bots[chat_id] = bot
    msgs = await db.messages_since(chat_id, int(time.time()) - 6 * 3600, 400)
    s = await db.settings(chat_id)
    st = await state_block(chat_id, msgs, s)
    acts = "\n".join(f"  {time.strftime('%H:%M', time.localtime(a[0]))} {a[1]}: {a[3][:60]}" for a in list(_actions[chat_id])[-8:]) or "  пока ничего"
    await msg.answer(f"<b>пульс</b> (pulse={s.get('pulse', 1)}, каждые {s.get('pulse_every', 2)} мин, пауза {s.get('pulse_gap', 10)} мин, тишина для инициативы {s.get('pulse_quiet', 40)} мин)\n\n"
                     f"<code>{html.escape(st)}</code>\n\nмои действия:\n<code>{html.escape(acts)}</code>")


@router.message(Command("обещания", "нити", "threads", prefix="!/"))
async def cmd_threads(msg: Message, bot: Bot):
    chat_id = msg.chat.id
    th = await db.threads_open(chat_id, 20)
    if not th:
        return await reply(msg, "threads_empty")
    lines = [f"#{t['id']} · {await nm(chat_id, t['user_id'])} — {html.escape(t['text'])} ({time.strftime('%d.%m', time.localtime(t['ts']))}"
             + (f", срок {t['due']}" if t["due"] else "") + ")" for t in th]
    await reply(msg, "threads_list", list="\n".join(lines))


@router.message(Command("обещание", "нить", "thread", prefix="-"))
async def cmd_thread_del(msg: Message, bot: Bot):
    args = split_args(msg)
    if not args or not args[0].lstrip("#").isdigit():
        return await reply(msg, "threads_usage")
    th = await db.thread(int(args[0].lstrip("#")))
    if not th or th["chat_id"] != msg.chat.id:
        return await reply(msg, "threads_none")
    from utils import has_rank
    if th["user_id"] != msg.from_user.id and not await has_rank(bot, msg.chat.id, msg.from_user.id, "settings"):
        return await reply(msg, "fact_denied")
    await db.thread_status(th["id"], "closed")
    await reply(msg, "threads_closed", id=th["id"])
