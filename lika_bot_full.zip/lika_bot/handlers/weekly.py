"""«Неделя в ЧВК Сарра» — воскресное шоу (weekly_day 6 = воскресенье, weekly_hour 20): карточка-картинка со статистикой недели
+ текст от Саррочки: главная драма, цитата недели, пара недели, номинации недели, кто пропал, кто ворвался. !неделя — вручную (ст. админ)."""
import asyncio
import html
import logging
import os
import time
from collections import Counter
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message, FSInputFile
from db import db
from utils import reply, mention, deny, style
from phrases import say
from config import MUSIC_DIR

router = Router()


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


async def nm(chat_id: int, uid: int) -> str:
    return mention(uid, await plain(chat_id, uid))


async def build(bot: Bot, chat_id: int, title: str) -> tuple[str | None, str]:
    now = int(time.time())
    since = now - 7 * 86400
    msgs = [m for m in await db.messages_since(chat_id, since, 3000) if m["text"]]
    events = await db.events(chat_id, since, 400)
    st = await db.summary_stats(chat_id, since)
    top = await db.top_period(chat_id, 7, 7)
    # кто пропал / ворвался: активные на прошлой неделе vs на этой
    prev = {r["user_id"]: r["n"] for r in await db.top_period(chat_id, 14, 60)}
    cur = {r["user_id"]: r["n"] for r in await db.top_period(chat_id, 7, 60)}
    gone = [u for u, n in prev.items() if n - cur.get(u, 0) >= 20 and cur.get(u, 0) == 0][:3]
    newcomers = [e for e in events if e["kind"] == "join"]
    # номинации недели: кто чаще всего побеждал
    nom_counter = Counter()
    for e in events:
        if e["kind"] == "nom":
            nom_counter[e["text"].split(" — ")[0]] += 1
    # картинка
    png = None
    try:
        from handlers.statcard import _draw
        from handlers.coins import month_key
        series = await db.chat_daily(chat_id, 7)
        topn = [(await plain(chat_id, r["user_id"]), r["n"]) for r in top]
        coins = [(await plain(chat_id, r["user_id"]), r["n"]) for r in await db.coins_top(chat_id, month_key(), 8)]
        kpi = [("сообщений", f"{st['msgs']:,}".replace(",", " ")), ("писали", str(st["users"])), ("новых", str(len(newcomers))),
               ("браков", str(sum(1 for e in events if e["kind"] == "marry"))), ("дуэлей", str(sum(1 for e in events if e["kind"] == "duel"))),
               ("споров", str(sum(1 for e in events if e["kind"] == "bet")))]
        os.makedirs(MUSIC_DIR, exist_ok=True)
        png = os.path.join(MUSIC_DIR, f"week_{chat_id}.png")
        await asyncio.get_running_loop().run_in_executor(None, _draw, png, title[:28], f"неделя · {time.strftime('%d.%m', time.localtime(since))}–{time.strftime('%d.%m')}",
                                                         series, topn, coins, kpi, "неделя в ЧВК. too pretty to argue.")
    except Exception as e:
        logging.warning("weekly card: %s", e)
        png = None
    # текст от Саррочки
    text = None
    try:
        from handlers.ai import llm
        from persona import system_prompt
        from handlers.relations import chat_summary
        ev_txt = "\n".join(e["text"] for e in events[-80:])
        sample = "\n".join(f"{m['nick'] or m['first_name']}: {m['text'][:140]}" for m in msgs[-400:])[-14000:]
        notes = await db.day_notes(chat_id, 7)
        notes_txt = "\n".join(f"{n['day']}: {n['note']}" for n in notes)
        facts = (f"сообщений за неделю: {st['msgs']}, писали: {st['users']}; топ активных: " + ", ".join(f"{await plain(chat_id, r['user_id'])} ({r['n']})" for r in top[:5])
                 + f"; пропали: {', '.join([await plain(chat_id, u) for u in gone]) or 'никто'}; новых: {len(newcomers)}"
                 + f"; чаще всех в номинациях: {', '.join(f'{k} ×{v}' for k, v in nom_counter.most_common(3)) or '—'}"
                 + f"; связи: {await chat_summary(chat_id, since) or '—'}")
        out = await llm([{"role": "system", "content": system_prompt(
            "Ты ведёшь воскресное шоу «неделя в ЧВК Сарра». Напиши выпуск 10–16 строк, живо и по фактам, строчными, без markdown, разделы с эмодзи в начале строки: "
            "🔥 драма недели (кто с кем и из-за чего — с цитатой), 💬 цитата недели (дословно, с автором), 💘 пара недели, 👑 герой недели (за что), "
            "🤡 момент недели, 🧵 обещания (кто что обещал и что с этим), 👋 кто пропал / кто ворвался, 🎀 твоё резюме недели одной фразой. "
            "Только реальные имена и события из материалов. Если раздела нечем заполнить — пропусти его.", with_mood=False)},
            {"role": "user", "content": f"ФАКТЫ: {facts}\n\nЗАМЕТКИ ПО ДНЯМ:\n{notes_txt}\n\nСОБЫТИЯ:\n{ev_txt}\n\nПЕРЕПИСКА (выборка):\n{sample}"}],
            max_tokens=900, temperature=0.7, timeout=120)
        text = html.escape(out) if out else None
    except Exception as e:
        logging.warning("weekly text: %s", e)
    if not text:
        lines = [f"сообщений: {st['msgs']}, писали: {st['users']}",
                 "самые активные: " + ", ".join([f"{await nm(chat_id, r['user_id'])} ({r['n']})" for r in top[:5]])]
        if gone:
            lines.append("пропали: " + ", ".join([await nm(chat_id, u) for u in gone]))
        text = "\n".join(lines)
    return png, text


async def post(bot: Bot, chat_id: int, title: str):
    st = await style(chat_id)
    png, text = await build(bot, chat_id, title)
    head = say(st, "weekly_head", chat_id=chat_id)
    if png:
        sent = await bot.send_photo(chat_id, FSInputFile(png), caption=head[:1000])
        await db.remember_bot_message(chat_id, sent.message_id)
        sent = await bot.send_message(chat_id, text[:4000])
    else:
        sent = await bot.send_message(chat_id, head + "\n\n" + text[:3800])
    await db.remember_bot_message(chat_id, sent.message_id)
    await db.log_event(chat_id, "weekly", "📺 вышел выпуск «неделя в ЧВК»")


async def weekly_tick(bot: Bot):
    lt = time.localtime()
    for chat_id in await db.all_chats():
        if chat_id > 0:
            continue
        s = await db.settings(chat_id)
        if not s.get("weekly", 1) or lt.tm_wday != int(s.get("weekly_day", 6)) or lt.tm_hour < int(s.get("weekly_hour", 20)):
            continue
        week = time.strftime("%Y-%W")
        if s.get("weekly_done") == week:
            continue
        await db.set_setting(chat_id, "weekly_done", week)
        try:
            chat = await bot.get_chat(chat_id)
            await post(bot, chat_id, chat.title or "чат")
        except Exception as e:
            logging.warning("weekly %s: %s", chat_id, e)


@router.message(Command("неделя", "weekly", prefix="!/"))
async def cmd_weekly(msg: Message, bot: Bot):
    if await deny(msg, bot, "settings"):
        return
    await reply(msg, "weekly_wait")
    await post(bot, msg.chat.id, msg.chat.title or "чат")
