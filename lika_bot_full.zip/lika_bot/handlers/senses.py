"""Зрение и слух Саррочки (нужен OPENAI_API_KEY).
• Голосовые и кружки → текст (Whisper): попадает в журнал сообщений (разборы, сводки, память, пульс видят их как текст);
  ответом на войс «что он сказал?» / «расшифруй» / !текст — показывает расшифровку. voice_auto 1 — писать расшифровку сразу под каждым войсом.
• Фото и мемы → короткое описание (gpt-4o-mini, low detail) в журнал; ответом «что на фото?» / !фото — живое описание в её стиле.
• Ссылки: ответом «о чём ссылка?» / «перескажи» / !ссылка — читает страницу и пересказывает; «саррочка, что думаешь?» на ссылку — тоже.
Настройки: senses (1/0), voice_auto (0), vision_auto (1), senses_max_sec (180)."""
import asyncio
import base64
import html
import io
import logging
import re
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply
from config import OPENAI_API_KEY, VISION_MODEL, WHISPER_MODEL

router = Router()
OPENAI = "https://api.openai.com/v1"
URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)
WHAT_SAID_RE = re.compile(r"(что\s+(?:он|она|там|тут)?\s*(?:сказал|сказала|говорит|наговорил)|расшифруй|текстом|не\s+могу\s+послушать|о\s+ч[её]м\s+(?:войс|голосов|кружок))", re.I)
WHAT_PHOTO_RE = re.compile(r"(что\s+(?:тут\s+|здесь\s+)?(?:на\s+)?(?:эт(?:ом|ой|их|о)\s+)?(?:фото|фотке|картинке|пикче|меме|скрине|изображен)|опиши\s+(?:эт\w+\s+)?(?:фото|картинку|мем|скрин)|в\s+ч[её]м\s+(?:тут\s+)?(?:шутка|прикол|смысл)|что\s+(?:это|тут|здесь)\s*(?:такое)?\s*\??$|кто\s+(?:это|на\s+фото)|что\s+за\s+(?:машина|тачка|место|город|еда|блюдо|фильм|игра|бренд|штука))", re.I)
WHAT_LINK_RE = re.compile(r"(о\s+ч[её]м\s+(?:ссылка|статья|пост|видео|там)|перескажи|что\s+(?:там|по\s+ссылке)|тлдр|tl;?dr|кратко)", re.I)
_transcripts: dict[tuple[int, int], str] = {}
_descriptions: dict[tuple[int, int], str] = {}


async def _download(bot: Bot, file_id: str, max_bytes: int = 20 * 1024 * 1024) -> bytes | None:
    try:
        f = await bot.get_file(file_id)
        if f.file_size and f.file_size > max_bytes:
            return None
        buf = io.BytesIO()
        await bot.download_file(f.file_path, buf)
        return buf.getvalue()
    except Exception as e:
        logging.warning("senses download: %s", str(e)[:120])
        return None


async def transcribe(data: bytes, filename: str = "voice.ogg") -> str | None:
    if not OPENAI_API_KEY:
        return None
    import aiohttp
    form = aiohttp.FormData()
    form.add_field("file", data, filename=filename, content_type="application/octet-stream")
    form.add_field("model", WHISPER_MODEL)
    form.add_field("language", "ru")
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=90)) as s:
            async with s.post(f"{OPENAI}/audio/transcriptions", data=form, headers={"Authorization": f"Bearer {OPENAI_API_KEY}"}) as resp:
                j = await resp.json()
                if resp.status != 200:
                    logging.warning("whisper %s: %s", resp.status, str(j)[:200])
                    return None
                return (j.get("text") or "").strip() or None
    except Exception as e:
        logging.warning("whisper: %s", str(e)[:150])
        return None


async def describe(data: bytes, prompt: str, detail: str = "low", max_tokens: int = 120) -> str | None:
    if not OPENAI_API_KEY:
        return None
    import aiohttp
    b64 = base64.b64encode(data).decode()
    payload = {"model": VISION_MODEL, "max_tokens": max_tokens, "messages": [{"role": "user", "content": [
        {"type": "text", "text": prompt},
        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}", "detail": detail}}]}]}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as s:
            async with s.post(f"{OPENAI}/chat/completions", json=payload, headers={"Authorization": f"Bearer {OPENAI_API_KEY}"}) as resp:
                j = await resp.json()
                if resp.status != 200:
                    logging.warning("vision %s: %s", resp.status, str(j)[:200])
                    return None
                return j["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logging.warning("vision: %s", str(e)[:150])
        return None


async def read_url(url: str, limit: int = 7000) -> str | None:
    """Текст страницы (без html), до limit символов."""
    import aiohttp
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20), headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/124.0"}) as s:
            async with s.get(url, allow_redirects=True) as resp:
                if resp.status != 200 or "text/html" not in (resp.headers.get("content-type") or "") and "text/plain" not in (resp.headers.get("content-type") or ""):
                    return None
                raw = (await resp.content.read(600_000)).decode(resp.charset or "utf-8", errors="ignore")
    except Exception as e:
        logging.warning("read_url %s: %s", url[:60], str(e)[:100])
        return None
    raw = re.sub(r"(?is)<(script|style|noscript|svg|header|footer|nav).*?</\1>", " ", raw)
    title = re.search(r"(?is)<title[^>]*>(.*?)</title>", raw)
    text = re.sub(r"(?s)<[^>]+>", " ", raw)
    text = html.unescape(re.sub(r"\s+", " ", text)).strip()
    return ((title.group(1).strip() + "\n\n") if title else "") + text[:limit]


# ---------------- автоматический контекст ----------------
async def observe(msg: Message, bot: Bot):
    """Из middleware: войсы/кружки → расшифровка, фото → описание; всё в журнал сообщений."""
    if not OPENAI_API_KEY:
        return
    chat_id = msg.chat.id
    s = await db.settings(chat_id)
    if not s.get("senses", 1):
        return
    key = (chat_id, msg.message_id)
    if msg.voice or msg.video_note:
        media = msg.voice or msg.video_note
        if (media.duration or 0) > int(s.get("senses_max_sec", 180)):
            return
        data = await _download(bot, media.file_id)
        if not data:
            return
        text = await transcribe(data, "voice.ogg" if msg.voice else "circle.mp4")
        if not text:
            return
        _transcripts[key] = text
        kind = "голосовое" if msg.voice else "кружок"
        await db.update_msg_text(chat_id, msg.message_id, f"[{kind}] {text}")
        try:
            from handlers.ai import _history, who
            _history[chat_id].append((who(msg), f"[{kind}] {text[:300]}"))
        except Exception:
            pass
        if s.get("voice_auto", 0):
            await reply(msg, "voice_text", text=html.escape(text[:3500]))
    elif msg.photo and s.get("vision_auto", 1):
        data = await _download(bot, msg.photo[-1].file_id, 10 * 1024 * 1024)
        if not data:
            return
        desc = await describe(data, "Опиши картинку одним предложением по-русски (что изображено, текст на ней, если это мем — в чём шутка). Без вступлений.")
        if not desc:
            return
        _descriptions[key] = desc
        cap = (msg.caption or "").strip()
        await db.update_msg_text(chat_id, msg.message_id, (cap + " " if cap else "") + f"[фото: {desc}]")
        try:
            from handlers.ai import _history, who
            _history[chat_id].append((who(msg), (cap + " " if cap else "") + f"[фото: {desc[:200]}]"))
        except Exception:
            pass


async def media_text(bot: Bot, r: Message) -> str | None:
    """Содержимое медиа-сообщения текстом для контекста диалога: расшифровка войса или описание фото (из кэша или заново)."""
    if not OPENAI_API_KEY:
        return None
    key = (r.chat.id, r.message_id)
    if r.voice or r.video_note:
        if key in _transcripts:
            return f"голосовое: «{_transcripts[key]}»"
        data = await _download(bot, (r.voice or r.video_note).file_id)
        text = await transcribe(data, "voice.ogg" if r.voice else "circle.mp4") if data else None
        if text:
            _transcripts[key] = text
            return f"голосовое: «{text}»"
        return None
    if r.photo:
        if key in _descriptions:
            return f"фото: {_descriptions[key]}" + (f"; подпись: {r.caption}" if r.caption else "")
        data = await _download(bot, r.photo[-1].file_id, 10 * 1024 * 1024)
        desc = await describe(data, "Опиши картинку 1–2 предложениями по-русски: что изображено, текст на ней, если мем — в чём шутка. Без вступлений.") if data else None
        if desc:
            _descriptions[key] = desc
            return f"фото: {desc}" + (f"; подпись: {r.caption}" if r.caption else "")
    return None


# ---------------- по запросу ----------------
async def _voice_text(msg: Message, bot: Bot, r: Message):
    key = (msg.chat.id, r.message_id)
    text = _transcripts.get(key)
    if not text:
        media = r.voice or r.video_note
        data = await _download(bot, media.file_id)
        text = await transcribe(data, "voice.ogg" if r.voice else "circle.mp4") if data else None
        if text:
            _transcripts[key] = text
            await db.update_msg_text(msg.chat.id, r.message_id, f"[{'голосовое' if r.voice else 'кружок'}] {text}")
    if not text:
        return await reply(msg, "senses_fail")
    await reply(msg, "voice_text", text=html.escape(text[:3500]))


async def _photo_text(msg: Message, bot: Bot, r: Message, question: str):
    data = await _download(bot, r.photo[-1].file_id, 10 * 1024 * 1024)
    if not data:
        return await reply(msg, "senses_fail")
    from persona import PERSONA
    prompt = (PERSONA[:1500] + "\n\nОпиши, что на картинке, и ответь на вопрос в своём стиле, 2–5 предложений, без markdown. "
              + (f"Вопрос: {question}" if question else "Вопрос: что это?") + (f"\nПодпись к фото: {r.caption}" if r.caption else ""))
    out = await describe(data, prompt, detail="high", max_tokens=350)
    if not out:
        return await reply(msg, "senses_fail")
    await reply(msg, "photo_text", text=html.escape(out[:3500]))


async def _link_text(msg: Message, bot: Bot, url: str, question: str):
    try:
        await bot.send_chat_action(msg.chat.id, "typing")
    except Exception:
        pass
    page = await read_url(url)
    if not page or len(page) < 200:
        return await reply(msg, "link_fail")
    from handlers.ai import llm
    from persona import system_prompt
    out = await llm([{"role": "system", "content": system_prompt("Тебе дали текст страницы по ссылке. Перескажи суть в 3–7 предложениях и, если спросили, ответь на вопрос. "
                                                                 "Факты — из текста, своё мнение — одной фразой в конце. Без markdown.", with_mood=False)},
                     {"role": "user", "content": f"Вопрос: {question or 'о чём это?'}\nСсылка: {url}\n\nТекст страницы:\n{page}"}], max_tokens=500, temperature=0.4)
    if not out:
        return await reply(msg, "ai_off")
    await reply(msg, "link_text", text=html.escape(out[:3500]))


@router.message(Command("текст", "расшифруй", "stt", prefix="!/"), F.reply_to_message)
async def cmd_stt(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if not (r.voice or r.video_note):
        return await reply(msg, "senses_not_voice")
    if not OPENAI_API_KEY:
        return await reply(msg, "senses_nokey")
    await _voice_text(msg, bot, r)


@router.message(Command("фото", "чтонафото", "see", prefix="!/"), F.reply_to_message)
async def cmd_see(msg: Message, bot: Bot):
    r = msg.reply_to_message
    if not r.photo:
        return await reply(msg, "senses_not_photo")
    if not OPENAI_API_KEY:
        return await reply(msg, "senses_nokey")
    from utils import split_args
    await _photo_text(msg, bot, r, " ".join(split_args(msg)))


@router.message(Command("ссылка", "перескажи", "link", "tldr", prefix="!/"))
async def cmd_link(msg: Message, bot: Bot):
    from utils import split_args
    args = split_args(msg)
    src = " ".join(args) + " " + ((msg.reply_to_message.text or msg.reply_to_message.caption or "") if msg.reply_to_message else "")
    m = URL_RE.search(src)
    if not m:
        return await reply(msg, "link_usage")
    await _link_text(msg, bot, m.group(0), " ".join(a for a in args if not a.startswith("http")))


@router.message(F.photo, F.caption)
async def photo_with_caption(msg: Message, bot: Bot):
    """Фото с подписью «саррочка, что это?» / «что на фото» — описывает это же фото."""
    from aiogram.dispatcher.event.bases import SkipHandler
    cap = msg.caption or ""
    if not (re.search(r"саррочка|@fromsarrabot", cap, re.I) or WHAT_PHOTO_RE.search(cap)):
        raise SkipHandler
    s = await db.settings(msg.chat.id)
    if not s.get("senses", 1):
        raise SkipHandler
    if not OPENAI_API_KEY:
        return await reply(msg, "senses_nokey")
    q = re.sub(r"саррочка|@fromsarrabot", "", cap, flags=re.I).strip(" ,!?") or "что это?"
    await _photo_text(msg, bot, msg, q)


@router.message(F.reply_to_message, F.text)
async def natural_senses(msg: Message, bot: Bot):
    """Ответом на войс/фото/ссылку — естественные фразы."""
    from aiogram.dispatcher.event.bases import SkipHandler
    r = msg.reply_to_message
    text = msg.text or ""
    if text.startswith(("/", "!", "+", "-")):
        raise SkipHandler
    s = await db.settings(msg.chat.id)
    if not s.get("senses", 1):
        raise SkipHandler
    if (r.voice or r.video_note) and WHAT_SAID_RE.search(text):
        if not OPENAI_API_KEY:
            return await reply(msg, "senses_nokey")
        return await _voice_text(msg, bot, r)
    if r.photo and WHAT_PHOTO_RE.search(text):
        if not OPENAI_API_KEY:
            return await reply(msg, "senses_nokey")
        return await _photo_text(msg, bot, r, text)
    url = URL_RE.search(r.text or r.caption or "")
    if url and (WHAT_LINK_RE.search(text) or re.search(r"саррочка", text, re.I)):
        return await _link_text(msg, bot, url.group(0), text)
    raise SkipHandler
