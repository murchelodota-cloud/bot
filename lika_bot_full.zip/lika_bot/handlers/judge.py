"""«опиши этого человека» / «какой он?» / «можно ли ему верить?» (ответом) — Саррочка анализирует по сообщениям в чате.
С LLM — живой разбор в её стиле; без LLM — портрет по статистике."""
import asyncio
import html
import logging
import re
import time
from collections import Counter
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from phrases import say
from utils import reply, mention, split_args, style, rank_of, rank_name
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL

router = Router()
TRIGGER_RE = re.compile(
    r"^(?:саррочка|сарочка)?[,!\s]*"
    r"(?:опиши(?:\s+(?:этого|его|её|ее))?\s*(?:человека|чела|его|её|ее)?|"
    r"какой\s+(?:он|она|это\s+человек|чел)|какая\s+она|кто\s+(?:он|она)\s+такой|кто\s+(?:он|она)|"
    r"можно\s+ли\s+(?:ему|ей)\s+(?:верить|доверять)|(?:он|она)\s+(?:бабник|нормальный|нормальная|адекватный|адекватная|токсик|мутный|мутная)|"
    r"что\s+(?:ты\s+)?думаешь\s+(?:о\s+нём|о\s+ней|про\s+него|про\s+неё|про\s+нее)|охарактеризуй|разбор|анализ|проанализируй|оцени\s+(?:его|её|ее))"
    r"[\s?!.]*(.*)$",
    re.I | re.S,
)
# произвольная фраза с упоминанием @юзера: «расскажи о @user», «опиши @user», «саррочка, что думаешь про @user, он норм?»
MENTION_WORDS = re.compile(
    r"(расскажи|опиши|охарактеризуй|разбери|проанализируй|разбор|анализ|оцени|что\s+(?:ты\s+)?думаешь|что\s+скажешь|какой\s+он|какая\s+она|"
    r"кто\s+так(?:ой|ая)|можно\s+ли\s+(?:ему|ей|)\s*(?:верить|доверять)|бабник|адекватн|токсик|мутн|нормальн)", re.I)
MENTION_RE = re.compile(r"@([A-Za-z][A-Za-z0-9_]{3,31})")

ROAST_RE = re.compile(
    r"^(?:саррочка|@fromsarrabot)[,!\s]+.*?прожар\w*(?:\s+(меня|его|её|ее|@([A-Za-z][A-Za-z0-9_]{3,31})))?|^.*?прожар\w*(?:\s+(меня|его|её|ее|@([A-Za-z][A-Za-z0-9_]{3,31})))?[,\s]+саррочка[?!.]*$",
    re.I | re.S)
_cool: dict[tuple[int, int], float] = {}


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


async def portrait_stats(chat_id: int, uid: int, bot) -> dict:
    row = await db.user(chat_id, uid)
    msgs = await db.user_messages(chat_id, uid, 300)
    texts = [m["text"] for m in msgs if m["text"]]
    from handlers.nominations import EMOJI_RE, EX_RE, GIRLS_RE
    joined = "\n".join(texts)
    n = max(1, len(texts))
    avg_len = sum(len(t) for t in texts) / n
    caps = sum(1 for t in texts if len(t) > 5 and t.upper() == t and any(c.isalpha() for c in t))
    questions = sum(1 for t in texts if "?" in t)
    hours = Counter(time.localtime(m["ts"]).tm_hour for m in msgs)
    night = sum(v for h, v in hours.items() if h < 6 or h >= 23)
    ds = await db.duel_stats(chat_id, uid)
    return {
        "name": (row["nick"] or row["first_name"]) if row else "кто-то",
        "rank": rank_name(await rank_of(bot, chat_id, uid)),
        "total": row["msgs"] if row else 0, "sample": len(texts), "avg_len": int(avg_len),
        "emoji": len(EMOJI_RE.findall(joined)), "ex": len(EX_RE.findall(joined)), "girls": len(GIRLS_RE.findall(joined)),
        "caps": caps, "questions": questions, "night": night, "links": sum(1 for t in texts if "http" in t),
        "warns": await db.active_warns(chat_id, uid), "partners": len(await db.partners(chat_id, uid)),
        "crush": bool(await db.crush(chat_id, uid)), "coins": await db.coins_total(chat_id, uid),
        "wins": ds["wins"] if ds else 0, "losses": ds["losses"] if ds else 0, "cowards": ds["cowards"] if ds else 0,
        "ach": await db.achievements(chat_id, uid), "bio": (row["bio"] if row else None) or "",
        "texts": texts,
    }


def stats_verdict(s: dict, question: str) -> str:
    """Портрет без ИИ — по цифрам, в характере."""
    lines = []
    if s["sample"] < 5:
        return (f"я видела от {s['name']} всего {s['sample']} сообщений. это как судить о книге по обложке. "
                f"но обложка… ладно, пусть напишет ещё, тогда расскажу.")
    traits = []
    pct = lambda x: int(100 * x / max(1, s["sample"]))
    if s["ex"] >= 3:
        traits.append(f"«бывшая» всплывала {s['ex']} раз(а) — не отпустил. я бы помогла, но я бот.")
    if s["girls"] >= 5:
        traits.append(f"про девочек — {s['girls']} упоминаний. бабник? скажем, внимательный. очень.")
    elif s["girls"] == 0 and s["sample"] > 30:
        traits.append("про девочек — ни слова. либо однолюб, либо скрытный. либо занят мной. нет.")
    if s["emoji"] > s["sample"] * 1.5:
        traits.append("эмодзи больше, чем слов. эмоциональный. или просто клавиатура такая.")
    if s["caps"] >= 3:
        traits.append(f"капсом писал {s['caps']} раз(а). вспыльчивый. или громкий. или и то, и другое.")
    if s["avg_len"] > 120:
        traits.append("пишет длинно и обстоятельно. читает ли кто-то до конца — вопрос. я читаю.")
    elif s["avg_len"] < 20:
        traits.append("пишет коротко. «ок», «да», «нет». экономит слова. или мысли.")
    if pct(s["questions"]) > 30:
        traits.append("много спрашивает. любопытный. или не читает, что пишут другие.")
    if s["night"] > s["sample"] * 0.4:
        traits.append("ночной. пишет, когда нормальные люди спят. я тоже не сплю. мы похожи. это тревожно.")
    if s["links"] > s["sample"] * 0.2:
        traits.append("каждое пятое сообщение — ссылка. либо делится, либо рекламирует. я за ним слежу.")
    if s["warns"]:
        traits.append(f"активных предов: {s['warns']}. ведёт себя так себе. или модераторы придирчивые. нет, он.")
    if s["cowards"]:
        traits.append(f"струсил в дуэли {s['cowards']} раз(а). запомнила.")
    elif s["wins"] >= 3:
        traits.append(f"{s['wins']} побед в дуэлях. горячий. или везучий.")
    if s["partners"] > 1:
        traits.append(f"{s['partners']} брака одновременно. верить ему? ну… жёны верят.")
    elif s["partners"] == 1:
        traits.append("в браке. один. пока.")
    if s["crush"]:
        traits.append("влюблён. в кого — не скажу. ладно, +отношения скажет.")
    if not traits:
        traits.append("ничего криминального. обычный человек. подозрительно обычный.")
    trust = "верить можно" if s["warns"] == 0 and s["cowards"] == 0 and s["ex"] < 3 else "верить — с оглядкой"
    if any(w in question.lower() for w in ("верить", "доверять")):
        traits.append(f"итого: {trust}. но это по сообщениям, а не по глазам. глаз у меня нет.")
    return " ".join(traits)


async def llm_verdict(s: dict, question: str) -> str | None:
    if not LLM_API_KEY or s["sample"] < 5:
        return None
    import aiohttp
    sample = "\n".join(f"- {t[:240]}" for t in s["texts"][-300:])[-14000:]
    facts = (f"имя: {s['name']}; ранг: {s['rank']}; всего сообщений: {s['total']}; активных предов: {s['warns']}; "
             f"браков: {s['partners']}; влюблён: {'да' if s['crush'] else 'нет'}; коинов: {s['coins']}; "
             f"дуэли: {s['wins']} побед / {s['losses']} поражений / {s['cowards']} отказов; "
             f"эмодзи в выборке: {s['emoji']}; упоминаний «бывшая»: {s['ex']}; упоминаний девочек: {s['girls']}; "
             f"ночных сообщений: {s['night']} из {s['sample']}; ачивки: {', '.join(s['ach']) or 'нет'}; описание: {s['bio'] or 'нет'}")
    from persona import system_prompt
    system = system_prompt("Тебя просят рассказать о участнике чата. Перед тобой ВСЕ его доступные сообщения и факты. Прочитай их целиком и дай честную оценку человека: "
                           "какой он по характеру, как общается (тон, юмор, агрессия, искренность, как реагирует на других), что для него важно, в чём противоречит сам себе, "
                           "чем отличается от остальных, и к какому выводу о нём ты пришла. Если автор задал конкретный вопрос («бабник?», «можно ли верить?») — ответь на него прямо и обоснуй. "
                           "Пиши связным текстом, 2–3 абзаца, как живой рассказ о человеке — НЕ по пунктам, без списков, без заголовков, без «манера общения:» и подобных рубрик. "
                           "Подкрепляй выводы 2–3 цитатами в кавычках. Опирайся только на реальные сообщения и факты, не выдумывай. "
                           "Честно — значит и хорошее, и плохое; сарказм уместен, но оценка должна быть справедливой. Закончи одной фразой от себя.", with_mood=False)
    payload = {"model": LLM_MODEL, "temperature": 0.7, "max_tokens": 900,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": f"Вопрос: {question or 'опиши этого человека'}\n\nФакты: {facts}\n\nЕго сообщения:\n{sample}"}]}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as sess:
            async with sess.post(f"{LLM_BASE_URL}/chat/completions", json=payload,
                                 headers={"Authorization": f"Bearer {LLM_API_KEY}"}) as resp:
                data = await resp.json()
                if resp.status != 200:
                    logging.warning("llm judge %s: %s", resp.status, str(data)[:300])
                    return None
                return html.escape(data["choices"][0]["message"]["content"].strip())[:3800]
    except Exception as e:
        logging.warning("llm judge: %s", str(e)[:200])
        return None


async def judge(msg: Message, bot, uid: int, name: str | None, question: str):
    chat_id = msg.chat.id
    key = (chat_id, uid)
    if time.time() - _cool.get(key, 0) < 60:
        return await reply(msg, "judge_cooldown")
    _cool[key] = time.time()
    status = await reply(msg, "judge_wait", user=await nm(chat_id, uid, name))
    s = await portrait_stats(chat_id, uid, bot)
    text = await llm_verdict(s, question) or stats_verdict(s, question)
    try:
        await status.delete()
    except Exception:
        pass
    await reply(msg, "judge", user=await nm(chat_id, uid, name), text=text)


@router.message(Command("опиши", "кто", "анализ", "разбор", "расскажи", "judge", prefix="!+/"))
async def cmd_judge(msg: Message, bot):
    """!опиши (ответом) · !опиши @юзер · !расскажи о @юзер"""
    from utils import resolve_target
    cmd = (msg.text or "").split()[0][1:].lower()
    args = split_args(msg)
    if cmd == "кто" and (not msg.reply_to_message or (args and args[0].lower() in ("я", "ты", "админ", "админы", "власть", "здесь"))):
        from aiogram.dispatcher.event.bases import SkipHandler
        raise SkipHandler
    if msg.reply_to_message:
        u = msg.reply_to_message.from_user
        if u.is_bot:
            return await reply(msg, "judge_bot")
        return await judge(msg, bot, u.id, u.first_name, " ".join(args))
    args = [a for a in args if a.lower() not in ("о", "про", "об")]
    uid, name, rest = await resolve_target(msg)
    if not uid:
        return await reply(msg, "judge_usage")
    me = await bot.get_me()
    if uid == me.id:
        return await reply(msg, "judge_bot")
    await judge(msg, bot, uid, name, " ".join(rest))


@router.message(F.reply_to_message, F.text.regexp(TRIGGER_RE).as_("m"))
async def natural_judge(msg: Message, bot, m: re.Match):
    s = await db.settings(msg.chat.id)
    if not s.get("judge_natural", 1):
        return
    u = msg.reply_to_message.from_user
    if not u or u.is_bot:
        return await reply(msg, "judge_bot")
    await judge(msg, bot, u.id, u.first_name, (msg.text or "").strip())


@router.message(F.text.regexp(MENTION_RE, mode="search").as_("m"))
async def mention_judge(msg: Message, bot, m: re.Match):
    """Любая фраза с @юзером и словом-триггером — без ответа на сообщение."""
    text = msg.text or ""
    if text.startswith(("/", "!", "+", "-")) or not MENTION_WORDS.search(text):
        from aiogram.dispatcher.event.bases import SkipHandler
        raise SkipHandler
    s = await db.settings(msg.chat.id)
    if not s.get("judge_natural", 1):
        raise SkipHandler
    uname = m.group(1)
    row = await db.find_user_by_username(msg.chat.id, uname)
    uid, name = (row["user_id"], row["first_name"]) if row else (None, None)
    if not uid:
        return await reply(msg, "judge_unknown", q="@" + uname)
    me = await bot.get_me()
    if uid == me.id or uname.lower() == (me.username or "").lower():
        return await reply(msg, "judge_bot")
    await judge(msg, bot, uid, name, text.strip())


@router.message(F.text, F.entities)
async def text_mention_judge(msg: Message, bot):
    """То же для упоминания без username (text_mention)."""
    from aiogram.dispatcher.event.bases import SkipHandler
    text = msg.text or ""
    if text.startswith(("/", "!", "+", "-")) or msg.reply_to_message or not MENTION_WORDS.search(text):
        raise SkipHandler
    ent = next((e for e in (msg.entities or []) if e.type == "text_mention" and e.user and not e.user.is_bot), None)
    if not ent:
        raise SkipHandler
    s = await db.settings(msg.chat.id)
    if not s.get("judge_natural", 1):
        raise SkipHandler
    await judge(msg, bot, ent.user.id, ent.user.first_name, text.strip())


# ---------- прожарка ----------
async def llm_roast(s: dict, by_self: bool) -> str | None:
    if not LLM_API_KEY or s["sample"] < 5:
        return None
    import aiohttp
    sample = "\n".join(f"- {t[:240]}" for t in s["texts"][-300:])[-14000:]
    facts = (f"имя: {s['name']}; ранг: {s['rank']}; всего сообщений: {s['total']}; активных предов: {s['warns']}; "
             f"браков: {s['partners']}; влюблён: {'да' if s['crush'] else 'нет'}; коинов: {s['coins']}; "
             f"дуэли: {s['wins']} побед / {s['losses']} поражений / {s['cowards']} отказов; "
             f"эмодзи в выборке: {s['emoji']}; упоминаний «бывшая»: {s['ex']}; упоминаний девочек: {s['girls']}; "
             f"ночных сообщений: {s['night']} из {s['sample']}; ачивки: {', '.join(s['ach']) or 'нет'}; описание: {s['bio'] or 'нет'}")
    from persona import system_prompt
    who = "Человек сам попросил прожарить его" if by_self else "Кто-то попросил прожарить другого участника"
    system = system_prompt(f"{who}. Это ПРОЖАРКА (roast): беспощадно остроумно, с сухим сарказмом, в твоём стиле. "
                           "Бей по тому, что он сам показал в сообщениях: манера общения, противоречия, самооценка, привычки, "
                           "поведение в чате, статистика (преды, дуэли, «бывшая», ночные сообщения, браки). Подкрепляй 3–4 цитатами в кавычках. "
                           "Жёстко, но не жестоко: без мата, без национальности, веры, внешности, здоровья, семьи и реальных бед. "
                           "Связный текст 2–3 абзаца, без списков и заголовков. В конце — одна фраза, которая всё-таки чуть-чуть его поддержит, по-твоему.", with_mood=False)
    payload = {"model": LLM_MODEL, "temperature": 0.9, "max_tokens": 800,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": f"Факты: {facts}\n\nЕго сообщения:\n{sample}"}]}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as sess:
            async with sess.post(f"{LLM_BASE_URL}/chat/completions", json=payload,
                                 headers={"Authorization": f"Bearer {LLM_API_KEY}"}) as resp:
                data = await resp.json()
                if resp.status != 200:
                    logging.warning("llm roast %s: %s", resp.status, str(data)[:300])
                    return None
                return html.escape(data["choices"][0]["message"]["content"].strip())[:3800]
    except Exception as e:
        logging.warning("llm roast: %s", str(e)[:200])
        return None


def stats_roast(s: dict) -> str:
    """Прожарка без ИИ — по цифрам."""
    if s["sample"] < 5:
        return f"я видела от {s['name']} всего {s['sample']} сообщений. прожаривать нечего. пока что это даже не сырое — это пустая тарелка."
    bits = []
    if s["avg_len"] < 20:
        bits.append("пишет так коротко, будто за каждую букву платит")
    elif s["avg_len"] > 120:
        bits.append("пишет простыни, которые дочитывала только я. из вежливости")
    if s["emoji"] > s["sample"]:
        bits.append("эмодзи больше, чем мыслей, и это не комплимент эмодзи")
    if s["ex"]:
        bits.append(f"«бывшая» всплыла {s['ex']} раз(а) — она, кстати, не всплывала, это ты тонешь")
    if s["girls"] >= 5:
        bits.append(f"{s['girls']} упоминаний девочек. девочки, если что, не в курсе")
    if s["warns"]:
        bits.append(f"{s['warns']} активных предов — редкий талант раздражать модераторов")
    if s["cowards"]:
        bits.append(f"струсил в дуэли {s['cowards']} раз(а). смелость — не твой жанр")
    if s["night"] > s["sample"] * 0.4:
        bits.append("живёт ночью. днём, видимо, нечего сказать. ночью, как выяснилось, тоже")
    if s["partners"] > 1:
        bits.append(f"{s['partners']} брака. не любовь, а коллекционирование")
    if not bits:
        bits.append("настолько обычный, что даже прожарить не за что. это, кстати, и есть прожарка")
    return f"{s['name']}, ну смотри: " + "; ".join(bits) + ". не благодари. я не для тебя старалась, а для чата 💋"


async def roast(msg: Message, bot, uid: int, name: str | None):
    chat_id = msg.chat.id
    key = (chat_id, uid, "roast")
    if time.time() - _cool.get(key, 0) < 120:
        return await reply(msg, "judge_cooldown")
    _cool[key] = time.time()
    who = await nm(chat_id, uid, name)
    status = await reply(msg, "roast_wait", user=who)
    s = await portrait_stats(chat_id, uid, bot)
    text = await llm_roast(s, uid == msg.from_user.id) or stats_roast(s)
    try:
        await status.delete()
    except Exception:
        pass
    await db.log_event(chat_id, "roast", f"🔥 {await nm(chat_id, msg.from_user.id, msg.from_user.first_name)} попросил(а) прожарить {who}")
    await reply(msg, "roast", user=who, text=text)


async def _roast_target(msg: Message, bot, uname: str | None, word: str | None):
    """Кого жарим: @юзер → ответ → «меня»/никого → автор."""
    if uname:
        row = await db.find_user_by_username(msg.chat.id, uname)
        if not row:
            await reply(msg, "judge_unknown", q="@" + uname)
            return None, None
        return row["user_id"], row["first_name"]
    for ent in (msg.entities or []):
        if ent.type == "text_mention" and ent.user and not ent.user.is_bot:
            return ent.user.id, ent.user.first_name
    if msg.reply_to_message and msg.reply_to_message.from_user and (word or "").lower() not in ("меня", ""):
        u = msg.reply_to_message.from_user
        if u.is_bot:
            await reply(msg, "judge_bot")
            return None, None
        return u.id, u.first_name
    if msg.reply_to_message and msg.reply_to_message.from_user and not word:
        u = msg.reply_to_message.from_user
        if not u.is_bot:
            return u.id, u.first_name
    return msg.from_user.id, msg.from_user.first_name


@router.message(Command("прожарь", "прожарить", "прожарка", "roast", prefix="!+/"))
async def cmd_roast(msg: Message, bot):
    """!прожарь — себя; !прожарь @юзер; ответом — его."""
    from utils import resolve_target
    uid, name, _ = await resolve_target(msg)
    if not uid:
        uid, name = msg.from_user.id, msg.from_user.first_name
    me = await bot.get_me()
    if uid == me.id:
        return await reply(msg, "roast_me")
    await roast(msg, bot, uid, name)


@router.message(F.text.regexp(ROAST_RE).as_("m"))
async def natural_roast(msg: Message, bot, m: re.Match):
    """«саррочка, прожарь меня», «@fromsarrabot можешь прожарить меня?», «саррочка, прожарь @user», ответом — «прожарь его, саррочка»."""
    word = m.group(1) or m.group(3)
    uname = m.group(2) or m.group(4)
    uid, name = await _roast_target(msg, bot, uname, word)
    if not uid:
        return
    await roast(msg, bot, uid, name)
