"""Споры на сарра-коины. !спор @user 50 что завтра будет дождь → соперник принимает кнопкой → ставки заморожены.
Разрешение: !спор итог <доказательства> (можно ответом на сообщение-доказательство) — Саррочка-арбитр через ИИ решает, кто прав;
!спор сдаюсь — признать поражение; !спор отмена — отменить по согласию обоих или админом; !споры — активные."""
import html
import json
import logging
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from db import db
from utils import reply, mention, resolve_target, split_args, deny

router = Router()


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or str(uid)


def kb(bet_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🤝 принимаю", callback_data=f"bet:yes:{bet_id}"),
        InlineKeyboardButton(text="🙅 нет", callback_data=f"bet:no:{bet_id}"),
    ]])


@router.message(Command("спор", "поспорить", "bet", prefix="!+/"))
async def cmd_bet(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    args = split_args(msg)
    sub = (args[0].lower() if args else "")
    if sub in ("итог", "итоги", "результат", "рассуди", "решай"):
        return await resolve_bet(msg, bot, " ".join(args[1:]))
    if sub in ("сдаюсь", "проиграл", "проиграла", "признаю"):
        return await concede(msg, bot)
    if sub in ("отмена", "отменить", "cancel"):
        return await cancel(msg, bot)
    if sub in ("список", "активные", "list"):
        return await list_bets(msg)
    tgt, name, rest = await resolve_target(msg)
    if not tgt:
        return await reply(msg, "bet_usage")
    if tgt == uid:
        return await reply(msg, "bet_self")
    # ставка — любое число в аргументах (в начале или в конце), остальное — утверждение
    nums = [i for i, a in enumerate(rest) if a.isdigit()]
    if not nums:
        return await reply(msg, "bet_usage")
    idx = nums[0] if nums[0] == 0 else nums[-1]
    amount = max(1, min(100000, int(rest[idx])))
    claim = " ".join(a for i, a in enumerate(rest) if i != idx).strip()
    if len(claim) < 5:
        return await reply(msg, "bet_usage")
    if await db.bet_active_between(chat_id, uid, tgt):
        return await reply(msg, "bet_exists")
    bal = await db.coins_total(chat_id, uid)
    if bal < amount:
        return await reply(msg, "bet_poor", need=amount, balance=bal)
    bet_id = await db.bet_create(chat_id, uid, tgt, amount, claim[:300])
    sent = await reply(msg, "bet_offer", user=await nm(chat_id, uid, msg.from_user.first_name), target=await nm(chat_id, tgt, name),
                       amount=amount, claim=html.escape(claim[:300]), reply_markup=kb(bet_id))
    if sent:
        await db.bet_set_msg(bet_id, sent.message_id)


@router.callback_query(F.data.startswith("bet:"))
async def on_bet_button(cb: CallbackQuery, bot: Bot):
    _, action, bet_id = cb.data.split(":")
    bet = await db.bet(int(bet_id))
    if not bet or bet["status"] != "offered":
        return await cb.answer("этот спор уже не актуален.", show_alert=True)
    if cb.from_user.id != bet["opponent"]:
        return await cb.answer("это не тебе предложили. завидуй молча.", show_alert=True)
    chat_id = bet["chat_id"]
    from phrases import say
    from utils import style
    st = await style(chat_id)
    if action == "no":
        await db.bet_status(bet["id"], "declined")
        text = say(st, "bet_declined", chat_id=chat_id, target=await nm(chat_id, bet["opponent"]), user=await nm(chat_id, bet["author"]))
    else:
        bal = await db.coins_total(chat_id, bet["opponent"])
        if bal < bet["amount"]:
            return await cb.answer(f"у тебя {bal} коинов, нужно {bet['amount']}.", show_alert=True)
        # замораживаем ставки у обоих
        await db.give_coin(chat_id, bet["author"], 0, f"спор #{bet['id']}: ставка", -bet["amount"])
        await db.give_coin(chat_id, bet["opponent"], 0, f"спор #{bet['id']}: ставка", -bet["amount"])
        await db.bet_status(bet["id"], "active")
        text = say(st, "bet_accepted", chat_id=chat_id, user=await nm(chat_id, bet["author"]), target=await nm(chat_id, bet["opponent"]),
                   amount=bet["amount"], claim=html.escape(bet["claim"]), id=bet["id"])
    try:
        await cb.message.edit_text(text, reply_markup=None)
    except TelegramBadRequest:
        await cb.message.answer(text)
    await cb.answer()


async def _my_bet(msg: Message):
    bets = await db.bets_active(msg.chat.id)
    mine = [b for b in bets if msg.from_user.id in (b["author"], b["opponent"])]
    if not mine:
        return None
    # если несколько — последний; можно указать номер: !спор итог #12 ...
    text = msg.text or ""
    for b in mine:
        if f"#{b['id']}" in text:
            return b
    return mine[-1]


async def resolve_bet(msg: Message, bot: Bot, evidence: str):
    chat_id = msg.chat.id
    bet = await _my_bet(msg)
    if not bet:
        return await reply(msg, "bet_none")
    evidence = evidence.replace(f"#{bet['id']}", "").strip()
    if msg.reply_to_message:
        r = msg.reply_to_message
        quoted = r.text or r.caption or ("[медиа без текста]" if (r.photo or r.video or r.document) else "")
        evidence += f"\n[пересланное сообщение от {r.from_user.first_name if r.from_user else '?'}]: {quoted[:600]}"
    if len(evidence.strip()) < 3:
        return await reply(msg, "bet_need_proof")
    from handlers.ai import llm_json
    from persona import system_prompt
    a_name, o_name = await plain(chat_id, bet["author"]), await plain(chat_id, bet["opponent"])
    who = await plain(chat_id, msg.from_user.id)
    ctx = [m for m in await db.messages_since(chat_id, int(time.time()) - 6 * 3600, 60)]
    ctx_txt = "\n".join(f"{m['nick'] or m['first_name']}: {m['text'][:150]}" for m in ctx if m["text"])[-3000:]
    status = await reply(msg, "bet_judging")
    res = await llm_json([
        {"role": "system", "content": system_prompt(
            "Ты арбитр спора на коины. Утверждение спора выдвинул автор; соперник считает, что оно ложно. "
            "Тебе дали доказательства от одной из сторон и последние сообщения чата. Реши: утверждение ПОДТВЕРДИЛОСЬ (победил автор), "
            "ОПРОВЕРГНУТО (победил соперник) или доказательств недостаточно/они не проверяемы. Не верь на слово: нужны факты, ссылки, скриншоты, "
            "признание второй стороны или общеизвестные вещи. Если утверждение про будущее и срок не наступил — недостаточно. "
            'Верни JSON: {"winner": "author"|"opponent"|"none", "confidence": 0-100, "verdict": "2–4 предложения в твоём стиле: почему"}', with_mood=False)},
        {"role": "user", "content": f"Спор #{bet['id']}. Автор: {a_name}. Соперник: {o_name}. Ставка: {bet['amount']} с каждого.\n"
                                    f"Утверждение автора: «{bet['claim']}»\n\nДоказательства прислал(а) {who}:\n{evidence}\n\nПоследние сообщения чата:\n{ctx_txt}"}],
        max_tokens=400)
    try:
        await status.delete()
    except Exception:
        pass
    if not isinstance(res, dict) or "winner" not in res:
        return await reply(msg, "bet_ai_off")
    verdict = html.escape(str(res.get("verdict", "")))[:900]
    winner = res.get("winner")
    conf = int(res.get("confidence") or 0)
    if winner not in ("author", "opponent") or conf < 60:
        return await reply(msg, "bet_undecided", verdict=verdict)
    await payout(bot, chat_id, bet, bet["author"] if winner == "author" else bet["opponent"], verdict, msg)


async def payout(bot: Bot, chat_id: int, bet, winner_id: int, verdict: str, msg: Message | None):
    loser_id = bet["opponent"] if winner_id == bet["author"] else bet["author"]
    pot = bet["amount"] * 2
    await db.give_coin(chat_id, 0, winner_id, f"спор #{bet['id']}: выигрыш", pot)
    await db.bet_status(bet["id"], "done", winner_id)
    await db.log_event(chat_id, "bet", f"🎲 спор #{bet['id']} «{bet['claim'][:60]}»: {await nm(chat_id, winner_id)} забирает {pot} 🪙 у {await nm(chat_id, loser_id)}")
    from phrases import say
    from utils import style
    text = say(await style(chat_id), "bet_result", chat_id=chat_id, winner=await nm(chat_id, winner_id), loser=await nm(chat_id, loser_id),
               pot=pot, claim=html.escape(bet["claim"]), verdict=verdict)
    sent = await (msg.reply(text) if msg else bot.send_message(chat_id, text))
    await db.remember_bot_message(chat_id, sent.message_id)


async def concede(msg: Message, bot: Bot):
    bet = await _my_bet(msg)
    if not bet:
        return await reply(msg, "bet_none")
    winner = bet["opponent"] if msg.from_user.id == bet["author"] else bet["author"]
    await payout(bot, msg.chat.id, bet, winner, "соперник сдался сам. редкая честность. я почти растрогана.", msg)


async def cancel(msg: Message, bot: Bot):
    chat_id = msg.chat.id
    bet = await _my_bet(msg)
    from utils import has_rank
    is_admin = await has_rank(bot, chat_id, msg.from_user.id, "kick")
    if not bet:
        # админ может отменить любой по номеру
        bets = await db.bets_active(chat_id)
        text = msg.text or ""
        bet = next((b for b in bets if f"#{b['id']}" in text), None)
        if not bet or not is_admin:
            return await reply(msg, "bet_none")
    if not is_admin:
        # нужна отмена от обеих сторон
        votes = set(json.loads(bet["cancel_votes"] or "[]"))
        votes.add(msg.from_user.id)
        if len(votes) < 2:
            await db.bet_cancel_votes(bet["id"], json.dumps(sorted(votes)))
            return await reply(msg, "bet_cancel_wait", user=await nm(chat_id, msg.from_user.id, msg.from_user.first_name))
    await db.give_coin(chat_id, 0, bet["author"], f"спор #{bet['id']}: возврат", bet["amount"])
    await db.give_coin(chat_id, 0, bet["opponent"], f"спор #{bet['id']}: возврат", bet["amount"])
    await db.bet_status(bet["id"], "cancelled")
    await reply(msg, "bet_cancelled", id=bet["id"], amount=bet["amount"])


async def list_bets(msg: Message):
    chat_id = msg.chat.id
    bets = await db.bets_active(chat_id)
    if not bets:
        return await reply(msg, "bet_list_empty")
    lines = [f"#{b['id']} · {await nm(chat_id, b['author'])} vs {await nm(chat_id, b['opponent'])} · {b['amount']} 🪙 · «{html.escape(b['claim'][:80])}»" for b in bets]
    await reply(msg, "bet_list", list="\n".join(lines))


@router.message(Command("споры", "bets", prefix="!+/"))
async def cmd_bets(msg: Message):
    await list_bets(msg)
