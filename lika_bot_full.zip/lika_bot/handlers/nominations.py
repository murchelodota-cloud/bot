"""Ежедневные номинации ЧВК «Сарра»: пикми, симп, бимбо, ПЗР, клоун, истеричка, любимчик (+ подкаблучник).
Счётчики по каждому сообщению дают подсказки; субъективные рубрики решает ИИ (если подключён), иначе — счётчики.
Итоги вечером (nom_hour), один комментарий из десяти, не повторяется два дня подряд. !номинации — текущие лидеры."""
import json
import random
import re
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from phrases import say, ACHIEVEMENTS
from utils import reply, mention, style
from nomdaily import NOMINATIONS, FAVORITE_MIN_MSGS

router = Router()
_ex_cool: dict[tuple[int, int], float] = {}   # антиспам реакции на «бывшая»

EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF\U00002B00-\U00002BFF❤❣♥☺☹\U0001F000-\U0001F2FF]"
)
EX_RE = re.compile(r"\bбывш(?:ая|ей|ую|ие|их|им|ими|его|ий|ему|ем|ой|ею)?\b", re.I)
GIRLS_RE = re.compile(r"\b(девочк[аиеуой]+|девушк[аиеуой]+|девчонк[аиеуой]+|девчат[аы]|подруг[аиеуой]+|красотк[аиеуой]+|малышк[аиеуой]+|жен[аыеу]|жёны|тян(?:очк[аи])?)\b", re.I)

SIMP_RE = re.compile(r"(красив|прекрасн|милая|милый|солнышко|солнце моё|зайк|котик|люблю тебя|обожаю|скучаю|моя королев|мой принц|целую|обнимаю|😍|🥰|😘|❤️|💕|💘)", re.I)
PICKME_RE = re.compile(r"(посмотрите|смотрите|оцените|а я |я вообще|я единственн|я лучш|заметьте|ну я же|как вам я|похвалите|никто не ценит|я не такой|я не такая)", re.I)
LAUGH_RE = re.compile(r"(ахах|хаха|пхах|лол|ржу|😂|🤣|💀|ору)", re.I)
DRAMA_RE = re.compile(r"(ужас|кошмар|ненавижу|всё кончено|всё пропало|никогда|умираю|не могу больше|это конец|предательств|как ты мог|как вы могли|!!!+|\?!|😭|💔|🙄)", re.I)

# счётные рубрики: kind -> что считаем; субъективные уточняет ИИ
KINDS = {k: (f"{v[1]} {v[0]}", "nom_" + k) for k, v in NOMINATIONS.items()}
COUNTED = ("pickme", "simp", "ex", "clown", "drama", "henpecked")


def today() -> str:
    return time.strftime("%Y-%m-%d")


async def nm(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None))


async def analyze(msg: Message):
    """Вызывается из middleware для каждого сообщения."""
    text = msg.text or msg.caption or ""
    if not text or text.startswith(("/", "!", "+", "-")):
        return
    chat_id, uid = msg.chat.id, msg.from_user.id
    day = today()
    await db.nom_add(chat_id, day, uid, "active", 1)
    # пикми: эмодзи + «посмотрите на меня»
    n_pick = len(EMOJI_RE.findall(text)) + 3 * len(PICKME_RE.findall(text))
    if n_pick:
        await db.nom_add(chat_id, day, uid, "pickme", n_pick)
    # симп: комплименты и нежности (сильнее, если это ответ кому-то)
    n_simp = len(SIMP_RE.findall(text))
    if n_simp:
        await db.nom_add(chat_id, day, uid, "simp", n_simp * (2 if msg.reply_to_message else 1))
    # истеричка: капс, !!!, драма-слова
    n_drama = len(DRAMA_RE.findall(text)) + (2 if len(text) > 8 and text.upper() == text and any(c.isalpha() for c in text) else 0)
    if n_drama:
        await db.nom_add(chat_id, day, uid, "drama", n_drama)
    # клоун: над кем смеются — смех в ответ засчитывается автору исходного сообщения
    if msg.reply_to_message and msg.reply_to_message.from_user and not msg.reply_to_message.from_user.is_bot \
            and msg.reply_to_message.from_user.id != uid and LAUGH_RE.search(text):
        await db.nom_add(chat_id, day, msg.reply_to_message.from_user.id, "clown", 1)
    # ПЗР: «бывшая» во всех падежах
    n_ex = len(EX_RE.findall(text))
    if n_ex:
        await db.nom_add(chat_id, day, uid, "ex", n_ex)
        s = await db.settings(chat_id)
        if s.get("ex_react", 1) and time.time() - _ex_cool.get((chat_id, uid), 0) >= int(s.get("ex_react_cooldown", 0)):
            _ex_cool[(chat_id, uid)] = time.time()
            total = sum(r["n"] for r in await db.nom_top(chat_id, day, "ex", 50) if r["user_id"] == uid)
            await reply(msg, "ex_react", user=await nm(chat_id, uid), n=total)
    # подкаблучник: слова про девочек + ответы/упоминания девушек чата
    n_girls = len(GIRLS_RE.findall(text))
    if msg.reply_to_message and msg.reply_to_message.from_user and msg.reply_to_message.from_user.id != uid:
        t = await db.user(chat_id, msg.reply_to_message.from_user.id)
        if t and t["gender"] == "ж":
            n_girls += 1
    for ent in (msg.entities or []):
        if ent.type == "text_mention" and ent.user:
            t = await db.user(chat_id, ent.user.id)
            if t and t["gender"] == "ж":
                n_girls += 1
        elif ent.type == "mention":
            uname = text[ent.offset + 1: ent.offset + ent.length]
            t = await db.find_user_by_username(chat_id, uname)
            if t and t["gender"] == "ж":
                n_girls += 1
    if n_girls:
        await db.nom_add(chat_id, day, uid, "henpecked", n_girls)


async def standings_text(chat_id: int, day: str) -> str:
    parts = []
    for kind in COUNTED:
        title = KINDS[kind][0]
        rows = await db.nom_top(chat_id, day, kind, 3)
        if rows:
            parts.append(f"{title}:\n" + "\n".join([f"  {i + 1}. {await nm(chat_id, r['user_id'])} — {r['n']}" for i, r in enumerate(rows)]))
    return "\n\n".join(parts)


@router.message(Command("номинации", "рубрики", "nominations", "подкаблучник", "пзр", "пикми", "симп", "бимбо", "клоун", "истеричка", prefix="!+/"))
async def cmd_nominations(msg: Message):
    text = await standings_text(msg.chat.id, today())
    if not text:
        return await reply(msg, "nom_empty")
    await reply(msg, "nom_standings", list=text)


def pick_comment(kind: str, last: dict) -> str:
    """Случайный из 10, но не вчерашний."""
    comments = NOMINATIONS[kind][3]
    idx = [i for i in range(len(comments)) if i != last.get(kind)] or list(range(len(comments)))
    i = random.choice(idx)
    last[kind] = i
    return comments[i]


async def ai_pick(bot: Bot, chat_id: int, hints: dict[str, list]) -> dict[str, int]:
    """ИИ выбирает победителей субъективных рубрик по сообщениям дня. Возвращает {kind: user_id}."""
    try:
        from handlers.ai import llm_json
        from persona import system_prompt
        from collections import defaultdict
    except Exception:
        return {}
    msgs = await db.messages_since(chat_id, int(time.time()) - 86400, 600)
    texts = [m for m in msgs if m["text"] and not m["text"].startswith(("/", "!", "+"))]
    if len(texts) < 30:
        return {}
    by_user, names = defaultdict(list), {}
    for m in texts:
        by_user[m["user_id"]].append(m["text"][:140])
        names[m["user_id"]] = m["nick"] or m["first_name"]
    top = sorted(by_user.items(), key=lambda kv: -len(kv[1]))[:14]
    sample = "\n\n".join(f"[{uid}] {names[uid]}:\n" + "\n".join(tt[-18:]) for uid, tt in top)
    crit = "\n".join(f"- {k}: {NOMINATIONS[k][0]} — {NOMINATIONS[k][2]}" for k in COUNTED if NOMINATIONS[k][2])
    hint_txt = "\n".join(f"- {k}: лидеры по счётчику {[(names.get(u, u), n) for u, n in v]}" for k, v in hints.items() if v)
    res = await llm_json([{"role": "system", "content": system_prompt(
        "Ты подводишь ежедневные номинации чата. Рубрики и критерии:\n" + crit +
        "\n\nПодсказки счётчиков (не обязательны, решай по контексту и юмору общения, а не по отдельным словам):\n" + hint_txt +
        '\n\nВерни JSON {"<kind>": <id из квадратных скобок>, ...} только для рубрик, где есть явный кандидат. '
        "Один человек — максимум в двух рубриках. Не награждай за настоящие переживания, уязвимости или конфликты.", with_mood=False)},
        {"role": "user", "content": sample}], max_tokens=200)
    out = {}
    if isinstance(res, dict):
        for k, v in res.items():
            try:
                uid = int(v)
            except (TypeError, ValueError):
                continue
            if k in NOMINATIONS and uid in names:
                out[k] = uid
    return out


async def nominations_close(bot: Bot, chat_id: int, force: bool = False):
    """Итоги дня — из часового цикла после nom_hour (по умолчанию 23)."""
    s = await db.settings(chat_id)
    if not s.get("nominations", 1):
        return
    day = today()
    if not force and (time.localtime().tm_hour < int(s.get("nom_hour", 23)) or s.get("nom_done") == day):
        return
    await db.set_setting(chat_id, "nom_done", day)
    st = await style(chat_id)
    bonus = int(s.get("nom_bonus", 10))
    try:
        last = json.loads(s.get("nom_last") or "{}")
    except Exception:
        last = {}
    hints = {k: [(r["user_id"], r["n"]) for r in await db.nom_top(chat_id, day, k, 3)] for k in COUNTED}
    picks = await ai_pick(bot, chat_id, hints) if s.get("ai_noms", 1) else {}
    winners: dict[str, tuple[int, int]] = {}
    for kind in COUNTED:
        if kind in picks:
            winners[kind] = (picks[kind], 0)
        elif hints[kind] and hints[kind][0][1] >= 2:
            winners[kind] = hints[kind][0]
    # любимчик — случайный среди активных, кто ещё ничего не получил
    active = [r["user_id"] for r in await db.nom_top(chat_id, day, "active", 50) if r["n"] >= FAVORITE_MIN_MSGS]
    pool = [u for u in active if u not in {w[0] for w in winners.values()}] or active
    if pool:
        winners["favorite"] = (random.choice(pool), 0)
    out = []
    for kind in NOMINATIONS:
        if kind not in winners:
            continue
        uid, n = winners[kind]
        title, emoji = NOMINATIONS[kind][0], NOMINATIONS[kind][1]
        await db.give_coin(chat_id, 0, uid, title, bonus)
        await db.give_achievement(chat_id, uid, "nom_" + kind)
        await db.log_event(chat_id, "nom", f"{emoji} {title} — {await nm(chat_id, uid)}")
        comment = pick_comment(kind, last)
        if st == "pickme":
            out.append(f"{emoji} <b>{title}</b> — {await nm(chat_id, uid)}\n«{comment}»")
        else:
            out.append(say(st, "nom_line", chat_id=chat_id, emoji=emoji, title=title, user=await nm(chat_id, uid), bonus=bonus))
    await db.set_setting(chat_id, "nom_last", json.dumps(last))
    if out:
        sent = await bot.send_message(chat_id, say(st, "nom_header", chat_id=chat_id) + "\n\n" + "\n\n".join(out)
                                      + "\n\n" + say(st, "nom_footer", chat_id=chat_id, bonus=bonus))
        await db.remember_bot_message(chat_id, sent.message_id)


@router.message(Command("итогидня", "nomclose", prefix="!+/"))
async def cmd_nom_close(msg: Message, bot: Bot):
    from utils import deny
    if await deny(msg, bot, "kick"):
        return
    await db.set_setting(msg.chat.id, "nom_done", "")
    await nominations_close(bot, msg.chat.id, force=True)
