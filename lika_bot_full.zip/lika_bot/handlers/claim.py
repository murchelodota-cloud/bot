"""Сбор сарра-коинов: раз в claim_hours (8) часов каждый может нажать кнопку и получить случайно claim_min–claim_max (10–200) 🪙.
!сбор / +сбор / !бонус — показать кнопку (сообщение можно закрепить: кнопка общая, таймер у каждого свой)."""
import random
import time
from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.exceptions import TelegramBadRequest
from db import db
from utils import reply, mention, human_duration, style
from phrases import say

router = Router()
KB = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🪙 забрать коины", callback_data="claim:go")]])


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


@router.message(Command("сбор", "бонус", "забрать", "claim", "daily", prefix="!+/"))
async def cmd_claim(msg: Message, bot: Bot):
    s = await db.settings(msg.chat.id)
    if not s.get("claim", 1):
        return
    await reply(msg, "claim_board", hours=int(s.get("claim_hours", 8)), lo=int(s.get("claim_min", 10)), hi=int(s.get("claim_max", 200)), reply_markup=KB)


@router.callback_query(F.data == "claim:go")
async def on_claim(cb: CallbackQuery, bot: Bot):
    chat_id, uid = cb.message.chat.id, cb.from_user.id
    s = await db.settings(chat_id)
    if not s.get("claim", 1):
        return await cb.answer("сбор выключен.", show_alert=True)
    await db.touch_user(chat_id, cb.from_user)
    hours = int(s.get("claim_hours", 8))
    last = await db.last_claim(chat_id, uid)
    left = last + hours * 3600 - int(time.time())
    if left > 0:
        return await cb.answer(f"рано, котенок. следующий сбор через {human_duration(left)}.", show_alert=True)
    lo, hi = int(s.get("claim_min", 10)), int(s.get("claim_max", 200))
    n = random.randint(min(lo, hi), max(lo, hi))
    await db.give_coin(chat_id, 0, uid, "сбор коинов", n)
    await db.set_claim(chat_id, uid, n)
    total = await db.coins_total(chat_id, uid)
    st = await style(chat_id)
    key = "claim_jackpot" if n >= hi - (hi - lo) // 10 else ("claim_small" if n <= lo + (hi - lo) // 10 else "claim_ok")
    await cb.answer(say(st, key, chat_id=chat_id, n=n, total=total, hours=hours).replace("<b>", "").replace("</b>", ""), show_alert=True)
    # в самом сообщении — последний сборщик, чтобы не плодить сообщения
    try:
        await cb.message.edit_text(
            say(st, "claim_board", chat_id=chat_id, hours=hours, lo=lo, hi=hi) + "\n\n" +
            say(st, "claim_last", chat_id=chat_id, user=await nm(chat_id, uid, cb.from_user.first_name), n=n),
            reply_markup=KB)
    except TelegramBadRequest:
        pass
