"""Сводки: !сводка1 (час), !сводка24 (сутки), !сводка7 (неделя) — о чём говорили + что произошло.
С LLM_API_KEY в .env — связный пересказ в стиле Саррочки; без ключа — темы по ключевым словам."""
import asyncio
import html
import json
import logging
import re
import time
from collections import Counter, defaultdict
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from phrases import say
from utils import reply, mention, split_args, style
from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL

router = Router()
WORD_RE = re.compile(r"[а-яёa-z]{4,}", re.I)
STOP = set("""
это этот эта эти того тоже тока тогда только потом просто очень когда если либо будет была были было есть надо нужно можно
нельзя который которая которые чтобы потому зачем почему здесь там тут где куда откуда сейчас вчера сегодня завтра ещё еще
уже всех всем всё все вот ведь даже хотя хоть пока типа короче ладно вообще конечно наверное может быть кажется думаю
знаю знаешь понял поняла привет пока спасибо пожалуйста давай давайте хорошо норм окей ок ага угу нет да нету
меня тебя себя него неё нее нас вас них мне тебе себе ему ней нам вам ним мной тобой собой ими
твой твоя твои твоё мой моя мои моё наш наша наши наше ваш ваша ваши ваше свой своя свои своё его её их
что как так или для при без про под над после перед через между один одна одно одни два две три
какой какая какие какое такой такая такие такое этом этой этих этим этими
сама само сами будут буду будешь будем будете бывает блин капец
""".split())


async def nm(chat_id: int, uid: int, fallback: str | None = None) -> str:
    row = await db.user(chat_id, uid)
    return mention(uid, ((row["nick"] or row["first_name"]) if row else None) or fallback)


def _name(r) -> str:
    return r["nick"] or r["first_name"] or "кто-то"


async def keyword_digest(chat_id: int, msgs: list) -> str:
    """Темы по словам, самые обсуждаемые сообщения, пик, диалоги, ссылки/медиа."""
    if not msgs:
        return "тишина. ни одного сообщения. я одна тут дежурила."
    words = Counter()
    by_id = {}
    reply_count = Counter()
    pairs = Counter()
    hours = Counter()
    links = media = 0
    for r in msgs:
        text = r["text"] or ""
        by_id[r["msg_id"]] = r
        hours[time.localtime(r["ts"]).tm_hour] += 1
        if r["reply_to"]:
            reply_count[r["reply_to"]] += 1
            src = by_id.get(r["reply_to"])
            if src and src["user_id"] != r["user_id"]:
                pairs[tuple(sorted((src["user_id"], r["user_id"])))] += 1
        if "http" in text or "t.me/" in text:
            links += 1
        if r["has_media"]:
            media += 1
        for w in WORD_RE.findall(text.lower()):
            if w not in STOP and not w.startswith(("http", "www")):
                words[w] += 1
    out = []
    top_words = [w for w, n in words.most_common(10) if n >= 2]
    if top_words:
        out.append("🗣 о чём говорили: " + ", ".join(top_words))
    hot = [(mid, n) for mid, n in reply_count.most_common(3) if n >= 2 and mid in by_id]
    if hot:
        lines = []
        for mid, n in hot:
            r = by_id[mid]
            snippet = html.escape((r["text"] or "[медиа]")[:80]).replace("\n", " ")
            lines.append(f"  • {mention(r['user_id'], _name(r))}: «{snippet}» — {n} ответов")
        out.append("🔥 самое обсуждаемое:\n" + "\n".join(lines))
    if pairs:
        (a, b), n = pairs.most_common(1)[0]
        out.append(f"💬 больше всех переписывались: {await nm(chat_id, a)} и {await nm(chat_id, b)} ({n} ответов друг другу)")
    if hours:
        h, n = hours.most_common(1)[0]
        out.append(f"⏰ пик активности: {h:02d}:00–{h + 1:02d}:00 ({n} сообщений)")
    extras = []
    if links:
        extras.append(f"🔗 ссылок: {links}")
    if media:
        extras.append(f"🖼 медиа: {media}")
    if extras:
        out.append(" · ".join(extras))
    return "\n".join(out) or "говорили о чём-то, но ни одно слово не повторилось. загадочно."


async def llm_digest(chat_id: int, msgs: list, period: str) -> str | None:
    """Связный пересказ через OpenAI-совместимый API. None — если нет ключа или ошибка."""
    if not LLM_API_KEY:
        logging.info("llm: no API key, skipping")
        return None
    if not msgs:
        return None
    import aiohttp
    by_id = {r["msg_id"]: r for r in msgs if r["msg_id"]}
    lines = []
    for r in msgs[-500:]:
        t = (r["text"] or "").replace("\n", " ").strip()
        if not t or t.startswith(("/", "!", "+", "-")):
            continue
        prefix = ""
        if r["reply_to"] and r["reply_to"] in by_id:
            src = by_id[r["reply_to"]]
            prefix = f"(отвечает {_name(src)}) "
        lines.append(f"[{time.strftime('%H:%M', time.localtime(r['ts']))}] {_name(r)}: {prefix}{t[:300]}")
    if len(lines) < 5:
        logging.info("llm: only %d text messages, skipping", len(lines))
        return None
    logging.info("llm: requesting %s with %d lines", LLM_MODEL, len(lines))
    transcript = "\n".join(lines)[-16000:]
    events = await db.events(chat_id, int(time.time()) - 7 * 86400, 20)
    ev = "\n".join(e["text"] for e in events[-12:]) or "—"
    # кто есть кто: ранги и ники
    people = {}
    for r in msgs:
        if r["user_id"] not in people:
            people[r["user_id"]] = _name(r)
    from persona import system_prompt
    system = system_prompt("Ты пишешь ДАЙДЖЕСТ переписки.\n"
              "Правила:\n"
              "1. Только то, что есть в переписке. Никаких общих фраз вроде «обсуждали разное» — называй конкретные темы, кто начал, кто что ответил.\n"
              "2. Минимум три прямые цитаты в кавычках с именем автора — самые смешные, резкие или показательные.\n"
              "3. Если был спор — кто с кем и из-за чего, чем кончилось. Если шутили — над чем. Если кто-то ушёл обиженный — скажи.\n"
              "4. Имена — ровно как в переписке. Не придумывай людей и события.\n"
              "5. Структура: 1–2 главные темы подробно, потом мелочи списком через «·», в конце одна фраза от себя в своём стиле.\n"
              "6. Длина 8–14 строк. Без заголовков, без «вот дайджест».", with_mood=False)
    payload = {"model": LLM_MODEL, "temperature": 0.6, "max_tokens": 900,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": f"Период: {period}. Участники: {', '.join(list(people.values())[:30])}.\n"
                                                        f"События бота за период:\n{ev}\n\nПереписка (в скобках — кому отвечает):\n{transcript}"}]}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=90)) as s:
            async with s.post(f"{LLM_BASE_URL}/chat/completions", json=payload,
                              headers={"Authorization": f"Bearer {LLM_API_KEY}"}) as resp:
                data = await resp.json()
                if resp.status != 200:
                    logging.warning("llm %s: %s", resp.status, str(data)[:300])
                    return None
                logging.info("llm: ok, %d chars", len(data["choices"][0]["message"]["content"]))
                return html.escape(data["choices"][0]["message"]["content"].strip())[:3500]
    except Exception as e:
        logging.warning("llm: %s: %s", type(e).__name__, str(e)[:200])
        return None


async def build_summary(chat_id: int, hours: int, period: str) -> dict:
    since = int(time.time()) - hours * 3600
    st = await db.summary_stats(chat_id, since)
    top = await db.summary_top(chat_id, since, 3)
    top_lines = [f"{await nm(chat_id, r['user_id'])} ({r['n']})" for r in top]
    msgs = await db.messages_since(chat_id, since, 600)
    narrative = await llm_digest(chat_id, msgs, period)
    talk = narrative or await keyword_digest(chat_id, msgs)
    events = await db.events(chat_id, since, 40)
    ev_lines = [f"{time.strftime('%H:%M' if hours <= 24 else '%d.%m %H:%M', time.localtime(e['ts']))} {e['text']}" for e in events]
    return {**st, "top": ", ".join(top_lines) or "—", "talk": talk,
            "events": "\n".join(ev_lines) or "событий не было. только разговоры. и я."}


SUMMARY_RE = re.compile(r"^[!+/]?\s*(?:сводка|дайджест|summary)\s*(?:за\s+)?(1|24|7|час|сутки|день|неделя|неделю)?\s*$", re.I)


@router.message(F.text.regexp(SUMMARY_RE).as_("m"))
async def cmd_summary(msg: Message, m: re.Match):
    num = (m.group(1) or "24").lower()
    hours = {"1": 1, "24": 24, "7": 168, "неделя": 168, "неделю": 168, "день": 24, "час": 1, "сутки": 24}.get(num, 24)
    label = {1: "за час", 24: "за сутки", 168: "за неделю"}[hours]
    status = await reply(msg, "summary_wait")
    d = await build_summary(msg.chat.id, hours, label)
    try:
        await status.delete()
    except Exception:
        pass
    text = say(await style(msg.chat.id), "summary", chat_id=msg.chat.id, period=label, **d)
    while text:
        cut = text.rfind("\n", 0, 4000) if len(text) > 4000 else len(text)
        sent = await msg.answer(text[:cut], disable_web_page_preview=True)
        await db.remember_bot_message(msg.chat.id, sent.message_id)
        text = text[cut:].lstrip("\n")


# ---------- автосводка ----------
_last_auto: dict[int, float] = {}


async def auto_summary_tick(bot):
    """Из минутного цикла: раз в summary_every часов, если за этот период было хоть 20 сообщений."""
    now = time.time()
    for chat_id in await db.all_chats():
        s = await db.settings(chat_id)
        every = float(s.get("summary_every", 0) or 0)
        if every <= 0:
            continue
        if now - _last_auto.get(chat_id, now) < every * 3600 and chat_id in _last_auto:
            continue
        if chat_id not in _last_auto:
            _last_auto[chat_id] = now   # первый раз — отсчёт с запуска, не сразу
            continue
        _last_auto[chat_id] = now
        hours = int(every) if every >= 1 else 1
        st = await db.summary_stats(chat_id, int(now) - hours * 3600)
        if st["msgs"] < int(s.get("summary_min_msgs", 20)):
            continue
        label = {1: "за час", 2: "за 2 часа", 3: "за 3 часа", 4: "за 4 часа", 6: "за 6 часов", 12: "за 12 часов", 24: "за сутки"}.get(hours, f"за {hours} ч")
        try:
            d = await build_summary(chat_id, hours, label)
            text = say(await style(chat_id), "summary_auto", chat_id=chat_id, period=label, **d)
            targets = [chat_id]
            channel = int(s.get("summary_channel") or 0)
            if channel:
                targets = [channel] if s.get("summary_channel_only", 0) else [chat_id, channel]
            for target in targets:
                chunk = text
                while chunk:
                    cut = chunk.rfind("\n", 0, 4000) if len(chunk) > 4000 else len(chunk)
                    sent = await bot.send_message(target, chunk[:cut], disable_web_page_preview=True)
                    if target == chat_id:
                        await db.remember_bot_message(chat_id, sent.message_id)
                    chunk = chunk[cut:].lstrip("\n")
        except Exception as e:
            logging.warning("auto summary %s: %s", chat_id, e)
