"""Защита от накрутки: масса, счётчик сообщений (коины за 500) и квесты считают только осмысленные сообщения —
не короче farm_min_len (3) символов или с медиа, не повтор своего же текста подряд, не больше farm_hour_cap (60) в час на человека.
Команды (/ ! + -) не считаются. Остальное (ответ Саррочки, модерация) работает как обычно."""
import time
from collections import defaultdict, deque
from aiogram.types import Message

MIN_LEN = 3
HOUR_CAP = 60
_last_text: dict[tuple[int, int], str] = {}
_hour: dict[tuple[int, int], deque] = defaultdict(deque)
_stats: dict[int, int] = defaultdict(int)   # сколько отсеяно за сегодня, для !пульс/логов


def counts(msg: Message) -> bool:
    text = (msg.text or msg.caption or "").strip()
    has_media = bool(msg.photo or msg.video or msg.voice or msg.video_note or msg.document or msg.animation or msg.sticker)
    if text.startswith(("/", "!", "+", "-")):
        return False
    key = (msg.chat.id, msg.from_user.id)
    now = time.time()
    if not has_media:
        # слишком коротко: «)», «ок», «+», одни эмодзи из 1–2 символов
        if len(text) < MIN_LEN:
            _stats[msg.chat.id] += 1
            return False
        # повтор своего же сообщения
        if _last_text.get(key) == text.lower():
            _stats[msg.chat.id] += 1
            return False
        _last_text[key] = text.lower()
    dq = _hour[key]
    while dq and now - dq[0] > 3600:
        dq.popleft()
    if len(dq) >= HOUR_CAP:
        _stats[msg.chat.id] += 1
        return False
    dq.append(now)
    return True
