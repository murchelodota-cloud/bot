"""Сезонные события: праздники с поздравлением от Саррочки (ИИ, с учётом жизни чата), 14 февраля — валентинки за коины и рейтинг пар,
персональные поздравления с днём рождения по памяти о человеке. Настройки: seasons (1/0), valentine_price (20).
+валентинка @юзер текст — анонимная валентинка (10–14 февраля; в остальное время — обычная, не анонимная)."""
import html
import json
import logging
import random
import time
from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message
from db import db
from utils import reply, mention, resolve_target, split_args, style
from phrases import say

router = Router()
HOLIDAYS = {
    "01-01": ("Новый год", "итоги года чата, пожелания, кто как встретил"),
    "01-07": ("Рождество", "коротко и тепло"),
    "02-14": ("День всех влюблённых", "пары чата, кто кого любит безответно, валентинки"),
    "02-23": ("23 февраля", "поздравить мужчин чата с иронией, без милитаризма"),
    "03-08": ("8 марта", "девочек чата — нежно и с восхищением, мальчикам — напомнить про цветы"),
    "04-01": ("1 апреля", "день, когда можно врать — розыгрыш или фейковая новость про чат"),
    "05-09": ("9 мая", "сдержанно и уважительно, без шуток"),
    "06-01": ("День защиты детей", "про то, кто в чате ведёт себя как ребёнок"),
    "09-01": ("1 сентября", "кто в чате вечный студент"),
    "10-31": ("Хэллоуин", "кто в чате самый страшный, костюмы"),
    "12-31": ("Канун Нового года", "итоги года: цифры, пары, драмы, кто вырос; тост"),
}
_done: dict[tuple[int, str], bool] = {}


async def plain(chat_id: int, uid: int) -> str:
    row = await db.user(chat_id, uid)
    return ((row["nick"] or row["first_name"]) if row else None) or "кто-то"


async def seasons_tick(bot: Bot):
    lt = time.localtime()
    if lt.tm_hour < 10:
        return
    key = time.strftime("%m-%d")
    if key not in HOLIDAYS:
        return
    day = time.strftime("%Y-%m-%d")
    for chat_id in await db.all_chats():
        if chat_id > 0 or _done.get((chat_id, day)):
            continue
        s = await db.settings(chat_id)
        if not s.get("seasons", 1) or s.get("season_done") == day:
            _done[(chat_id, day)] = True
            continue
        await db.set_setting(chat_id, "season_done", day)
        _done[(chat_id, day)] = True
        try:
            await greet(bot, chat_id, *HOLIDAYS[key])
        except Exception as e:
            logging.warning("season %s: %s", chat_id, e)


async def greet(bot: Bot, chat_id: int, name: str, angle: str):
    from handlers.ai import llm
    from persona import system_prompt
    since = int(time.time()) - (365 if name.startswith(("Новый", "Канун")) else 30) * 86400
    top = await db.top_period(chat_id, 30, 5)
    try:
        marriages = await db.marriages(chat_id)
    except Exception:
        marriages = []
    facts = (f"топ активных за месяц: {', '.join([await plain(chat_id, r['user_id']) for r in top])}; "
             f"пар в чате: {len(marriages)}; заметки: " + " | ".join(f"{n['day']}: {n['note']}" for n in await db.day_notes(chat_id, 7)))
    out = await llm([{"role": "system", "content": system_prompt(
        f"Сегодня {name}. Напиши поздравление для чата: 4–8 строк, строчными, без markdown, в своём стиле, угол: {angle}. "
        "Используй реальные имена и события из фактов, не выдумывай. В конце — одна фраза от себя.", with_mood=False)},
        {"role": "user", "content": facts}], max_tokens=400, temperature=0.8)
    text = html.escape(out) if out else say(await style(chat_id), "season_fallback", chat_id=chat_id, name=name)
    sent = await bot.send_message(chat_id, text)
    await db.remember_bot_message(chat_id, sent.message_id)
    if name == "День всех влюблённых":
        await couples_rating(bot, chat_id)


async def couples_rating(bot: Bot, chat_id: int):
    """14 февраля: рейтинг пар по взаимным ответам + флирту."""
    pairs = await db.rel_pairs(chat_id, "flirt", 5, int(time.time()) - 30 * 86400)
    if not pairs:
        return
    lines = [f"{i + 1}. {mention(p['x'], await plain(chat_id, p['x']))} + {mention(p['y'], await plain(chat_id, p['y']))} — {p['n']} 💘" for i, p in enumerate(pairs)]
    for p in pairs[:1]:
        for u in (p["x"], p["y"]):
            await db.give_coin(chat_id, 0, u, "пара года", 100)
    sent = await bot.send_message(chat_id, say(await style(chat_id), "season_couples", chat_id=chat_id, list="\n".join(lines)))
    await db.remember_bot_message(chat_id, sent.message_id)


@router.message(Command("валентинка", "valentine", prefix="+!/"))
async def cmd_valentine(msg: Message, bot: Bot):
    chat_id, uid = msg.chat.id, msg.from_user.id
    s = await db.settings(chat_id)
    target, name, rest = await resolve_target(msg)
    text = " ".join(rest).strip()
    if not target or target == uid or len(text) < 2:
        return await reply(msg, "valentine_usage")
    cost = int(s.get("valentine_price", 20))
    bal = await db.coins_total(chat_id, uid)
    if bal < cost:
        return await reply(msg, "shop_poor", name="валентинка", cost=cost, balance=bal)
    md = time.strftime("%m-%d")
    anon = "02-10" <= md <= "02-14"
    await db.give_coin(chat_id, uid, 0, "валентинка", -cost)
    await db.rel_add(chat_id, uid, target, "flirt", 3)
    try:
        await msg.delete()
    except Exception:
        pass
    to = mention(target, await plain(chat_id, target))
    frm = "" if anon else mention(uid, await plain(chat_id, uid))
    sent = await bot.send_message(chat_id, say(await style(chat_id), "valentine_anon" if anon else "valentine", chat_id=chat_id, to=to, frm=frm, text=html.escape(text[:200])))
    await db.remember_bot_message(chat_id, sent.message_id)


async def personal_birthday(bot: Bot, chat_id: int, uid: int) -> str | None:
    """Персональное поздравление по памяти о человеке (вызывается из iris.birthday_check)."""
    try:
        from handlers.ai import llm
        from persona import system_prompt
        from handlers.relations import summary as rel_summary
        facts = "; ".join(r["fact"] for r in await db.user_facts(chat_id, uid, 15))
        u = await db.user(chat_id, uid)
        texts = [m["text"] for m in await db.user_messages(chat_id, uid, 60)]
        info = (f"имя: {await plain(chat_id, uid)}; сообщений: {u['msgs'] if u else 0}; факты: {facts or '—'}; {await rel_summary(chat_id, uid)}; "
                f"браки: {len(await db.partners(chat_id, uid))}; ачивки: {', '.join(await db.achievements(chat_id, uid)) or '—'}\nего сообщения:\n" + "\n".join(f"- {t[:100]}" for t in texts[-30:]))
        out = await llm([{"role": "system", "content": system_prompt(
            "У участника чата день рождения. Напиши персональное поздравление 4–6 строк, строчными, без markdown: с конкретикой про него (что он за человек в чате, "
            "его привычки, фирменные фразы, с кем дружит/спорит), с иронией и теплом, в конце — искреннее пожелание. Только факты из материалов.", with_mood=False)},
            {"role": "user", "content": info}], max_tokens=350, temperature=0.8)
        return html.escape(out) if out else None
    except Exception as e:
        logging.warning("bday llm: %s", e)
        return None
