# Авто-деплой и мониторинг (на сервере, один раз)

```
cd /opt/lika_bot && chmod +x deploy/*.sh && (crontab -l 2>/dev/null | grep -v "lika_bot/deploy"; \
 echo "* * * * * /opt/lika_bot/deploy/update.sh >/dev/null 2>&1"; \
 echo "*/5 * * * * /opt/lika_bot/deploy/watchdog.sh >/dev/null 2>&1") | crontab -
```

После этого:
- `!обновить` в чате (владелец) или в личке боту → в течение минуты сервер сам делает git pull, распаковку зипа и пересборку, присылает отчёт.
- Если бот завис/упал — сторож перезапустит и напишет владельцам.
- Ручной запуск: `/opt/lika_bot/deploy/update.sh force`. Лог: `data/update.log`.
