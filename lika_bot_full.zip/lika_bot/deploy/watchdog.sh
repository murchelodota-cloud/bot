#!/usr/bin/env bash
# Мониторинг: раз в 5 минут. Если контейнер не запущен или бот не обновлял data/heartbeat дольше 6 минут — перезапуск и сообщение владельцам.
set -u
DIR=/opt/lika_bot
HB=$DIR/data/heartbeat
TOKEN=$(grep ^BOT_TOKEN= "$DIR/.env" | cut -d= -f2-)
notify() { for ID in $(grep ^OWNER_IDS= "$DIR/.env" | cut -d= -f2- | tr ',' ' '); do
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" -d chat_id="$ID" -d text="$1" >/dev/null; done; }
cd "$DIR" || exit 0
RUNNING=$(docker compose ps --status running -q 2>/dev/null | wc -l)
AGE=9999
[ -f "$HB" ] && AGE=$(( $(date +%s) - $(stat -c %Y "$HB") ))
if [ "$RUNNING" -eq 0 ] || [ "$AGE" -gt 360 ]; then
  docker compose up -d --force-recreate >/dev/null 2>&1
  notify "🚑 Саррочка не отвечала $((AGE/60)) мин (контейнеров: $RUNNING) — перезапустила её. $(date '+%H:%M')"
fi
