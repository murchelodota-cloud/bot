#!/usr/bin/env bash
# Авто-обновление Саррочки. Запускается кроном раз в минуту на хосте; срабатывает, если бот оставил флаг data/update.flag
# (команда !обновить от владельца) ИЛИ если передан аргумент force. Делает: git pull → распаковка lika_bot_full.zip → сохранение .env → пересборка.
set -u
DIR=/opt/lika_bot
FLAG=$DIR/data/update.flag
LOG=$DIR/data/update.log
if [ "${1:-}" != "force" ] && [ ! -f "$FLAG" ]; then exit 0; fi
rm -f "$FLAG"
{
  echo "=== $(date '+%F %T') update start"
  cd "$DIR" || exit 1
  cp .env /tmp/env.bak
  git checkout -- .env 2>/dev/null
  git pull 2>&1
  python3 -c "import zipfile; zipfile.ZipFile('lika_bot_full.zip').extractall('/opt')" 2>&1
  cp /tmp/env.bak .env
  docker compose up -d --build 2>&1 | tail -3
  echo "=== $(date '+%F %T') update done"
} >> "$LOG" 2>&1
# сообщить владельцам
TOKEN=$(grep ^BOT_TOKEN= "$DIR/.env" | cut -d= -f2-)
for ID in $(grep ^OWNER_IDS= "$DIR/.env" | cut -d= -f2- | tr ',' ' '); do
  curl -s -X POST "https://api.telegram.org/bot$TOKEN/sendMessage" -d chat_id="$ID" -d text="🔄 обновилась. $(tail -1 "$LOG")" >/dev/null
done
