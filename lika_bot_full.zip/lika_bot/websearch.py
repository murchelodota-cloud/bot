"""Веб-поиск для ответов Саррочки (DuckDuckGo через ddgs, без ключей). Используется, когда модель сама решает, что вопрос про свежее/конкретное:
курсы, цены, новости, расписания, «что сейчас», адреса, характеристики. Возвращает сниппеты с источниками."""
import asyncio
import logging
import re


def _search_sync(query: str, n: int = 6) -> list[dict]:
    from ddgs import DDGS
    out = []
    try:
        for r in DDGS().text(query, max_results=n, region="ru-ru", safesearch="moderate"):
            out.append({"title": (r.get("title") or "")[:120], "url": r.get("href") or r.get("url") or "", "body": (r.get("body") or "")[:400]})
    except Exception as e:
        logging.warning("websearch %r: %s", query, str(e)[:200])
    return out


def _news_sync(query: str, n: int = 5) -> list[dict]:
    from ddgs import DDGS
    out = []
    try:
        for r in DDGS().news(query, max_results=n, region="ru-ru"):
            out.append({"title": (r.get("title") or "")[:120], "url": r.get("url") or "", "body": (r.get("body") or "")[:400], "date": (r.get("date") or "")[:10]})
    except Exception as e:
        logging.warning("news %r: %s", query, str(e)[:200])
    return out


async def search(query: str, n: int = 6, news: bool = False) -> list[dict]:
    loop = asyncio.get_running_loop()
    try:
        return await asyncio.wait_for(loop.run_in_executor(None, _news_sync if news else _search_sync, query, n), 25)
    except asyncio.TimeoutError:
        return []


def fmt(results: list[dict]) -> str:
    return "\n".join(f"[{i + 1}] {r['title']}" + (f" ({r['date']})" if r.get("date") else "") + f"\n{r['body']}\nисточник: {r['url']}" for i, r in enumerate(results))


NEED_WEB_HINT = re.compile(r"(сейчас|сегодня|вчера|завтра|текущ|актуальн|курс|цена|стоит|сколько стоит|новост|погод|расписани|когда выйдет|когда будет|"
                           r"последн|свеж|2026|2027|адрес|телефон|режим работы|где купить|отзыв|рейтинг|характеристик|спецификац)", re.I)


async def research(question: str, context: str = "") -> tuple[str, list[dict]]:
    """Спрашиваем модель, нужен ли поиск и какой запрос; ищем; возвращаем (блок с результатами для промпта, результаты)."""
    from handlers.ai import llm_json
    plan = await llm_json([
        {"role": "system", "content": 'Реши, нужен ли веб-поиск, чтобы ответить точно и актуально (свежие события, цены, курсы, расписания, конкретные товары/места/люди, '
                                      'факты, в которых ты можешь ошибиться). Общие знания, советы, объяснения, переводы, расчёты — поиск не нужен. '
                                      'Верни JSON: {"web": true/false, "news": true/false, "query": "короткий поисковый запрос на языке источников"}'},
        {"role": "user", "content": f"Вопрос: {question}\nКонтекст: {context[-600:]}"}], max_tokens=80)
    need = bool(plan and plan.get("web")) or bool(NEED_WEB_HINT.search(question))
    if not need:
        return "", []
    query = (plan or {}).get("query") or question[:120]
    results = await search(query, 6, news=bool(plan and plan.get("news")))
    if not results and plan and plan.get("news"):
        results = await search(query, 6)
    if not results:
        return "", []
    return f"РЕЗУЛЬТАТЫ ПОИСКА (запрос «{query}»):\n{fmt(results)}", results
